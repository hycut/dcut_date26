#include <stdio.h>
#include "cstrlist.h"

void print_constraints(struct CStrList* pcstrlist)
{
    struct CStrList* l = pcstrlist;
    while (l) {
        for (int i = 0; i < l->current.length; i++) {
            printf("%.10f ", l->current.coeffs[i]);
        }
        printf("%c %.10f\n", l->current.direction, l->current.d);
        l = l->next;
    }
}
