#include "split.h"
#include "cstrlist.h"

#include <assert.h>

#define DEBUG_GRAM_SCHMIDT
#define DEBUG_GRAM_SCHMIDT_AND_INVERSE
#define DEBUG_INSERTION_ABS_SORT
#define DEBUG_COMPLETE_INTO_BASE_AND_NORMALIZE

#define AVG_WINDOW 5
#define MAX_THREAD 128
#define MIN_DEPTH_PER_THREAD 5

// BEGIN Investigate infeasible encode_nn_and_solve
// int exit_prog = 0;
// unsigned long g_parent_tid = 0;
// END Investigate infeasible encode_nn_and_solve

int prev_chosen_layer = -1;
int prev_chosen_neuron = -1;

int NEED_PRINT = 0;
int NEED_FOR_ONE_RUN = 0;
int input_depth = 0;
int adv_found = 0;
int count = 0;
int thread_tot_cnt = 0;
int smear_cnt = 0;

int progress = 0;

int CHECK_ADV_MODE = 0;
int PARTIAL_MODE = 0;

double avg_depth = 50;
double total_avg_depth = 0;
int leaf_num = 0;
int uncertain_leaf_num = 0;
double max_depth = 0;

double avg_linear_neurons_robust = 0;
double avg_lin_split_active = 0;
double avg_lin_split_inactive = 0;
double avg_lin_split_hybrid = 0;

int split_num = 0;
int active_splits = 0;
int inactive_splits = 0;
int hybrid_splits = 0;
int killed_splits = 0;
double avg_linear_neurons_split = 0;

int csv_print = 0;

int total_gurobi_count = 0;
int input_gurobi_count = 0;
int gurobi_count = 0;
double total_gurobi_time = 0;

int max_dims_used_robust = -1;
int min_dims_used_robust = INT_MAX;

int max_allowed_depth = -1;
int uncertain_analysis = 0;

double avg_target_output_width = 0;

struct timeval start, finish, last_finish;

pthread_mutex_t lock;

/*
 * Following functions check whether there is any violation of defined
 * properties.
 * functions look like foo() check for interval output
 * functions look like foo1() check for concrete output
 * It takes in the network structure and approximated output ranges
 * It outputs whether has overlap, 1 for overlap, 0 for none.
 */
int check_max_constant(struct NNet *nnet, struct DInterval *output)
{
  // pthread_mutex_lock(&lock);
  // printf("check_max_constant: %.20f\n",output->upper_dmatrix->data[nnet->target]);
  // pthread_mutex_unlock(&lock);
  if (output->upper_dmatrix->data[nnet->target] > 0.5011)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

// can target be max?
// For an exact analysis:
//      yes iff all other. other - target can be negative
//      i.e., all other. lower(other - target) <= 0.
// For an over-approximation:
//      returning false means indeed there is at least other. st. other-target is always positive
//      and hence target cannot be max.
int check_max(struct NNet *nnet, struct DInterval *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {
    if (output->lower_dmatrix->data[i] > 0 && i != nnet->target)
    {
      return 0;
    }
  }
  return 1;
}

// can target be strictly smaller than another out?
int check_target_not_largest(struct NNet *nnet, struct DInterval *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {
    if(i != nnet->target){
      if (output->upper_dmatrix->data[i] > output->lower_dmatrix->data[nnet->target])
      {
        return 1;
      }
    }
  }
  return 0;
}

// can target be strictly larger than anothe out?
int check_target_not_smallest(struct NNet *nnet, struct DInterval *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {
    if(i != nnet->target){
      if (output->lower_dmatrix->data[i] < output->upper_dmatrix->data[nnet->target])
      {
        return 1;
      }
    }
  }
  return 0;
}

// used for property 117
int check_target_may_be_outside_neg_one_one(struct NNet *nnet, struct DInterval *output)
{
    for (int i = 0; i < nnet->outputSize; i++) {
        if(i == nnet->target) {
            if (output->lower_dmatrix->data[i] < -1 || output->upper_dmatrix->data[i] > 1) {
                return 1;
            }
        }
    }
    return 0;
}

// used for property 118
int check_target_may_be_outside_zero_one(struct NNet *nnet, struct DInterval *output)
{
    for (int i = 0; i < nnet->outputSize; i++) {
        if(i == nnet->target) {
            if (output->lower_dmatrix->data[i] < 0 || output->upper_dmatrix->data[i] > 1) {
                return 1;
            }
        }
    }
    return 0;
}

// used for property 119
int check_target_may_be_outside_neg_three_two(struct NNet *nnet, struct DInterval *output)
{
    for (int i = 0; i < nnet->outputSize; i++) {
        if(i == nnet->target) {
            if (output->lower_dmatrix->data[i] < -3 || output->upper_dmatrix->data[i] > 2) {
                return 1;
            }
        }
    }
    return 0;
}

int get_most_violating_index_for_target_not_largest(struct NNet *nnet, struct DInterval *output)
{
  int largest_index = -1;
  double largest_value = 0.0;
  for (int i = 0; i < nnet->outputSize; i++)
  {
    if(i!=nnet->target){
      double beyond = output->upper_dmatrix->data[i] - output->lower_dmatrix->data[nnet->target];
      if(beyond > largest_value){
        largest_value = beyond;
        largest_index = i;
      }
    }
  }
  return largest_index;
}

// can target be min?
// For an exact analysis:
//      yes iff all other. other - target can be positive
//      i.e., all other. upper(other - target) >= 0.
// For an over-approximation:
//      returning false means indeed there is at least other. st. (other - target) is always negative
//      and hence target cannot be min.
int check_min(struct NNet *nnet, struct DInterval *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {
    if (output->upper_dmatrix->data[i] < 0 && i != nnet->target)
    {
      return 0;
    }
  }
  return 1;
}

int check_min_p7(struct NNet *nnet, struct DInterval *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {

    if (i != 3 && i != 4)
    {

      if (output->upper_dmatrix->data[i] <
              output->lower_dmatrix->data[4] &&
          output->upper_dmatrix->data[i] <
              output->lower_dmatrix->data[3])
      {
        return 0;
      }
    }
  }

  return 1;
}

int check_not_min_p8(struct NNet *nnet, struct DInterval *output)
{

  for (int i = 0; i < nnet->outputSize; i++)
  {
    if (i != 0 && i != 1)
    {
      if (output->lower_dmatrix->data[i] <
              output->upper_dmatrix->data[0] &&
          output->lower_dmatrix->data[i] <
              output->upper_dmatrix->data[1])
      {
        return 1;
      }
    }
  }

  return 0;
}

// can target be not min?
// For an exact analysis:
//      yes iff exists other s.t. other - target can be negative
//      i.e., exists other. lower(other - target) < 0.
// For an over-approximation:
//      returning false means indeed for all other. (other - target) is always positive or zero
//      and hence target has to be min.
int check_not_min(struct NNet *nnet, struct DInterval *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {
    // printf("%d -> %f\n", i, output->lower_dmatrix->data[i]);
    if (output->lower_dmatrix->data[i] < 0 && i != nnet->target)
    {
      return 1;
    }
  }
  return 0;
}

int check_not_min_p11(struct NNet *nnet, struct DInterval *output)
{

  if (output->lower_dmatrix->data[0] < 0)
  {
    return 1;
  }

  return 0;
}

int check_min1_p7(struct NNet *nnet, struct DMatrix *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {

    if (i != 3 && i != 4)
    {

      if (output->data[i] < output->data[3] && output->data[i] < output->data[4])
      {
        return 0;
      }
    }
  }

  return 1;
}

// MNIST, property 1000
int check_not_max(struct NNet *nnet, struct DInterval *output)
{
  for (int i = 0; i < nnet->outputSize; i++) {
    if (output->upper_dmatrix->data[i] > 0 && i != nnet->target) {
      return 1;
    }
  }
  return 0;
}

int check_max_constant1(struct NNet *nnet, struct DMatrix *output)
{
    // This version follows the same reasoning as check_max_constant: unwanted condition returns 1
  // pthread_mutex_lock(&lock);
  // printf("check_max_constant1: %.20f\n",output->data[nnet->target]);
  // pthread_mutex_unlock(&lock);
  if (output->data[nnet->target] > 0.5011)
  {
    return 1;
  }
  return 0;

/*
  if (output->data[nnet->target] < 0.5011)
  {
    return 0;
  }

  return 1;
  */
}

// Is target max?
//      yes iff all other. other - target is negative or zero
//      i.e., all other. (other - target) <= 0.
int check_max1(struct NNet *nnet, struct DMatrix *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {
    if (output->data[i] > 0 && i != nnet->target)
    {
      return 0;
    }
  }
  return 1;
}

// Is target min?
//      yes iff all other. other - target is positive or zero
//      i.e., all other. (other - target) >= 0.
int check_min1(struct NNet *nnet, struct DMatrix *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {
    if (output->data[i] < 0 && i != nnet->target)
    {
      return 0;
    }
  }
  return 1;
}

// Is target not min?
//      true iff exists other. other - target is negative
//      i.e., exists other. (other - target) < 0.
// equiv. false iff all other. other - target is positive or zero
//      i.e., all other. (other - target) >= 0.
int check_not_min1(struct NNet *nnet, struct DMatrix *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {
    if (output->data[i] < 0 && i != nnet->target)
    {
      return 1;
    }
  }
  return 0;
}

int check_not_min1_p8(struct NNet *nnet, struct DMatrix *output)
{

  for (int i = 0; i < nnet->outputSize; i++)
  {

    if (i != 0 && i != 1)
    {

      if (output->data[i] < output->data[0] && output->data[i] < output->data[1])
      {
        return 1;
      }
    }
  }

  return 0;
}

// can target be strictly smaller than another ?
// at least one other node has a larger value than the target node.
int check_target_not_largest1(struct NNet *nnet, struct DMatrix *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {
    if (i != nnet->target)
    {
      if (output->data[nnet->target] < output->data[i])
      {
        return 1;
      }
    }
  }
  return 0;
}

// can target be strictly larger than another?
// at least one other node has a smaller value than the target node.
int check_target_not_smallest1(struct NNet *nnet, struct DMatrix *output)
{
  for (int i = 0; i < nnet->outputSize; i++)
  {
    if (i != nnet->target)
    {
      if (output->data[nnet->target] > output->data[i])
      {
        return 1;
      }
    }
  }
  return 0;
}

// used for property 117
int check_target_may_be_outside_neg_one_one1(struct NNet *nnet, struct DMatrix *output)
{
    if (output->data[nnet->target] < -1 || output->data[nnet->target] > 1)
    {
        return 1;
    }
    return 0;
}

// used for property 118
int check_target_may_be_outside_zero_one1(struct NNet *nnet, struct DMatrix *output)
{
    if (output->data[nnet->target] < 0 || output->data[nnet->target] > 1)
    {
        return 1;
    }
    return 0;
}

// used for property 119
int check_target_may_be_outside_neg_three_two1(struct NNet *nnet, struct DMatrix *output)
{
    if (output->data[nnet->target] < -3 || output->data[nnet->target] > 2)
    {
        return 1;
    }
    return 0;
}

int check_not_min1_p11(struct NNet *nnet, struct DMatrix *output)
{

  if (output->data[0] < 0)
  {
    return 1;
  }

  return 0;
}

// MNIST, property 1000
int check_not_max1(struct NNet *nnet, struct DMatrix *output)
{
  for (int i = 0; i < nnet->outputSize; i++) {
    if (output->data[i] > 0 && i != nnet->target) {
      return 1;
    }
  }
  return 0;
}

int get_most_violating_index(struct NNet *nnet, struct DInterval *output)
{

//  if (PROPERTY == 114)
//  {
    return get_most_violating_index_for_target_not_largest(nnet, output);
//  }

}

int check_functions(struct NNet *nnet, struct DInterval *output)
{

  if (PROPERTY == 1)
  {
    return check_max_constant(nnet, output);
  }

  if (PROPERTY == 2)
  {
    return check_max(nnet, output);
  }

  if (PROPERTY == 3)
  {
    return check_min(nnet, output);
  }

  if (PROPERTY == 4)
  {
    return check_min(nnet, output);
  }

  if (PROPERTY == 5)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 16)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 26)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 7)
  {
    return check_min_p7(nnet, output);
  }

  if (PROPERTY == 8)
  {
    return check_not_min_p8(nnet, output);
  }

  if (PROPERTY == 9)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 10)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 11)
  {
    return check_not_min_p11(nnet, output);
  }

  if (PROPERTY == 12)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 13)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 14)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 15)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 100)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 101)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 102)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 110)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 111)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 112)
  {
    return check_not_min(nnet, output);
  }

  // Below is non ACAS Xu properties
  if (PROPERTY == 114)
  {
    return check_target_not_largest(nnet, output);
  }

  if (PROPERTY == 115)
  {
      return check_target_not_smallest(nnet, output);
    /* return check_min(nnet, output); */
  }

  if (PROPERTY == 116)
  {
    return check_target_not_smallest(nnet, output);
  }

  if (PROPERTY == 117)
  {
    return check_target_may_be_outside_neg_one_one(nnet, output);
  }

  if (PROPERTY == 118)
  {
    return check_target_may_be_outside_zero_one(nnet, output);
  }
  if (PROPERTY == 119)
  {
    return check_target_may_be_outside_neg_three_two(nnet, output);
  }

  if (PROPERTY == 120)
  {
    return check_not_min(nnet, output);
  }

  if (PROPERTY == 1000)
  {
    return check_not_max(nnet, output);
  }

  return -1;
}

int check_functions1(struct NNet *nnet, struct DMatrix *output)
{

  if (PROPERTY == 1)
  {
    return check_max_constant1(nnet, output);
  }

  if (PROPERTY == 2)
  {
    return check_max1(nnet, output);
  }

  if (PROPERTY == 3)
  {
    return check_min1(nnet, output);
  }

  if (PROPERTY == 4)
  {
    return check_min1(nnet, output);
  }

  if (PROPERTY == 5)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 16)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 26)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 7)
  {
    return check_min1_p7(nnet, output);
  }

  if (PROPERTY == 8)
  {
    return check_not_min1_p8(nnet, output);
  }

  if (PROPERTY == 9)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 10)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 11)
  {
    return check_not_min1_p11(nnet, output);
  }

  if (PROPERTY == 12)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 13)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 14)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 15)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 100)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 101)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 102)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 110)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 111)
  {
    return check_not_min1(nnet, output);
  }

  if (PROPERTY == 112)
  {
    return check_not_min1(nnet, output);
  }

  // Below is non ACAS Xu properties
  if (PROPERTY == 114)
  {
    return check_target_not_largest1(nnet, output);
  }

  if (PROPERTY == 115)
  {
      return check_target_not_smallest1(nnet, output);
    /* return check_min1(nnet, output); */
  }

  if (PROPERTY == 116)
  {
    return check_target_not_smallest1(nnet, output);
  }

  if (PROPERTY == 117)
  {
    return check_target_may_be_outside_neg_one_one1(nnet, output);
  }

  if (PROPERTY == 118)
  {
    return check_target_may_be_outside_zero_one1(nnet, output);
  }

  if (PROPERTY == 119)
  {
    return check_target_may_be_outside_neg_three_two1(nnet, output);
  }

  if (PROPERTY == 120)
  {
    return check_not_min1(nnet, output);
  }

  // MNIST
  if (PROPERTY == 1000)
  {
    return check_not_max1(nnet, output);
  }

  return -1;
}


double normalize(double v[], int n)
{
    return sqrt(cblas_ddot(n, v, 1, v, 1));
}

// simple insertion sort on vec with map tracking permuations
// map[0]: index of smallest, map[n-1]: index of largest
void insertion_abs_sort(double _vec[], int map[], int n)
{
    double vec[n];
    for (int i = 0; i < n; i++){
        vec[i] = (_vec[i] < 0 ? -_vec[i] : _vec[i]);
    }

// #ifdef DEBUG_INSERTION_ABS_SORT
#ifdef DEBUG
    pthread_mutex_lock(&lock);
    printf(">>>>>>>> pid= %ld \n", syscall(SYS_gettid));
    printf("insertion sort with vec\nvec=[");

    for (int i = 0; i < n; i++){
        printf("%.20f ", vec[i]);
    }

    printf("]\n");
    printf("<<<<<<<<< pid= %ld \n", syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif // #ifdef DEBUG_INSERTION_ABS_SORT

    for (int i = 1; i < n; i++) {
        double smallest = (vec[i] < 0 ? -vec[i] : vec[i]);
        int j = i;

        while (j > 0 && vec[j - 1] > smallest) {
            j--;
            vec[j + 1] = vec[j];
            map[j + 1] = map[j];
        }

        vec[j] = smallest;
        map[j] = i;
    }

// #ifdef DEBUG_INSERTION_ABS_SORT
#ifdef DEBUG
    pthread_mutex_lock(&lock);
    printf(">>>>>>>> pid= %ld \n", syscall(SYS_gettid));

    printf("sorted vec=[");
    for (int i = 0; i < n; i++) {
        printf("%.20f ", vec[i]);
    }
    printf("]\n");

    printf("map[sorted]=old position: map=[");
    for (int i = 0; i < n; i++) {
        printf("%d ", map[i]);
    }
    printf("]\n");
    printf("<<<<<<<<< pid= %ld \n", syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif // DEBUG_INSERTION_ABS_SORT
}

// use normalized vec instead of a unit vector whose coordinate in vec
// is largest, then in decreasing order of the absolute values of their
// coordinates, use corresponding unit vectors. Observe the obtained
// base is normalized, but likely not orthogonal.
// base layout is column major, with normalized vec as first column
int complete_into_base_and_normalize(double* vec, double* base, int n)
{
// #ifdef DEBUG_COMPLETE_INTO_BASE_AND_NORMALIZE
#ifdef DEBUG
    pthread_mutex_lock(&lock);
    printf(">>>>>>>> pid= %ld, complete \n", syscall(SYS_gettid));
    printf("complete_into_base with vec\nvec=[");
    for (int i = 0; i < n; i++) {
        printf("%.20f ", vec[i]);
    }
    printf("]\n");
    printf("<<<<<<<<< pid= %ld \n", syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif // DEBUG_COMPLETE_INTO_BASE_AND_NORMALIZE

    memset(base, 0, sizeof(double) * n * n);

    // just place normalized vec as first vector
    double norm = cblas_dnrm2(n, vec, 1); // two norm of vec
    if (norm < OUTWARD_ROUND) {
        pthread_mutex_lock(&lock);
        printf(">>>>>>>> pid= %ld, complete \n", syscall(SYS_gettid));
        printf("too small vector to be completed into a base!\n");
        printf("<<<<<<<<< pid= %ld \n", syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);

        for(int diag= 0; diag < n; diag++) {
            base[diag * n + diag] = 1.0;
        }
        return 0;
    }

    // we sort vec in increasing order.
    // keep dimensions correspondance in mapping
    int mapping[n];
    for (int i = 0; i < n; i++) {
        mapping[i] = i;
    }
    insertion_abs_sort(vec, mapping, n);

    // add, in the order of their decreasing contrbution to
    // vec, one unit vector at a time (but skip the first column
    // where normalized vec will be copied)
    for (int col = 1; col < n; col++) {
        for (int row = 0; row < n; row++) {
            base[col * n + row] = (row == mapping[n - 1 - col] ? 1 : 0);
        }
    }

    // inserts normalized vec as first column in base.
    // vec is first. Chosen instead of unit vector giving largest vec
    // coordinate
    // cblas_daxpy(n, a=1/norm, x=vec, incx=1, y=base, incy=n) does y:= ax+y
    cblas_daxpy(n, 1 / norm, vec, 1, base, 1);


// #ifdef DEBUG_COMPLETE_INTO_BASE_AND_NORMALIZE
#ifdef DEBUG
    pthread_mutex_lock(&lock);
    printf(">>>>>>>> pid= %ld, complete \n", syscall(SYS_gettid));
    printf("sorted base with normalized vec as first column:\n");
    for (int row = 0; row < n; row++) {
        printf("[");
        for (int col = 0; col < n; col++) {
            printf("%.20f ", base[col * n + row]);
        }
        printf("]\n");
    }
    printf("]\n");
    printf("<<<<<<<<< pid= %ld \n", syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif // DEBUG_COMPLETE_INTO_BASE_AND_NORMALIZE
    return 0;
}

// Apply Gram Schmidt on a normalized (precondition), but not necessarily
// orthogonal base. The obtained base is then inversed.
lapack_int gram_schmidt_and_inverse(double base[], double inv[], int n)
{
// #ifdef DEBUG_GRAM_SCHMIDT_AND_INVERSE
#ifdef DEBUG
    pthread_mutex_lock(&lock);
    printf(">>>>>>>> pid= %ld, Gram Schmidt \n", syscall(SYS_gettid));
    printf("GSI input base: \n");
    for (int i = 0; i < n * n; i++) {
        if ((i % n) == 0)
            putchar('\n');
        printf("%12.20f ", base[(i / n) + (i % n) * n]);
    }
    putchar('\n');
    printf("<<<<<<<<< pid= %ld \n", syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif // DEBUG_GRAM_SCHMIDT_AND_INVERSE

    // This is the Gram Schmidt procedure
    // Observe all vectors in base are already normalized
    for (int v = 0; v < n; v++) {
        // cblas_dcopy(n, x, incx, y, incy) does y := x
        for (int u = 0; u < v; u++) {
            double vdotu = cblas_ddot(n, base + n * v, 1, base + n * u, 1);
            // cblas_daxpy(n, a, x, incx, y, incy) does y:= ax+y
            cblas_daxpy(n, -vdotu, base + n * u, 1, base + n * v, 1);
        }
        double vnorm = cblas_dnrm2(n, base + n * v, 1);
        cblas_dscal(n, 1 / vnorm, base + n * v, 1);
    }

    memcpy(inv, base, sizeof(double) * n * n);

    lapack_int ipiv[n];
    lapack_int ret = LAPACKE_dgetrf(LAPACK_ROW_MAJOR, n, n, inv, n, ipiv);
    if (ret != 0) {
        pthread_mutex_lock(&lock);
        printf(">>>>>>>> pid=%ld, Gram Schmidt \n", syscall(SYS_gettid));
        printf("Error in LAPACKE_dgetrf\n");
        printf("<<<<<<<< pid=%ld \n", syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);
        return ret;
    }
    ret = LAPACKE_dgetri(LAPACK_ROW_MAJOR, n, inv, n, ipiv);
    if (ret != 0) {
        pthread_mutex_lock(&lock);
        printf(">>>>>>>> pid=%ld, Gram Schmidt \n", syscall(SYS_gettid));
        printf("Error in LAPACKE_dgetri\n");
        printf("<<<<<<<< pid=%ld \n", syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);
        return ret;
    }

// #ifdef DEBUG_GRAM_SCHMIDT_AND_INVERSE
#ifdef DEBUG
    pthread_mutex_lock(&lock);
    printf(">>>>>>>> pid= %ld, Gram Schmidt \n", syscall(SYS_gettid));
    printf("GSI output base: \n");
    for (int i = 0; i < n * n; i++) {
        if ((i % n) == 0)
            putchar('\n');
        printf("%12.20f ", base[(i / n) + (i % n) * n]);
    }
    putchar('\n');

    printf("GSI output inv: \n");
    for (int i = 0; i < n * n; i++) {
        if ((i % n) == 0)
            putchar('\n');
        printf("%12.20f ", inv[(i / n) + (i % n) * n]);
    }
    putchar('\n');

    double prod[n * n];
    // b is 0.  memset(prod,0,sizeof(double)*n*n);
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, n, n, n, 1, base, n, inv, n, 0, prod, n);

    printf("GSI resulting prod=base * inv: \n");
    for (int i = 0; i < n * n; i++) {
        if ((i % n) == 0)
            putchar('\n');
        printf("%12.20f ", prod[(i / n) + (i % n) * n]);
    }
    putchar('\n');
    printf("<<<<<<<<< pid= %ld \n", syscall(SYS_gettid));

    pthread_mutex_unlock(&lock);
#endif // DEBUG_GRAM_SCHMIDT_AND_INVERSE
    return ret;
}

lapack_int construct_new_base(int const input_size, struct DMatrix *new_base, struct DMatrix *new_base_inv)
{
    // Initially assume:
    //  - That new_base contains the lower and upper bounds of the neuron we want to split on.
    //  - row(new_base) == input_size, this will not change.
    //  - col(new_base) < input_size, this will change as we grow new_base into a base.
    //      - However, the data vector of new_base has size input_size * input_size.
    //  - new_base_inv contains nothing

    double data_l_matrix[input_size * input_size];
    struct DMatrix L = {
        .data = data_l_matrix,
        .row = new_base->row,
        .col = new_base->row
    };
    double data_u_matrix[input_size * input_size];
    struct DMatrix U = {
        .data = data_u_matrix,
        .row = new_base->row,
        .col = new_base->col
    };

    lapack_int info = DMatrix_LU_decomposition(new_base, &L, &U);
    if (info != 0) {
        printf("LU Decomposition error %d\n", info);
        return info;
    }
    int urank = DMatrix_rank(&U);

#ifdef DEBUG
    printf("== Original base ======================\n");
    printDMatrix(new_base);
    printf("== L matrix ===========================\n");
    printDMatrix(&L);
    printf("== U matrix ===========================\n");
    printDMatrix(&U);
#endif

    // If the rank of the matrix is not 2 initially, with only the lower and upper bound equations
    // as columns, this means that they are not linearly independet and we cannot construct a base
    // from them.
    if (urank != 2) {
        printf("Lower and upper bound of neuron not linearly independent, exiting.\n");
        exit(1);
    }

    // Generate vectors to propose for base.
    // Identity matrix, columns are standard unit vectors in space.
    // We should investigate if there is a need to use other vectors than the unit vectors.
    double prop_mat_data[input_size * input_size];
    memset(prop_mat_data, 0.0, sizeof(double) * input_size * input_size);
    for (int i = 0; i < input_size; i++)
        prop_mat_data[i * input_size + i] = 1.0;
    struct DMatrix proposal_mat = {
        .data = prop_mat_data,
        .row = input_size,
        .col = input_size
    };
    int try_vec_idx = 0;

    // Keep adding vectors until we have a square matrix of linearly independent vectors, i.e., a base.
    // We iterate until we have added enough columns (with vectors to new_base for it to be a base.
    // We only add a vector if it linearly independent from the previously added vectors.
    // The other condition is that we have run out of vectors to try to add to new_base,
    // in this case we need to abort.
    while (new_base->col < input_size && try_vec_idx < proposal_mat.col) {
        memset(L.data, 0.0, sizeof(double) * input_size * input_size);
        memset(U.data, 0.0, sizeof(double) * input_size * input_size);

        // Copy the 'try_vec_idx'-th column from proposal_mat into the newly added column of new_base
        new_base->col += 1;
        for (int r = 0; r < new_base->row; r++) {
            new_base->data[(new_base->col - 1) * new_base->row + r] =
                proposal_mat.data[try_vec_idx * proposal_mat.row + r];
        }
        try_vec_idx += 1; // We need to increment this to try adding new columns in future iterations
        U.col = new_base->col;

        info = DMatrix_LU_decomposition(new_base, &L, &U);
        if (info != 0) {
            printf("LU Decomposition error %d\n", info);
            return info;
        }
        urank = DMatrix_rank(&U);
        // Vectors are not linearly independent
        if (urank != new_base->col) {
            // The vector we just added should not be used, restore new_base to its previous state
            for (int r = 0; r < new_base->row; r++)
                new_base->data[(new_base->col - 1) * new_base->row + r] = 0.0;
            new_base->col -= 1;
        }
    }

    // We have tried adding all proposed vectors but not constructed a base
    if (try_vec_idx == proposal_mat.col && new_base->col != input_size) {
        printf("No base constructed.\n");
        return -1;
    }

    info = DMatrix_inverse(new_base, new_base_inv);
    if (info != 0) {
        printf("Matrix inverse error %d\n", info);
        return info;
    }

#ifdef DEBUG
    printf("== New base ===========================\n");
    printDMatrix(new_base);
    printf("== New base inverse ===================\n");
    printDMatrix(new_base_inv);
#endif

    return info;
}

void print_activation_vector(struct NNet *nnet, int *activation)
{
    for(int layer = 0; layer < nnet->numLayers - 1; layer++) {
        for(int node = 0; node < nnet->layerSizes[layer + 1]; node++) {
            printf("act[n=%d/l=%d]=%d, ", node, layer + 1, activation[node + layer * nnet->maxLayerSize]);
        }
        printf("\n");
    }

}

void print_pure_hybrid(struct NNet *nnet, int *activation, int *activation_new)
{
    int active_hybrid = 0, inactive_hybrid = 0, hybrid_hybrid = 0;
    for(int layer = 0; layer < nnet->numLayers - 1; layer++) {
        for(int node = 0; node < nnet->layerSizes[layer + 1]; node++) {
            if (activation_new[node + layer * nnet->maxLayerSize] == 1) {
                if (activation[node + layer * nnet->maxLayerSize] == 0) {
                    inactive_hybrid++;
                } else if (activation[node + layer * nnet->maxLayerSize] == 1) {
                    hybrid_hybrid++;
                } else if (activation[node + layer * nnet->maxLayerSize] == 2) {
                    active_hybrid++;
                }
            }
        }
    }
    printf("Active hybrid: %d, Inactive hybrid: %d, Hybrid hybrid: %d\n", active_hybrid, inactive_hybrid, hybrid_hybrid);
}

void print_activation_info(struct NNet *nnet, int *activation)
{
    int alive = 0, dead = 0, hybrid = 0, total = 0;
    for(int layer = 0; layer < nnet->numLayers - 1; layer++) {
        for(int node = 0; node < nnet->layerSizes[layer + 1]; node++) {
            total++;
            if (activation[node + layer * nnet->maxLayerSize] == 0) {
                dead++;
            } else if (activation[node + layer * nnet->maxLayerSize] == 1) {
                hybrid++;
            } else if (activation[node + layer * nnet->maxLayerSize] == 2) {
                alive++;
            }
        }
    }
    printf("Total: %d, dead: %d, hybrid: %d, alive: %d\n", total, dead, hybrid, alive);
}

int construct_input_in_old(
        struct DInterval *input_in_old,
        struct DInterval *input_in_current,
        struct DMatrix *current_base_in_old,
        struct DMatrix *current_origin_in_old,
        struct CStrList *pcstrlist,
        int const input_size)
{
    static int cnt = 0;
    GRBmodel *model = NULL;
    GRBenv *env = NULL;
    char modelname[] = "models/model_input_in_old.lp";
    construct_common_model(&model, &env, modelname, input_size);

    int error = 0;
    int lp_var_index[input_size];
    for (int i = 0; i < input_size; i++)
        lp_var_index[i] = i;

    // pcstrlist contains the original bounds and split bounds
    struct CStrList *list = pcstrlist;
    while (list) {
        char dir = list->current.direction;
        assert(dir == GRB_GREATER_EQUAL || dir == GRB_LESS_EQUAL || dir == GRB_EQUAL);

        error = GRBaddconstr(model, input_size, lp_var_index, list->current.coeffs, dir, list->current.d, "");
        if (error)
            quit_and_print_gurobi_error(env);

        list = list->next;
    }
    GRBupdatemodel(model);
    cnt++;

    double obj[input_size];
    memset(obj, 0, sizeof(double) * input_size);
    double objval = 0.0;
    int optim_val_error = 0;
    for (int i = 0; i < input_size; i++) {
        obj[i] = 1;

        pthread_mutex_lock(&lock);
        input_gurobi_count++;
        pthread_mutex_unlock(&lock);
        optim_val_error = get_optimal_val(model, env, obj, input_size, GRB_MINIMIZE, &objval);
        if (!optim_val_error) {
            input_in_old->lower_dmatrix->data[i] = objval;
        } else {
            pthread_mutex_lock(&lock);
            char name[100];
            sprintf(
                    name,
                    "models/ciin-%d-%ld.lp",
                    cnt, syscall(SYS_gettid));
            GRBwrite(model, name);
            printf(">>>>>>> pid=%ld construct_input_in_old\n", syscall(SYS_gettid));
            printf("Non-optimal model when constructing input in old, writing to: %s\n", name);
            printf("<<<<<<< pid=%ld construct_input_in_old\n", syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
            return 1;
        }

        pthread_mutex_lock(&lock);
        input_gurobi_count++;
        pthread_mutex_unlock(&lock);
        optim_val_error = get_optimal_val(model, env, obj, input_size, GRB_MAXIMIZE, &objval);
        if (!optim_val_error) {
            input_in_old->upper_dmatrix->data[i] = objval;
        } else {
            pthread_mutex_lock(&lock);
            char name[100];
            sprintf(
                    name,
                    "models/ciin-%d-%ld.lp",
                    cnt, syscall(SYS_gettid));
            GRBwrite(model, name);
            printf(">>>>>>> pid=%ld construct_input_in_old\n", syscall(SYS_gettid));
            printf("Non-optimal model when constructing input in old, writing to: %s\n", name);
            printf("<<<<<<< pid=%ld construct_input_in_old\n", syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
            return 1;
        }

        obj[i] = 0;
    }

    // Free model and environment used
    error = GRBfreemodel(model);
    if (error)
        quit_and_print_gurobi_error(env);
    GRBfreeenv(env);

    return 0;
}

int find_worst_neuron_affecting_target(
        struct NNet *nnet,
        struct IntervalVals **neuron_intervals,
        int const target_layer,
        int const target_neuron,
        struct NeuronInfoList *forbidden_neurons,
        int *l,
        int *n)
{
    int const max_layer_size = nnet->maxLayerSize;

    double grad_upper[max_layer_size];
    double grad_lower[max_layer_size];
    double ograd_upper[max_layer_size];
    double ograd_lower[max_layer_size];

    memcpy(grad_upper, nnet->dmatrix[target_layer][0][target_neuron], sizeof(double)*nnet->layerSizes[target_layer]);
    memcpy(grad_lower, nnet->dmatrix[target_layer][0][target_neuron], sizeof(double)*nnet->layerSizes[target_layer]);

    double curr_worst = -1.0;

    // Start going back from layer before target layer.
    for(int layer = target_layer - 1; layer >= 0; layer--) {
        double **weights = nnet->dmatrix[layer][0];
        memset(ograd_upper, 0, sizeof(double)*max_layer_size);
        memset(ograd_lower, 0, sizeof(double)*max_layer_size);

        for(int dst = 0; dst < nnet->layerSizes[layer + 1]; dst++) {
            int const is_hybrid =
                (neuron_intervals[dst + (layer + 1) * max_layer_size]->lo < 0) &&
                (neuron_intervals[dst + (layer + 1) * max_layer_size]->up > 0);
            int const is_dead = neuron_intervals[dst + (layer + 1) * max_layer_size]->up < 0;
            if(is_dead){
                grad_upper[dst] = grad_lower[dst] = 0;
            } else if (is_hybrid) {
                grad_upper[dst] = (grad_upper[dst] > 0) ? grad_upper[dst] : 0;
                grad_lower[dst] = (grad_lower[dst] < 0) ? grad_lower[dst] : 0;
            }

            double range =
                neuron_intervals[dst + (layer + 1) * max_layer_size]->up -
                neuron_intervals[dst + (layer + 1) * max_layer_size]->lo;
            double influence = (grad_upper[dst] > -grad_lower[dst] ? grad_upper[dst] : -grad_lower[dst]);
            double smear = range * influence;

            if (smear > curr_worst && is_hybrid) {
                struct NeuronInfoList *nil = forbidden_neurons;
                int neuron_ok = 1;
                while (nil->next != NULL) {
                    int const prev_forced_linear = (nil->ni->state == ACTIVE || nil->ni->state == INACTIVE);
                    // The condition means that we have previously used this neuron to split the problem
                    // AND in the current subproblem the neuron has been forced to be active or inactive.
                    // The idea is that we can split on a neuron again that we did not force to be linear.
                    if (layer == nil->ni->l && dst == nil->ni->n && prev_forced_linear) {
                        neuron_ok = 0;
                        // If we find that the current neuron is not ok, then we break
                        break;
                    }
                    nil = nil->next;
                }
                if (neuron_ok) {
                    curr_worst = smear;
                    *l = layer;
                    *n = dst;
                }
            }

            for (int src = 0; src < nnet->layerSizes[layer];src++) {
                if (weights[dst][src] >= 0) {
                    ograd_upper[src] += weights[dst][src]*grad_upper[dst];
                    ograd_lower[src] += weights[dst][src]*grad_lower[dst];
                } else {
                    ograd_upper[src] += weights[dst][src]*grad_lower[dst];
                    ograd_lower[src] += weights[dst][src]*grad_upper[dst];
                }
            }
        }

        memcpy(grad_upper,ograd_upper,sizeof(double)*max_layer_size);
        memcpy(grad_lower,ograd_lower,sizeof(double)*max_layer_size);
    }

    // We didn't find any hybrid ReLU
    if (curr_worst < 0) {
        return 0;
    } else {
        return 1;
    }
}

void count_neuron_activations(
        struct NNet *nnet,
        enum NeuronState *activation_history,
        int *active,
        int *inactive,
        int *hybrid)
{
    *active = 0;
    *inactive = 0;
    *hybrid = 0;
    for(int layer = 0; layer < nnet->numLayers - 1; layer++) {
        for(int node = 0; node < nnet->layerSizes[layer + 1]; node++) {
            if (activation_history[node + layer * nnet->maxLayerSize] == ACTIVE) {
                (*active)++;
            } else if (activation_history[node + layer * nnet->maxLayerSize] == INACTIVE) {
                (*inactive)++;
            } else if (activation_history[node + layer * nnet->maxLayerSize] == HYBRID) {
                (*hybrid)++;
            }
        }
    }
}

int encode_nn_and_solve(
        struct NNet *nnet,
        struct CStrList *pcstrlist,
        struct IntervalVals **neuron_intervals,

        unsigned long const parent_tid,
        int const depth,
        enum NeuronState const current_split_state,

        struct DInterval *output)
{
#ifdef DBG_ENCODE_NN
    printf(">>>>>>> pid=%ld encode_nn_and_solve\n", syscall(SYS_gettid));
#endif
    int nv = 0;
    for (int layer = 0; layer < nnet->numLayers - 1; layer++) {
        nv += nnet->layerSizes[layer + 1] * 2;

    }
    int const input_size = nnet->inputSize;
    int const output_size = nnet->outputSize;
    int const num_vars = nv + input_size + output_size;

    GRBmodel *model = NULL;
    GRBenv *env = NULL;
    char modelname[] = "models/nn.lp";
    construct_common_model(&model, &env, modelname, num_vars);

    int error = 0;

    // Encode collected constraints from pcstrlist
    {
        int *input_var_index = (int*) malloc(sizeof(int) * input_size);
        for (int i = 0; i < input_size; i++)
            input_var_index[i] = i;
        // pcstrlist contains the original bounds and split bounds
        struct CStrList *list = pcstrlist;
        while (list) {
            char dir = list->current.direction;
            assert(dir == GRB_GREATER_EQUAL || dir == GRB_LESS_EQUAL || dir == GRB_EQUAL);
            error = GRBaddconstr(model, input_size, input_var_index, list->current.coeffs, dir, list->current.d, "");
            if (error)
                quit_and_print_gurobi_error(env);
            list = list->next;
        }
        free(input_var_index);
    }

    // Encode input bounds
    {
        int input_idx[1];
        double coeff[1];
        coeff[0] = 1.0;
        for (int i = 0; i < input_size; i++) {
            input_idx[0] = i;
            error = GRBaddconstr(model, 1, input_idx, coeff, GRB_GREATER_EQUAL, neuron_intervals[i]->lo, "");
            if (error)
                quit_and_print_gurobi_error(env);
            error = GRBaddconstr(model, 1, input_idx, coeff, GRB_LESS_EQUAL, neuron_intervals[i]->up, "");
            if (error)
                quit_and_print_gurobi_error(env);
        }
    }

    int var_idx_begin = 0;
    int var_idx_end = input_size;
    for (int layer = 0; layer < nnet->numLayers; layer++) {
        // weights between src and dst layers
        // E.g., when layer = 0 then src layer is input layer
        // and dst is the first hidden layer
        struct DMatrix *w = &nnet->weights[layer];
        struct DMatrix *b = &nnet->bias[layer];
        int const src_layer_size = nnet->layerSizes[layer];
        int const dst_layer_size = nnet->layerSizes[layer + 1];
#ifdef DBG_ENCODE_NN
        printf("---------------------\n");
        printf("layer=%d, scr_layer_size=%d, dst_layer_size=%d\n", layer, src_layer_size, dst_layer_size);
        printf("var_idx_begin=%d, var_idx_end=%d\n", var_idx_begin, var_idx_end);
        printDMatrix(w);
        printDMatrix(b);
#endif

        // The first src_layer_size positions will encode the
        // coeffiecients from the src layer. We need one extra position
        // to encode the target neuron in the dst layer.
        double coeffs[src_layer_size + 1];
        int idxs[src_layer_size + 1];
        for (int idx = 0; idx < src_layer_size; idx++)
            idxs[idx] = var_idx_begin + idx;
        coeffs[src_layer_size] = -1; // To encode x + y = z we add the constraint x + y - z = 0
        for (int node = 0; node < dst_layer_size; node++) {
            memcpy(coeffs, w->data + (node * src_layer_size), sizeof(double) * src_layer_size);
            idxs[src_layer_size] = var_idx_end + node;

#ifdef DBG_ENCODE_NN
            printf("[");
            for (int k = 0; k < src_layer_size + 1; k++) {
                printf("%d ", idxs[k]);
            }
            printf("]\n");
            printf("[");
            for (int k = 0; k < src_layer_size + 1; k++) {
                printf("%f ", coeffs[k]);
            }
            printf("]\n");
#endif

            // error = GRBaddconstr(model, src_layer_size + 1, idxs, coeffs, GRB_EQUAL, 0.0, "");
            error = GRBaddconstr(model, src_layer_size + 1, idxs, coeffs, GRB_EQUAL, -b->data[node], "");
            if (error)
                quit_and_print_gurobi_error(env);
        }

        // Encode the ReLU activations
        if (layer < nnet->numLayers - 1) {
#ifdef DBG_ENCODE_NN
            printf("Encode ReLUs!\n");
#endif
            for (int n = 0; n < dst_layer_size; n++) {
                double const l = neuron_intervals[nnet->maxLayerSize * (layer + 1) + n]->lo;
                double const u = neuron_intervals[nnet->maxLayerSize * (layer + 1) + n]->up;
                int const pre_relu_idx = var_idx_end + n;
                int const post_relu_idx = var_idx_end + dst_layer_size + n;
                if (l < 0 && 0 < u) {

#ifdef DBG_ENCODE_NN
                    printf("(Hybrid): Pre: %d, post: %d\n", pre_relu_idx, post_relu_idx);
#endif
                    // ReLU(x) >= 0
                    {
                        int idx[1]; idx[0] = post_relu_idx;
                        double coeff[1]; coeff[0] = 1.0;
                        error = GRBaddconstr(model, 1, idx, coeff, GRB_GREATER_EQUAL, 0.0, "");
                        if (error)
                            quit_and_print_gurobi_error(env);
                    }

                    // ReLU(x) >= x <=> ReLU(x) - x >= 0 <=> -x + ReLU(x) >= 0
                    {
                        int idx[2]; idx[0] = pre_relu_idx; idx[1] = post_relu_idx;
                        double coeff[2]; coeff[0] = -1.0; coeff[1] = 1.0;
                        error = GRBaddconstr(model, 2, idx, coeff, GRB_GREATER_EQUAL, 0.0, "");
                        if (error)
                            quit_and_print_gurobi_error(env);
                    }

                    // ReLU(x) <= x * u / (u - l) - ul / (u - l) <=>
                    // ReLU(x) - x * u / (u - l) <= -ul / (u - l) <=>
                    // -x * u / (u - l) + ReLU(x) <= -ul / (u - l)
                    {
                        double const slope = u / (u - l);
                        double const offset = -(u * l) / (u - l);
                        int idx[2]; idx[0] = pre_relu_idx; idx[1] = post_relu_idx;
                        double coeff[2]; coeff[0] = -slope; coeff[1] = 1.0;
                        error = GRBaddconstr(model, 2, idx, coeff, GRB_LESS_EQUAL, offset, "");
                        if (error)
                            quit_and_print_gurobi_error(env);
                    }
                } else if (u <= 0) {
#ifdef DBG_ENCODE_NN
                    printf("(Inactive): Pre: %d, post: %d\n", pre_relu_idx, post_relu_idx);
#endif
                    // ReLU(x) = 0
                    {
                        int idx[1]; idx[0] = post_relu_idx;
                        double coeff[1]; coeff[0] = 1.0;
                        error = GRBaddconstr(model, 1, idx, coeff, GRB_EQUAL, 0.0, "");
                        if (error)
                            quit_and_print_gurobi_error(env);
                    }
                } else if (l >= 0) {
#ifdef DBG_ENCODE_NN
                    printf("(Active): Pre: %d, post: %d\n", pre_relu_idx, post_relu_idx);
#endif
                    // ReLU(x) = x
                    {
                        int idx[2]; idx[0] = pre_relu_idx; idx[1] = post_relu_idx;
                        double coeff[2]; coeff[0] = -1.0; coeff[1] = 1.0;
                        error = GRBaddconstr(model, 2, idx, coeff, GRB_EQUAL, 0.0, "");
                        if (error)
                            quit_and_print_gurobi_error(env);
                    }

                }
            }
        }

#ifdef DBG_ENCODE_NN
        // This part will solve the bounds for each neuron in the current layer
        char mname[100];
        sprintf(mname, "models/nn-layer-%d.lp", layer);
        GRBwrite(model, mname);
        GRBupdatemodel(model);
        for (int n = 0; n < dst_layer_size; n++) {
            int const post_relu_idx = var_idx_end + n + (layer < nnet->numLayers - 1 ? dst_layer_size : 0);
            double coeff[num_vars];
            memset(coeff, 0, sizeof(double) * num_vars); // this must be malloc'd later
            coeff[post_relu_idx] = 1.0;
            double val1 = 1337.7331;
            double val2 = 1337.7331;
            error = get_optimal_val(model, env, coeff, num_vars, GRB_MINIMIZE, &val1);
            error = get_optimal_val(model, env, coeff, num_vars, GRB_MAXIMIZE, &val2);
            printf("%d (l=%d, n=%d) : [%f, %f]\n", post_relu_idx, layer, n, val1, val2);
        }
#endif

        var_idx_begin = var_idx_end + dst_layer_size;
        var_idx_end = var_idx_begin + dst_layer_size;
    }

#ifdef DBG_ENCODE_NN
    GRBwrite(model, modelname);
#endif
    GRBupdatemodel(model);

    var_idx_begin = num_vars - output_size;
    var_idx_end = num_vars;

#ifdef DBG_ENCODE_NN_WRITE_FILES
    char mname[256];
    char state = 'F';
    if (current_split_state == ACTIVE)
        state = 'A';
    else if (current_split_state == INACTIVE)
        state = 'D';
    else if (current_split_state == HYBRID)
        state = 'H';
    sprintf(
            mname,
            "models/nn-depth_%d-state_%c-pid_%lu-parent_tid_%lu.lp",
            depth, state, (unsigned long) syscall(SYS_gettid), parent_tid);
    pthread_mutex_lock(&lock);
    GRBwrite(model, mname);
    pthread_mutex_unlock(&lock);
#endif

    int ret = 0;
    double *coeff = (double*) malloc(sizeof(double) * num_vars);
    memset(coeff, 0, sizeof(double) * num_vars);
    int output_idx = 0;
    for (int o = var_idx_begin; o < var_idx_end; o++) {
        coeff[o] = 1.0;

        double val1 = 0;
        double val2 = 0;
        pthread_mutex_lock(&lock);
        gurobi_count++;
        pthread_mutex_unlock(&lock);
        error = get_optimal_val(model, env, coeff, num_vars, GRB_MINIMIZE, &val1);
        if (error) {
            ret = 1;
        }
        pthread_mutex_lock(&lock);
        gurobi_count++;
        pthread_mutex_unlock(&lock);
        error = get_optimal_val(model, env, coeff, num_vars, GRB_MAXIMIZE, &val2);
        if (error) {
            ret = 1;
        }
#ifdef DBG_ENCODE_NN
        printf("%d : [%f, %f]\n", o, val1, val2);
#endif


        if (!error) {
            if (output->lower_dmatrix->data[output_idx] < val1) {
                output->lower_dmatrix->data[output_idx] = val1;
            }
            if (output->upper_dmatrix->data[output_idx] > val2) {
                output->upper_dmatrix->data[output_idx] = val2;
            }
        }

        output_idx++;
        coeff[o] = 0.0;
    }
    free(coeff);

    // Free model and environment used
    error = GRBfreemodel(model);
    if (error)
        quit_and_print_gurobi_error(env);
    GRBfreeenv(env);

#ifdef DBG_ENCODE_NN
    printf("<<<<<<< pid=%ld encode_nn_and_solve\n", syscall(SYS_gettid));
#endif
    return ret;
}

void check_on_relu(
        struct NNet *nnet,
        struct DMatrix *current_base_in_old,
        struct DMatrix *current_origin_in_old,
        struct DInterval *input_in_current,
        struct DInterval *output,
        struct CStrList* pcstrlist,

        int const num_dims_allowed,
        int *dims_used,

        unsigned long const parent_tid,
        int const depth,
        int const prev_split_l,
        int const prev_split_n,

        struct NeuronInfoList *prev_neurons,
        enum NeuronState *activation_history,

        struct IntervalVals **neuron_intervals)
{
    pthread_mutex_lock(&lock);
    if (adv_found) {
        pthread_mutex_unlock(&lock);
        return;
    }
    pthread_mutex_unlock(&lock);

    // Find tight inputs in original base and check for adversary in midpoint
    int const input_size = nnet->inputSize;
    int const output_size = nnet->outputSize;
    double *data_input_in_old_lower = (double*) malloc(sizeof(double) * input_size);
    double *data_input_in_old_upper = (double*) malloc(sizeof(double) * input_size);
    struct DInterval input_in_old = {
        .lower_dmatrix = &(struct DMatrix){data_input_in_old_lower, input_size, 1},
        .upper_dmatrix = &(struct DMatrix){data_input_in_old_upper, input_size, 1}
    };
    int ciin_err = construct_input_in_old(
        &input_in_old,
        input_in_current,
        current_base_in_old,
        current_origin_in_old,
        pcstrlist,
        input_size);
    if (ciin_err) {
        // This should not happen. If it happens it means that we accidently started a subproblem that
        // has a bad input region. This issue should be captured when computing the bounds for the
        // subproblems in split_relu_3way. If it is encountered here it means that an invalid
        // subproblem was started.
        pthread_mutex_lock(&lock);
        printf(">>>>>>> depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
        printf("Original input region not included in new base...\n");
        printf("<<<<<<< depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);
        assert(0); // Leaving this for now
        return;
    }
    // Check mid-point of input in old if it is an adversarial input
    double data_adv_test[input_size];
    memset(data_adv_test, 0.0, sizeof(double) * input_size);
    struct DMatrix adv_test = {data_adv_test, input_size, 1};
    for (int k = 0; k < input_size; k++) {
        double l = input_in_old.lower_dmatrix->data[k];
        double u = input_in_old.upper_dmatrix->data[k];
        double m = (l + u) / 2.0;
        data_adv_test[k] = m;
    }
#ifdef DBG_CHK_ADV_TEST
    pthread_mutex_lock(&lock);
    printf(">>>>>>> depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
    printf("Checking if adversarial input (in old base) with:\n");
    printDMatrix(&adv_test);
    printf("<<<<<<< depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif
    if (is_concrete_adv(nnet, &adv_test)) {
        if (!csv_print) {
            pthread_mutex_lock(&lock);
            printf("Found adverserial!\n");
            pthread_mutex_unlock(&lock);
        }
        return;
    }

    // Tighten best intervals with input_in_old
    for (int k = 0; k < input_size; k++) {
        if (neuron_intervals[k]->lo < input_in_old.lower_dmatrix->data[k]) {
            neuron_intervals[k]->lo = input_in_old.lower_dmatrix->data[k];
        }
        if (neuron_intervals[k]->up > input_in_old.upper_dmatrix->data[k]) {
            neuron_intervals[k]->up = input_in_old.upper_dmatrix->data[k];
        }
    }

#ifdef CHK_COMMON_DBG
    pthread_mutex_lock(&lock);
    printf(">>>>>>> depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
    printf("input in current: \n");
    printf("lower ");  printDMatrix(input_in_current->lower_dmatrix);
    printf("upper ");  printDMatrix(input_in_current->upper_dmatrix);
    printf("input in old: \n");
    printf("lower ");  printDMatrix(input_in_old.lower_dmatrix);
    printf("upper ");  printDMatrix(input_in_old.upper_dmatrix);
    printf("current base in old: \n");
    printDMatrix(current_base_in_old);
    printf("current origin in old: \n");
    printDMatrix(current_origin_in_old);
    printf("output BEFORE forward strengthening at depth %d: \n", depth);
    printf("lower ");  printDMatrix(output->lower_dmatrix);
    printf("upper ");  printDMatrix(output->upper_dmatrix);
    printf("<<<<<<< depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif

    int active_pre = 0, inactive_pre = 0, hybrid_pre = 0;
    count_neuron_activations(nnet, activation_history, &active_pre, &inactive_pre, &hybrid_pre);
    int const linear_pre = active_pre + inactive_pre;
    if (depth == 0) assert(active_pre == 0 && inactive_pre == 0 && hybrid_pre == 0);

    // Perform forward analysis
    // neuron_intervals will now contain the best known intervals for all neurons, including output
    // output structure is redundant I think?
    symbolic_forward_analysis(
            nnet,
            current_base_in_old,
            current_origin_in_old,
            input_in_current,

            &input_in_old, // Delete later...

            output,
            neuron_intervals,
            pcstrlist,

            prev_neurons,
            activation_history,

            0,
            NULL);

    int active_post = 0, inactive_post = 0, hybrid_post = 0;
    count_neuron_activations(nnet, activation_history, &active_post, &inactive_post, &hybrid_post);
    int const linear_post = active_post + inactive_post;
    int const total = active_post + inactive_post + hybrid_post;
    int const new_linear = linear_post - linear_pre;

    // Compute some stats for activations
    // This must be locked since we are modifying a global variables
    pthread_mutex_lock(&lock);
    enum NeuronState split_state = DEFAULT;
    if (depth > 0) {
        struct NeuronInfoList *nil = prev_neurons;
        if (nil->next != NULL) {
            split_state = nil->ni->state;
        }
        if (split_state == ACTIVE) {
            avg_lin_split_active =
                (avg_lin_split_active * active_splits + new_linear) / (active_splits + 1);
            active_splits++;
        } else if (split_state == INACTIVE) {
            avg_lin_split_inactive =
                (avg_lin_split_inactive * inactive_splits + new_linear) / (inactive_splits + 1);
            inactive_splits++;
        } else if (split_state == HYBRID) {
            avg_lin_split_hybrid =
                (avg_lin_split_hybrid * hybrid_splits + new_linear) / (hybrid_splits + 1);
            hybrid_splits++;
        }

        avg_linear_neurons_split =
            (avg_linear_neurons_split * split_num + new_linear) / (split_num + 1);
        split_num++;
    }
    pthread_mutex_unlock(&lock);

#ifdef CHK_COMMON_DBG
    pthread_mutex_lock(&lock);
    printf(">>>>>>> depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
    printf("Total ReLU-neurons: %d\n\tActive: %d\n\tInactive: %d\n\tTotal linear: %d\n\tHybrid: %d\n",
            total, active_post, inactive_post, linear_post, hybrid_post);
    printf("Split (state=%d) at depth=%d introduced %d new linear neurons!\n",
            split_state, depth, new_linear);
    printf("<<<<<<< depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif

#ifdef CHK_COMMON_DBG
    pthread_mutex_lock(&lock);
    printf(">>>>>>> depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
    if (prev_neurons->next != NULL) {
        // Small sanity check, delete later
        if (prev_split_l != prev_neurons->ni->l || prev_split_n != prev_neurons->ni->n) {
            printf("Error with prev neurons linked list implementation\n");
        }
        struct NeuronInfoList *nil = prev_neurons;
        while (nil->next != NULL) {
            int curr_split_l = nil->ni->l;
            int curr_split_n = nil->ni->n;
            enum NeuronState forced_state = nil->ni->state;
            char forced_state_print;
            if (forced_state == ACTIVE) {
                forced_state_print = 'A';
            } else if (forced_state == INACTIVE) {
                forced_state_print = 'D';
            } else if (forced_state == HYBRID) {
                forced_state_print = 'H';
            }
            printf("Activation of previous chosen neuron (l=%d, n=%d, s=%c): [%.20f, %.20f]\n",
                    curr_split_l, curr_split_n, forced_state_print,
                    neuron_intervals[nnet->maxLayerSize * (curr_split_l + 1) + curr_split_n]->lo,
                    neuron_intervals[nnet->maxLayerSize * (curr_split_l + 1) + curr_split_n]->up);
            printf("-----------------------------------------------------------------------------------------------\n");
            nil = nil->next;
        }
    }
    printf("output AFTER forward strengthening at depth %d: \n", depth);
    printf("lower "); printDMatrix(output->lower_dmatrix);
    printf("upper "); printDMatrix(output->upper_dmatrix);
    printf("<<<<<<< depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif

    // check_functions returns 1 if there is a possible problem despite over-approximations
    int robust = !check_functions(nnet, output);

    // Only makes sense to use this after splitting
    if (!robust && depth > 0) {
        double *data_identity_base = (double*) malloc(sizeof(double) * input_size * input_size);
        memset(data_identity_base, 0, sizeof(double) * input_size * input_size);
        for (int in = 0; in < input_size; in++) {
            data_identity_base[in + in*input_size] = 1.0;
        }
        struct DMatrix *identity_base = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        identity_base->data = data_identity_base;
        identity_base->row = input_size;
        identity_base->col = input_size;
        symbolic_forward_analysis(
                nnet,

                identity_base,

                current_origin_in_old,
                &input_in_old,

                &input_in_old, // Delete later...

                output,
                neuron_intervals,
                pcstrlist,

                prev_neurons,
                activation_history,

                0,
                NULL);
        free(data_identity_base);
        free(identity_base);
        robust = !check_functions(nnet, output);

#ifdef CHK_COMMON_DBG
        pthread_mutex_lock(&lock);
        printf(">>>>>>> depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
        printf("output AFTER forward analysis with identity base at depth %d: \n", depth);
        printf("lower "); printDMatrix(output->lower_dmatrix);
        printf("upper "); printDMatrix(output->upper_dmatrix);
        printf("<<<<<<< depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);
#endif
    }

    // Some other condition could be added, e.g., if depth exceeds a certain threshold.
    pthread_mutex_lock(&lock);
    // if (!robust && depth > total_avg_depth) {
    // if (!robust) {
    if (0) {
        pthread_mutex_unlock(&lock);

        int encode_infeasible = encode_nn_and_solve(
                nnet,
                pcstrlist,
                neuron_intervals,

                parent_tid,
                depth,
                prev_neurons->ni->state,

                output);

        if (encode_infeasible) {
            // BEGIN Investigate infeasible encode_nn_and_solve
            // pthread_mutex_lock(&lock);
            // exit_prog = depth;
            // g_parent_tid = parent_tid;
            // pthread_mutex_unlock(&lock);
            // return;
            // END Investigate infeasible encode_nn_and_solve
            robust = 1;
        } else {
            robust = !check_functions(nnet, output);
        }

        // BEGIN Investigate infeasible encode_nn_and_solve
        // pthread_mutex_lock(&lock);
        // if (exit_prog) {
        //     pthread_mutex_unlock(&lock);
        //     return;
        // }
        // pthread_mutex_unlock(&lock);
        // END Investigate infeasible encode_nn_and_solve

#ifdef CHK_COMMON_DBG
        pthread_mutex_lock(&lock);
        printf(">>>>>>> depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
        printf("output AFTER solving entire NN at depth %d: \n", depth);
        printf("lower "); printDMatrix(output->lower_dmatrix);
        printf("upper "); printDMatrix(output->upper_dmatrix);
        printf("<<<<<<< depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);
#endif
    } else {
        pthread_mutex_unlock(&lock);
    }

    pthread_mutex_lock(&lock);
    if (max_allowed_depth > 0 && depth >= max_allowed_depth && !robust) {
        uncertain_analysis = 1;
    }
    pthread_mutex_unlock(&lock);

    pthread_mutex_lock(&lock);
    int const target = nnet->target;
    double target_width = output->upper_dmatrix->data[target] - output->lower_dmatrix->data[target];
    avg_target_output_width = (avg_target_output_width * depth + target_width) / (depth + 1);
    pthread_mutex_unlock(&lock);

    pthread_mutex_lock(&lock);
    if (robust || uncertain_analysis) {

        // Print to create violin plots
        // printf("%d\n", depth);

        avg_depth -= avg_depth / AVG_WINDOW;
        avg_depth += depth / AVG_WINDOW;

        if (depth > max_depth) max_depth = depth;

        total_avg_depth =
            (total_avg_depth * (leaf_num + uncertain_leaf_num) + depth) / ((leaf_num + uncertain_leaf_num) + 1);

        if (robust) {
            avg_linear_neurons_robust = (avg_linear_neurons_robust * leaf_num + linear_post) / (leaf_num + 1);
        }
        if (robust) {
            leaf_num++;
        } else {
            uncertain_leaf_num++;
        }

        int total_dims_used = 0;
        for (int i = 0; i < input_size; i++) {
            if (dims_used[i]) {
                total_dims_used++;
            }
        }
        if (total_dims_used > max_dims_used_robust)
            max_dims_used_robust = total_dims_used;
        if (total_dims_used < min_dims_used_robust)
            min_dims_used_robust = total_dims_used;

#ifdef DEBUG
        if (robust) {
            printf("Showed robustness! depth: %d, avg_depth: %f, linear neurons: %d\n",
                    depth, avg_depth, linear_post);
        } else {
            printf("Uncertain analysis! depth: %d, avg_depth: %f, linear neurons: %d\n",
                    depth, avg_depth, linear_post);
        }
#endif
        pthread_mutex_unlock(&lock);
        return;
    }
    pthread_mutex_unlock(&lock);

    // An array of struct keeping information about ReLU neurons that are undesirable.
    // We can have at most num_layers - 1 such neurons, since we pick at most one per layer
    // and there are no relu activations in the final layer.
    // struct NeuronInfo *bad_neurons[nnet->numLayers - 1];
    struct NeuronInfo **bad_neurons = (struct NeuronInfo**) malloc(sizeof(struct NeuronInfo*) * (nnet->numLayers - 1));
    for (int i = 0; i < nnet->numLayers - 1; i++) {
        bad_neurons[i] = NULL;
    }
    int bn_idx = 0;
    int fwnat_ret = 1;
    int layer = -1, neuron = -1;
    int target_layer = nnet->numLayers - 1, target_neuron = nnet->target;
    while (fwnat_ret) {
        fwnat_ret =
            find_worst_neuron_affecting_target(
                nnet,
                neuron_intervals,
                target_layer,
                target_neuron,
                prev_neurons,
                &layer,
                &neuron);
        if (fwnat_ret) {
            bad_neurons[bn_idx] = allocate_NeuronInfo(input_size);
            bad_neurons[bn_idx]->l = layer;
            bad_neurons[bn_idx]->n = neuron;
            target_layer = layer;
            target_neuron = neuron;
            bn_idx++;
        }
    }
    // Second pass to find equations of "bad" neurons
    symbolic_forward_analysis(
            nnet,
            current_base_in_old,
            current_origin_in_old,
            input_in_current,

            &input_in_old, // Delete

            output,
            neuron_intervals,
            pcstrlist,

            prev_neurons,
            activation_history,

            1,
            bad_neurons);

#ifdef DBG_CHK_BAD_NEURONS
    pthread_mutex_lock(&lock);
    printf(">>>>>>> depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
    printf("== Bad Neurons ===========================================\n");
    for (int i = 0; i < nnet->numLayers - 1; i++) {
        if (bad_neurons[i] != NULL) {
            print_NeuronInfo(bad_neurons[i]);
            printf("----------------------------------------------------------\n");
        }
    }
    printf("==========================================================\n");
    printf("<<<<<<< depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif

    for (int i = 0; i < nnet->numLayers - 1; i++) { // Terminates often
    // for (int i = nnet->numLayers - 2; i >= 0; i--) { // Not always terminating?
        if (bad_neurons[i] != NULL) {

            // Check if the previous neuron is the same one
            // If it is, then we skip forward
            struct NeuronInfoList *nil = prev_neurons;
            if (nil->next != NULL) {
                if (bad_neurons[i]->l == nil->ni->l && bad_neurons[i]->n == nil->ni->n) {
#ifdef DBG_CHK_BAD_NEURONS
                    pthread_mutex_lock(&lock);
                    printf("NOT SPLITTING ON NEURON (l=%d, n=%d) AGAIN!\n", nil->ni->l, nil->ni->n);
                    pthread_mutex_unlock(&lock);
#endif
                    continue;
                }
            }
#ifdef DBG_CHK_BAD_NEURONS
            pthread_mutex_lock(&lock);
            printf(">>>>>>> depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
            printf("== Trying split with neuron ==============================\n");
            print_NeuronInfo(bad_neurons[i]);
            printf("<<<<<<< depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
#endif

            // Convert equation of neuron to be expressed in the original base
            // This is important since all linear constraints must be expressed
            // using the same variables.
            // What we are doing here is only multiplying the base matrix with the equation
            // (excluding bias) of the neuron.
            double data_neuron_in_old_lower[input_size];
            double data_neuron_in_old_upper[input_size];
            struct DInterval neuron_in_old = {
                .lower_dmatrix = &(struct DMatrix){data_neuron_in_old_lower, input_size, 1},
                .upper_dmatrix = &(struct DMatrix){data_neuron_in_old_upper, input_size, 1}
            };
            double data_neuron_in_new_lower[input_size];
            double data_neuron_in_new_upper[input_size];
            memcpy(
                data_neuron_in_new_lower,
                bad_neurons[i]->equation->lower_dmatrix->data,
                sizeof(double) * input_size);
            memcpy(
                data_neuron_in_new_upper,
                bad_neurons[i]->equation->upper_dmatrix->data,
                sizeof(double) * input_size);
            struct DInterval neuron_in_new = {
                .lower_dmatrix = &(struct DMatrix){data_neuron_in_new_lower, input_size, 1},
                .upper_dmatrix = &(struct DMatrix){data_neuron_in_new_upper, input_size, 1}
            };

            matmul(current_base_in_old, neuron_in_new.lower_dmatrix, neuron_in_old.lower_dmatrix);
            matmul(current_base_in_old, neuron_in_new.upper_dmatrix, neuron_in_old.upper_dmatrix);

            memcpy(
                bad_neurons[i]->equation->lower_dmatrix->data,
                data_neuron_in_old_lower,
                sizeof(double) * input_size);
            memcpy(
                bad_neurons[i]->equation->upper_dmatrix->data,
                data_neuron_in_old_upper,
                sizeof(double) * input_size);
#ifdef DBG_CHK_BAD_NEURONS
            pthread_mutex_lock(&lock);
            printf(">>>>>>> depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
            printf("== Trying split with neuron - after conversion ===========\n");
            print_NeuronInfo(bad_neurons[i]);
            printf("<<<<<<< depth=%d, pid=%ld check_on_relu\n", depth, syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
#endif

            int retry = split_relu_3way(
                nnet,
                input_in_current,
                output,
                pcstrlist,

                num_dims_allowed,
                dims_used,

                depth,
                bad_neurons[i],
                bad_neurons[i]->l,
                bad_neurons[i]->n,

                prev_neurons,
                activation_history,

                neuron_intervals);
            if (retry == 0) {
                break;
            }
        }
    }

    for (int i = 0; i < nnet->numLayers - 1; i++) {
        if (bad_neurons[i] != NULL) {
            free_NeuronInfo(bad_neurons[i]);
        }
    }
    free(bad_neurons);
    free(data_input_in_old_lower);
    free(data_input_in_old_upper);
}

int is_concrete_adv(struct NNet *nnet, struct DMatrix *adv)
{
    double out[nnet->outputSize];
    struct DMatrix output = {out, nnet->outputSize, 1};

    forward_prop(nnet, adv, &output);

    if (check_functions1(nnet, &output)) {
        pthread_mutex_lock(&lock);
        if (!csv_print) {
            printf(">>>>>>>> pid=%ld\n", syscall(SYS_gettid));
            printf("adv found:\n");
            printf("adv is (norm): ");
            printDMatrix(adv);

            // "Denormalize" input to get it in values that are within the original (non-normalized) input intervals.
            denormalize_input(nnet, adv);
            printf("adv is (de-norm): ");
            printDMatrix(adv);

            printf("it's output is: ");
            printDMatrix(&output);
            printf("<<<<<<<<< pid=%ld\n", syscall(SYS_gettid));
        }
        adv_found = 1;
        pthread_mutex_unlock(&lock);
        return 1;
    }
    return 0;
}

void quit_and_print_gurobi_error(GRBenv *env)
{
    pthread_mutex_lock(&lock);
    printf(">>>>>>>> pid=%ld\n", syscall(SYS_gettid));
    printf("Gurobi Error: %s\n", GRBgeterrormsg(env));
    printf("<<<<<<<< pid=%ld\n", syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
    exit(1);
}

void add_collected_constraints_to_model(
        struct CStrList* pcstrlist,
        int n,
        struct DMatrix* new_base_in_old,
        struct DMatrix* new_origin_in_old,
        GRBmodel* model,
        GRBenv* env)
{
    // The models in split will be used to derive
    // input bounds in in the new base. Here, models
    // will have 2 * n variables: first
    // n old inputs then n new inputs.
    // No constraint will involve more than n+1
    // inputs. Hence the size of indexOf.
    // indexOf maps costraint vars to model vars.
    int indexOf[n + 1];
    // used to store constraints' coefficients
    double coeffs[n + 1];
    int error;
    // add transition matrix new_base_in_old
    // x_in_old = new_base_in_old * x_in_new + new_origin_in_old;
    // following constraints correspond to the rows of the equation above.
    // first variables in constraints are new ones, the last one is a dimension of an x_in_old
    for (int i = 0; i < n; i++) {
        // (n+i)-th var in constraint is actually ith variable in the new base
        indexOf[i] = n + i;
    }

    for(int i=0; i < n; i++) {
        memset(coeffs, 0, (n + 1) * sizeof(double));
        indexOf[n] = i;

        // cblas_daxpy(n, a=1, x=new_base_in_old, incx=n, y=coeff, incy=1) does y:= ax+y
        cblas_daxpy(n, 1, new_base_in_old->data + i, n, coeffs, 1); // copy row i of base to coeffs

        coeffs[n] = -1.0;
        error = GRBaddconstr(model, n + 1, indexOf, coeffs, GRB_EQUAL, -new_origin_in_old->data[i], "");

        if (error) goto QUIT;
    }

    // add collected constraints so far expressed in old
    for (int i = 0; i < n; i++) {
        // ith var in constraint is actually ith variable in the old base
        indexOf[i] = i;
    }

    struct CStrList *list = pcstrlist;
    while (list) {
        char dir = list->current.direction;
        assert(dir == GRB_GREATER_EQUAL || dir == GRB_LESS_EQUAL || dir == GRB_EQUAL);

        error = GRBaddconstr(model, n, indexOf, list->current.coeffs, dir, list->current.d, "");
        if (error) goto QUIT;

        list = list->next;
    }

    error = GRBsetintattr(model, GRB_INT_ATTR_MODELSENSE, GRB_MAXIMIZE);
    if (error) goto QUIT;

QUIT:
    if (error) {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(1);
    }
}

void construct_common_model(GRBmodel **model, GRBenv **env, char *modelname, int const num_vars)
{
    // Pre condition
    assert(*model == NULL);
    assert(*env == NULL);

    double *ubs = (double*) malloc(sizeof(double) * num_vars);
    double *lbs = (double*) malloc(sizeof(double) * num_vars);
    for (int i = 0; i < num_vars; i++) {
        ubs[i] = GRB_INFINITY;
        lbs[i] = -GRB_INFINITY;
    }

    int error = 0;
    error = GRBemptyenv(env);
    if (error)
         quit_and_print_gurobi_error(*env);

    error = GRBsetintparam(*env, "OutputFlag", 0);
    if (error)
        quit_and_print_gurobi_error(*env);

    error = GRBstartenv(*env);
    if (error)
        quit_and_print_gurobi_error(*env);

    error = GRBnewmodel(*env, model, modelname, 0, NULL, NULL, NULL, NULL, NULL);
    if (error)
        quit_and_print_gurobi_error(*env);

    // By default, lower bound of new variables is 0.0. Explicitly set upper and lower bound
    // to inf and -inf, respectively.
    error = GRBaddvars(*model, num_vars, 0, NULL, NULL, NULL, NULL, lbs, ubs, NULL, NULL);
    if (error)
        quit_and_print_gurobi_error(*env);

    free(ubs);
    free(lbs);
}

int get_optimal_val(GRBmodel* model, GRBenv *env, double* obj, int size, int max_min, double *objval)
{
    pthread_mutex_lock(&lock);
    total_gurobi_count++;
    pthread_mutex_unlock(&lock);
    static int cnt = 0;
    int error = 0;
    int optimstatus;
    cnt++;

    error = GRBresetmodel(model);
    if (error) {
        quit_and_print_gurobi_error(env);
    }

    error = GRBsetintattr(model, GRB_INT_ATTR_MODELSENSE, max_min);
    if (error) {
        quit_and_print_gurobi_error(env);
    }

    error = GRBsetintparam(GRBgetenv(model), "DualReductions", 0);
    if (error) {
        quit_and_print_gurobi_error(env);
    }

    error = GRBsetdblattrarray(model, GRB_DBL_ATTR_OBJ, 0, size, obj);
    if (error) {
        quit_and_print_gurobi_error(env);
    }

    struct timeval gurobi_start, gurobi_finish;
    gettimeofday(&gurobi_start, NULL);

    GRBoptimize(model);

    gettimeofday(&gurobi_finish, NULL);
    double time_spent =
        ((double)(gurobi_finish.tv_sec - gurobi_start.tv_sec) * 1000000 +
        (double)(gurobi_finish.tv_usec - gurobi_start.tv_usec)) / 1000000;
    pthread_mutex_lock(&lock);
    total_gurobi_time += time_spent;
    pthread_mutex_unlock(&lock);

    error = GRBgetintattr(model, GRB_INT_ATTR_STATUS, &optimstatus);
    if (error) {
        quit_and_print_gurobi_error(env);
    }


    if (optimstatus != GRB_OPTIMAL) {
        if (optimstatus == GRB_INFEASIBLE) {
#ifdef DBG_GUROBI
            pthread_mutex_lock(&lock);
            char name[100];
            sprintf(
                    name,
                    "models/inf-%d-%ld.lp",
                    cnt, syscall(SYS_gettid));
            printf("Infeasible model, writing model to disk: %s\n", name);
            GRBwrite(model, name);
            pthread_mutex_unlock(&lock);
#endif
            return 1;
        } else if (optimstatus == GRB_UNBOUNDED) {
#ifdef DBG_GUROBI
            pthread_mutex_lock(&lock);
            char name[100];
            sprintf(
                    name,
                    "models/unbd-%d-%ld.lp",
                    cnt, syscall(SYS_gettid));
            printf("Unbounded model, writing model to disk: %s\n", name);
            GRBwrite(model, name);
            pthread_mutex_unlock(&lock);
#endif
            return 1;
        }
    }

    // assert(optimstatus == GRB_OPTIMAL);
    // assert(!(optimstatus == GRB_INF_OR_UNBD || optimstatus == GRB_INFEASIBLE));

    error = GRBgetdblattr(model, GRB_DBL_ATTR_OBJVAL, objval);
    if (error) {
        quit_and_print_gurobi_error(env);
    }
    return 0;
}

int get_input_bounds_dim(
        GRBmodel *model,
        GRBenv *env,
        int const dim,
        int const input_size,
        int *split_ok,
        struct DInterval *input)
{
    int const obj_size = input_size * 2;
    double obj[obj_size];
    double objval = 0.0;
    int optim_val_error = 0;
    memset(obj, 0, sizeof(double) * obj_size);

    obj[input_size + dim] = 1;

    pthread_mutex_lock(&lock);
    input_gurobi_count++;
    pthread_mutex_unlock(&lock);
    optim_val_error = get_optimal_val(model, env, obj, obj_size, GRB_MINIMIZE, &objval);
    if (!optim_val_error) {
        input->lower_dmatrix->data[dim] = objval;
    } else {
        *split_ok = 0;
    }

    pthread_mutex_lock(&lock);
    input_gurobi_count++;
    pthread_mutex_unlock(&lock);
    optim_val_error = get_optimal_val(model, env, obj, obj_size, GRB_MAXIMIZE, &objval);
    if (!optim_val_error) {
        input->upper_dmatrix->data[dim] = objval;
    } else {
        *split_ok = 0;
    }

    obj[input_size + dim] = 0;
}

int get_input_bounds_multiple(
        GRBmodel *model,
        GRBenv *env,
        int const input_size,
        int *split_ok,
        struct DInterval *input)
{

    // Set up multiple objective
    int const obj_size = input_size * 2;
    int ind[obj_size];
    for (int i = 0; i < obj_size; i++) {
        ind[i] = i;
    }
    double obj[obj_size];
    memset(obj, 0, sizeof(double) * obj_size);

    int error = 0;
    for (int i = 0; i < input_size; i++) {
        obj[input_size + i] = 1.0;

        error = GRBsetobjectiven(
                    model, // model
                    i, // index
                    0, // priority
                    1.0, // weight
                    1e-6, // abstol
                    0.0, // reltol
                    NULL, // name
                    0.0, // constant part of object function
                    obj_size, // number of non-zero coefficients (only new variables are non-zero)
                    ind, // indices of non-zero variables
                    obj);
        if (error)
            quit_and_print_gurobi_error(env);
        obj[input_size + i] = 0.0;
    }
    error = GRBsetintparam(GRBgetenv(model), "DualReductions", 0);
    if (error) {
        quit_and_print_gurobi_error(env);
    }

    error = GRBresetmodel(model);
    if (error) {
        quit_and_print_gurobi_error(env);
    }
    error = GRBsetintattr(model, GRB_INT_ATTR_MODELSENSE, GRB_MINIMIZE);
    if (error) {
        quit_and_print_gurobi_error(env);
    }

    GRBwrite(model, "models/multiple_obj_min.lp");
    // GRBupdatemodel(model);
    GRBoptimize(model);

    // Get solution for minimization
    int num_sols = 0;
    error = GRBgetintattr(model, GRB_INT_ATTR_SOLCOUNT, &num_sols);
    if (error)
        quit_and_print_gurobi_error(env);
    printf("number solutions min: %d\n", num_sols);
    if (num_sols == 0) {
        *split_ok = 0;
        return 1;
    }

    for (int i = 0; i < input_size; i++) {
        error = GRBsetintparam(GRBgetenv(model), GRB_INT_PAR_OBJNUMBER, i);
        if (error)
            quit_and_print_gurobi_error(env);

        double obj_val = 0.0;
        error = GRBgetdblattr(model, GRB_DBL_ATTR_OBJNVAL, &obj_val);
        if (error)
            quit_and_print_gurobi_error(env);
        input->lower_dmatrix->data[i] = obj_val;
    }

    error = GRBresetmodel(model);
    if (error) {
        quit_and_print_gurobi_error(env);
    }
    error = GRBsetintattr(model, GRB_INT_ATTR_MODELSENSE, GRB_MAXIMIZE);
    if (error) {
        quit_and_print_gurobi_error(env);
    }

    GRBwrite(model, "models/multiple_obj_max.lp");
    // GRBupdatemodel(model);
    GRBoptimize(model);
    // Get solution for maximization
    num_sols = 0;
    error = GRBgetintattr(model, GRB_INT_ATTR_SOLCOUNT, &num_sols);
    if (error)
        quit_and_print_gurobi_error(env);
    printf("number solutions max: %d\n", num_sols);
    if (num_sols == 0) {
        *split_ok = 0;
        return 1;
    }

    for (int i = 0; i < input_size; i++) {
        error = GRBsetintparam(GRBgetenv(model), GRB_INT_PAR_OBJNUMBER, i);
        if (error)
            quit_and_print_gurobi_error(env);

        double obj_val = 0.0;
        error = GRBgetdblattr(model, GRB_DBL_ATTR_OBJNVAL, &obj_val);
        if (error)
            quit_and_print_gurobi_error(env);
        input->upper_dmatrix->data[i] = obj_val;
    }
}

void *check_on_relu_thread(void *args)
{
    struct check_on_relu_args *actual_args = args;
    check_on_relu(
            actual_args->nnet,
            actual_args->current_base_in_old,
            actual_args->current_origin_in_old,
            actual_args->input_in_current,
            actual_args->output,
            actual_args->pcstrlist,
            actual_args->num_dims_allowed,
            actual_args->dims_used,
            actual_args->parent_tid,
            actual_args->depth,
            actual_args->prev_split_l,
            actual_args->prev_split_n,
            actual_args->prev_neurons,
            actual_args->activation_history,
            actual_args->best_intervals);
    return NULL;
}

int cmp_dim_scores(void const *ds1, void const *ds2)
{
    struct dimension_score arg1 = *(struct dimension_score const*) ds1;
    struct dimension_score arg2 = *(struct dimension_score const*) ds2;

    if (arg1.score < arg2.score) return 1; // I want to sort in ascending order
    if (arg1.score > arg2.score) return -1; // I want to sort in ascending order
    return 0;
}

int cmp_int(void const *i1, void const *i2)
{
    int arg1 = *(int const*)i1;
    int arg2 = *(int const*)i2;
    if (arg1 < arg2) return -1;
    if (arg1 > arg2) return 1;
    return 0;
}

int construct_approx_equation(
        struct DMatrix *equation,
        struct DInterval *parent_input,
        int const input_size,

        int const num_dims_allowed,
        int *dims_used_local,
        int *dims_used,

        double *active_offset,
        double *inactive_offset,
        struct DMatrix *approx_equation
        )
{
    struct dimension_score scores[input_size];
    for (int i = 0; i < input_size; i++) {
        double s =
            fabs(equation->data[i]) * (parent_input->upper_dmatrix->data[i] - parent_input->lower_dmatrix->data[i]);
        scores[i] = (struct dimension_score){ .score = s, .index = i };
    }
    qsort(scores, input_size, sizeof(struct dimension_score), cmp_dim_scores);

    // Assume approx_equation has been properly initialized.
    // Assume active_offset and inactive_offset have been initialized
    // s.t. they are the bias term from the lower and upper equations.
    for (int i = 0; i < input_size; i++) {
        int const idx = scores[i].index;
        if (i < num_dims_allowed) {
            approx_equation->data[idx] = equation->data[idx];
            dims_used_local[i] = idx;
            dims_used[idx] = 1;
        } else {
            double coeff = equation->data[idx];
            if (coeff >= 0) {
                *active_offset += coeff * parent_input->lower_dmatrix->data[idx];
                *inactive_offset += coeff * parent_input->upper_dmatrix->data[idx];
            } else {
                *active_offset += coeff * parent_input->upper_dmatrix->data[idx];
                *inactive_offset += coeff * parent_input->lower_dmatrix->data[idx];
            }
        }
    }
    qsort(dims_used_local, num_dims_allowed, sizeof(int), cmp_int);
}

int construct_base_from_approx_equation(
        struct DMatrix *approx_equation,
        int *dims_used_local,
        int const input_size,
        int const num_dims_allowed,

        struct DMatrix *base
        )
{
    double *low_dim_base_equation = (double*) malloc(sizeof(double) * num_dims_allowed);
    for (int i = 0; i < num_dims_allowed; i++) {
        low_dim_base_equation[i] = approx_equation->data[dims_used_local[i]];
    }

    double *low_dim_base_data = (double*) malloc(sizeof(double) * num_dims_allowed * num_dims_allowed);
    struct DMatrix low_dim_base = {
        .data = low_dim_base_data,
        .row = num_dims_allowed,
        .col = num_dims_allowed
    };

    if (complete_into_base_and_normalize(low_dim_base_equation, low_dim_base.data, num_dims_allowed)) {
        pthread_mutex_lock(&lock);
        printf(">>>>>>>> pid=%ld, construct_base_from_approx_equation\n", syscall(SYS_gettid));
        printf("Problem with constructing low dimensional base.\n");
        printf("<<<<<<<< pid=%ld \n", syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);
        exit(-1);
    }

    double *inv = (double*) malloc(sizeof(double) * num_dims_allowed * num_dims_allowed);
    lapack_int ret = gram_schmidt_and_inverse(low_dim_base.data, inv, num_dims_allowed);
    if (ret) {
        pthread_mutex_lock(&lock);
        printf(">>>>>>>> pid=%ld,  construct_base_from_approx_equation\n", syscall(SYS_gettid));
        printf("Issue with low dimensional base: %d. Orhtonormalization or inverse.\n", ret);
        printf("<<<<<<<< pid=%ld \n", syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);
        exit(-1);
    }
    free(inv);

    for (int i = 0; i < input_size; i++) {
        base->data[i + input_size * i] = 1.0;
    }
    for (int i = 0; i < num_dims_allowed; i++) {
        memset(base->data + (dims_used_local[i] * input_size), 0.0, sizeof(double) * input_size);
    }

    for (int i = 0; i < num_dims_allowed; i++) {
        for (int j = 0; j < num_dims_allowed; j++) {
            base->data[dims_used_local[j] + dims_used_local[i] * input_size] =
                low_dim_base.data[j + i * num_dims_allowed];
        }
    }

    free(low_dim_base_data);
    free(low_dim_base_equation);
}

int split_relu_3way(
        struct NNet *nnet,
        struct DInterval *parent_input,
        struct DInterval *output,
        struct CStrList* pcstrlist,

        int const num_dims_allowed,
        int *dims_used,

        int depth,
        struct NeuronInfo *neuron,
        int const split_l,
        int const split_n,

        struct NeuronInfoList *prev_neurons,
        enum NeuronState *activation_history,

        struct IntervalVals **best_intervals
        )
{
    pthread_mutex_lock(&lock);
    if (adv_found){
        pthread_mutex_unlock(&lock);
        return 0;
    }
    // BEGIN Investigate infeasible encode_nn_and_solve
    // if (exit_prog) {
    //     pthread_mutex_unlock(&lock);
    //     return 0;
    // }
    // END Investigate infeasible encode_nn_and_solve
    pthread_mutex_unlock(&lock);

    int active_ok = 1, inactive_ok = 1, hybrid_ok = 1;

    int const input_size = nnet->inputSize;
    int const output_size = nnet->outputSize;

    GRBmodel *model = NULL;
    GRBenv *env = NULL;
    char modelname[31];
    sprintf(modelname, "models/check_%ld.lp", syscall(SYS_gettid));

    construct_common_model(&model, &env, modelname, input_size * 2);
#ifdef DEBUG
    GRBwrite(model, modelname);
#endif
    GRBupdatemodel(model);
    GRBmodel *model_active = model;
    GRBmodel *model_inactive = GRBcopymodel(model);
    GRBmodel *model_hybrid = GRBcopymodel(model);

    double data_direction_active[input_size]; // In old base
    double data_direction_inactive[input_size]; // In old base
    struct DMatrix direction_active = {data_direction_active, input_size, 1};
    struct DMatrix direction_inactive = {data_direction_inactive, input_size, 1};

    int same_slope = 1;
    for (int k = 0; k < input_size; k++) {
        data_direction_active[k] = neuron->equation->lower_dmatrix->data[k];
        data_direction_inactive[k] = neuron->equation->upper_dmatrix->data[k];
        double diff = fabs(neuron->equation->lower_dmatrix->data[k] - neuron->equation->upper_dmatrix->data[k]);
        if (diff > 1e-6) {
            same_slope = 0;
        }
    }
#ifdef DEBUG
    if (!same_slope) {
        pthread_mutex_lock(&lock);
        printf(">>>>>>>> pid=%ld, split_relu_3way\n", syscall(SYS_gettid));
        printf("Lower and upper equations differ:\n");
        printf("Lower: "); printDMatrix(neuron->equation->lower_dmatrix);
        printf("Upper: "); printDMatrix(neuron->equation->upper_dmatrix);
        printf("<<<<<<<< pid=%ld \n", syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);
    }
#endif

    double active_offset = -neuron->equation->lower_dmatrix->data[input_size];
    double inactive_offset = -neuron->equation->upper_dmatrix->data[input_size];

    // If condition below holds then active and inactive subproblem
    // will cover the hybrid subproblem, therefore we don't need to
    // start the hybrid subproblem.
    if (same_slope && (active_offset == inactive_offset)) {
        hybrid_ok = 0;
    }

    // If the neuron's upper and lower bounds do not have the same
    // slope then we only start two subproblems:
    //  1) Active
    //      We use the lower bound to create the base, therefore
    //      we can ensure that the chosen neuron can be made active.
    //  2) Hybrid
    //      The other side we cannot make any guarantees on, so
    //      we start it as a hybrid subproblem.
    if (!same_slope) {
        inactive_ok = 0;
    }

    int dims_used_local[num_dims_allowed];
    memset(dims_used_local, -1, sizeof(int) * num_dims_allowed);

    double data_approx_equation[input_size];
    struct DMatrix approx_equation = {data_approx_equation, input_size, 1};
    double active_offset_copy = active_offset;
    double inactive_offset_copy = inactive_offset;
    construct_approx_equation(
            &direction_active,
            parent_input,
            input_size,
            num_dims_allowed,
            dims_used_local,
            dims_used,
            &active_offset_copy,
            &inactive_offset_copy,
            &approx_equation);

    // New origin (shared between sub-problems)
    double *data_new_origin_in_old = (double*) malloc(sizeof(double) * input_size);
    memset(data_new_origin_in_old, 0.0, sizeof(double) * input_size);
    struct DMatrix *new_origin_in_old = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    new_origin_in_old->data = data_new_origin_in_old;
    new_origin_in_old->row = input_size;
    new_origin_in_old->col = 1;

    double *data_base_active = (double*) malloc(sizeof(double) * input_size * input_size);
    memset(data_base_active, 0.0, sizeof(double) * input_size * input_size);
    struct DMatrix *base_active = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    base_active->data = data_base_active;
    base_active->row = input_size;
    base_active->col = input_size;

    // New base procedure can re-use a lot of code here.
    // We need to find a base for a problem with k dimensions
    // which we will do in the same way as below, using the k
    // coefficients from eq-tilde as the first column in the
    // new base.
    construct_base_from_approx_equation(&approx_equation, dims_used_local, input_size, num_dims_allowed, base_active);

    // Use instead of construct_approx_equation and construct_base_from_approx_equation
    // if (complete_into_base_and_normalize(direction_active.data, base_active->data, input_size)) {
    //     pthread_mutex_lock(&lock);
    //     printf(">>>>>>>> pid=%ld, split_relu_3way\n", syscall(SYS_gettid));
    //     printf("Problem with constructing active base.\n");
    //     printf("<<<<<<<< pid=%ld \n", syscall(SYS_gettid));
    //     pthread_mutex_unlock(&lock);
    //     exit(-1);
    // }
    // double *inv_active = (double*) malloc(sizeof(double) * input_size * input_size);
    // lapack_int ret = gram_schmidt_and_inverse(base_active->data, inv_active, input_size);
    // if (ret) {
    //     pthread_mutex_lock(&lock);
    //     printf(">>>>>>>> pid=%ld, check \n", syscall(SYS_gettid));
    //     printf("Issue with active base: %d. Orhtonormalization or inverse.\n", ret);
    //     printf("<<<<<<<< pid=%ld \n", syscall(SYS_gettid));
    //     pthread_mutex_unlock(&lock);
    //     assert(0);
    //     exit(-1);
    // }
    // free(inv_active);
    add_collected_constraints_to_model(pcstrlist, input_size, base_active, new_origin_in_old, model_active, env);
    add_collected_constraints_to_model(pcstrlist, input_size, base_active, new_origin_in_old, model_inactive, env);
    add_collected_constraints_to_model(pcstrlist, input_size, base_active, new_origin_in_old, model_hybrid, env);

    double *input_upper_active = (double*) malloc(sizeof(double) * input_size);
    double *input_lower_active = (double*) malloc(sizeof(double) * input_size);
    struct DMatrix *matrix_upper_active = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    struct DMatrix *matrix_lower_active = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    matrix_upper_active->data = input_upper_active;
    matrix_upper_active->row = input_size;
    matrix_upper_active->col = 1;
    matrix_lower_active->data = input_lower_active;
    matrix_lower_active->row = input_size;
    matrix_lower_active->col = 1;
    struct DInterval *input_interval_in_old_active = (struct DInterval*) malloc(sizeof(struct DInterval));
    input_interval_in_old_active->upper_dmatrix = matrix_upper_active;
    input_interval_in_old_active->lower_dmatrix = matrix_lower_active;

    double *input_upper_inactive = (double*) malloc(sizeof(double) * input_size);
    double *input_lower_inactive = (double*) malloc(sizeof(double) * input_size);
    struct DMatrix *matrix_upper_inactive = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    struct DMatrix *matrix_lower_inactive = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    matrix_upper_inactive->data = input_upper_inactive;
    matrix_upper_inactive->row = input_size;
    matrix_upper_inactive->col = 1;
    matrix_lower_inactive->data = input_lower_inactive;
    matrix_lower_inactive->row = input_size;
    matrix_lower_inactive->col = 1;
    struct DInterval *input_interval_in_old_inactive = (struct DInterval*) malloc(sizeof(struct DInterval));
    input_interval_in_old_inactive->upper_dmatrix = matrix_upper_inactive;
    input_interval_in_old_inactive->lower_dmatrix = matrix_lower_inactive;

    double *input_upper_hybrid = (double*) malloc(sizeof(double) * input_size);
    double *input_lower_hybrid = (double*) malloc(sizeof(double) * input_size);
    struct DMatrix *matrix_upper_hybrid = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    struct DMatrix *matrix_lower_hybrid = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    matrix_upper_hybrid->data = input_upper_hybrid;
    matrix_upper_hybrid->row = input_size;
    matrix_upper_hybrid->col = 1;
    matrix_lower_hybrid->data = input_lower_hybrid;
    matrix_lower_hybrid->row = input_size;
    matrix_lower_hybrid->col = 1;
    struct DInterval *input_interval_in_old_hybrid = (struct DInterval*) malloc(sizeof(struct DInterval));
    input_interval_in_old_hybrid->upper_dmatrix = matrix_upper_hybrid;
    input_interval_in_old_hybrid->lower_dmatrix = matrix_lower_hybrid;

    memset(input_upper_active, 0.0, sizeof(double) * input_size);
    memset(input_lower_active, 0.0, sizeof(double) * input_size);
    memset(input_upper_inactive, 0.0, sizeof(double) * input_size);
    memset(input_lower_inactive, 0.0, sizeof(double) * input_size);
    memset(input_upper_hybrid, 0.0, sizeof(double) * input_size);
    memset(input_lower_hybrid, 0.0, sizeof(double) * input_size);

    memcpy(input_upper_active, parent_input->upper_dmatrix->data, sizeof(double) * input_size);
    memcpy(input_lower_active, parent_input->lower_dmatrix->data, sizeof(double) * input_size);
    memcpy(input_upper_inactive, parent_input->upper_dmatrix->data, sizeof(double) * input_size);
    memcpy(input_lower_inactive, parent_input->lower_dmatrix->data, sizeof(double) * input_size);
    memcpy(input_upper_hybrid, parent_input->upper_dmatrix->data, sizeof(double) * input_size);
    memcpy(input_lower_hybrid, parent_input->lower_dmatrix->data, sizeof(double) * input_size);

    // With this we actually encode the constraint we want to use.
    // E.g., if the neuron we want to manipulate has the equation
    //      Lower: 0.5 x0 - 0.25 x1 + x2 + C0
    //      Upper: 0.5 x0 - 0.25 x1 + x2 + C1
    // then
    //      indexOf = [0, 1, 2] (for x0, x1, x2)
    //      coeffs = [0.5, -0.25, 1]
    //
    // The constraints we add will be the follwing:
    //  active:
    //      0.5 x0 - 0.25 x1 + x2 >= -C0
    //  inactive:
    //      0.5 x0 - 0.25 x1 + x2 <= -C1
    //  hybrid:
    //      0.5 x0 - 0.25 x1 + x2 >= -C0
    //      0.5 x0 - 0.25 x1 + x2 <= -C1
    int indexOf[input_size];
    for (int i = 0; i < input_size; i++) {
        indexOf[i] = i;
    }
    double coeffs[input_size];
    for (int i = 0; i < input_size; i++) {
        coeffs[i] = direction_active.data[i];
    }


    if (same_slope) {
        // Active model
        if (GRBaddconstr(model_active, input_size, indexOf, coeffs, GRB_GREATER_EQUAL, active_offset, "")) {
            quit_and_print_gurobi_error(env);
        }

        // Inactive model
        if (GRBaddconstr(model_inactive, input_size, indexOf, coeffs, GRB_LESS_EQUAL, inactive_offset, "")) {
            quit_and_print_gurobi_error(env);
        }

        // Hybrid model
        if (GRBaddconstr(model_hybrid, input_size, indexOf, coeffs, GRB_LESS_EQUAL, active_offset, "")) {
            quit_and_print_gurobi_error(env);
        }
        if (GRBaddconstr(model_hybrid, input_size, indexOf, coeffs, GRB_GREATER_EQUAL, inactive_offset, "")) {
            quit_and_print_gurobi_error(env);
        }
    } else { // Only starting active and hybrid subproblem
        // Active model
        if (GRBaddconstr(model_active, input_size, indexOf, coeffs, GRB_GREATER_EQUAL, active_offset, "")) {
            quit_and_print_gurobi_error(env);
        }

        // Hybrid model
        if (GRBaddconstr(model_hybrid, input_size, indexOf, coeffs, GRB_LESS_EQUAL, active_offset, "")) {
            quit_and_print_gurobi_error(env);
        }
    }

#ifdef DEBUG
    char active_name[100], inactive_name[100], hybrid_name[100];
    sprintf(active_name, "models/active-%d.lp", depth + 1);
    sprintf(inactive_name, "models/inactive-%d.lp", depth + 1);
    sprintf(hybrid_name, "models/hybrid-%d.lp", depth + 1);
    GRBwrite(model_active, active_name);
    GRBwrite(model_inactive, inactive_name);
    GRBwrite(model_hybrid, hybrid_name);
#endif

    GRBupdatemodel(model_active);
    GRBupdatemodel(model_inactive);
    GRBupdatemodel(model_hybrid);

    /*
        Find lower and upper bounds for variables in new base for >= side.

        E.g., to find lower bound for x':
        Minimize 0x + 0y + 1x' + 0y'
        subject to [collected constraints]

        The objective function is encoded in the array obj.
        The constraints are already in the respective models, model_plus and model_minus.
    */

    for (int in = 0; in < input_size; in++) {
        if (dims_used[in]) {
            if (active_ok) {
                get_input_bounds_dim(model_active, env, in, input_size, &active_ok, input_interval_in_old_active);
            }
            if (inactive_ok) {
                get_input_bounds_dim(model_inactive, env, in, input_size, &inactive_ok, input_interval_in_old_inactive);
            }
            if (hybrid_ok) {
                get_input_bounds_dim(model_hybrid, env, in, input_size, &hybrid_ok, input_interval_in_old_hybrid);
            }
        }
    }

    for (int in = 0; in < input_size; in++) {
    }

    // extensions of cstrlist, one for each child.
    struct CStrList cstrlist_active, cstrlist_inactive, cstrlist_hybrid1, cstrlist_hybrid2;

    if (same_slope) {
        // This list remembers the current constraints for future splits, since we destroy the Gurobi model used here.
        // It is also expressed in the old base, i.e., can be used to construct the construct the splits imposed here
        // in any future base.
        cstrlist_active.current = (struct Cstr){input_size, direction_active.data, GRB_GREATER_EQUAL, active_offset};
        cstrlist_active.next = pcstrlist;

        cstrlist_inactive.current = (struct Cstr){input_size, direction_active.data, GRB_LESS_EQUAL, inactive_offset};
        cstrlist_inactive.next = pcstrlist;

        cstrlist_hybrid1.current = (struct Cstr){input_size, direction_active.data, GRB_LESS_EQUAL, active_offset};
        cstrlist_hybrid1.next = pcstrlist;
        cstrlist_hybrid2.current = (struct Cstr){input_size, direction_active.data, GRB_GREATER_EQUAL, inactive_offset};
        cstrlist_hybrid2.next = &cstrlist_hybrid1;
    } else { // Only starting the active and hybrid subproblems
        cstrlist_active.current = (struct Cstr){input_size, direction_active.data, GRB_GREATER_EQUAL, active_offset};
        cstrlist_active.next = pcstrlist;

        cstrlist_hybrid2.current = (struct Cstr){input_size, direction_active.data, GRB_LESS_EQUAL, active_offset};
        cstrlist_hybrid2.next = pcstrlist;
    }


#ifdef DEBUG
    pthread_mutex_lock(&lock);
    printf(">>>>>>> depth=%d, pid=%ld split_relu_3way\n", depth, syscall(SYS_gettid));
    printf("Inputs active: \n");
    printDMatrix(input_interval_in_old_active->lower_dmatrix);
    printDMatrix(input_interval_in_old_active->upper_dmatrix);
    printf("Inputs inactive: \n");
    printDMatrix(input_interval_in_old_inactive->lower_dmatrix);
    printDMatrix(input_interval_in_old_inactive->upper_dmatrix);
    printf("Inputs hybrid: \n");
    printDMatrix(input_interval_in_old_hybrid->lower_dmatrix);
    printDMatrix(input_interval_in_old_hybrid->upper_dmatrix);
    // printf("Constraints active:\n");
    // print_constraints(&cstrlist_active);
    // printf("Constraints inactive:\n");
    // print_constraints(&cstrlist_inactive);
    // printf("Constraints hybrid:\n");
    // print_constraints(&cstrlist_hybrid2);
    printf("<<<<<<< depth=%d, pid=%ld split_relu_3way\n", depth, syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif


    int error = GRBfreemodel(model_hybrid);
    if (error) {
        quit_and_print_gurobi_error(env);
    }
    error = GRBfreemodel(model_inactive);
    if (error) {
        quit_and_print_gurobi_error(env);
    }
    error = GRBfreemodel(model_active); // alias model
    if (error) {
        quit_and_print_gurobi_error(env);
    }
    GRBfreeenv(env);

    // This can be deleted and replaced with NULL if needed.
    // However, it doesn't hurt to keep it.
    // It saves the lower and upper equations of neurons that we are using to split the problem.
    double data_saved_eq_lo[input_size + 1];
    double data_saved_eq_up[input_size + 1];
    memcpy(data_saved_eq_lo, direction_active.data, sizeof(double) * input_size);
    data_saved_eq_lo[input_size] = -active_offset;
    memcpy(data_saved_eq_up, direction_inactive.data, sizeof(double) * input_size);
    data_saved_eq_up[input_size] = -inactive_offset;
    struct DInterval neq = {
        .lower_dmatrix = &(struct DMatrix){data_saved_eq_lo, input_size + 1, 1},
        .upper_dmatrix = &(struct DMatrix){data_saved_eq_up, input_size + 1, 1},
    };

    int *dims_used_active = (int*) malloc(sizeof(int) * input_size);
    int *dims_used_inactive = (int*) malloc(sizeof(int) * input_size);
    int *dims_used_hybrid = (int*) malloc(sizeof(int) * input_size);

    memcpy(dims_used_active, dims_used, sizeof(int) * input_size);
    memcpy(dims_used_inactive, dims_used, sizeof(int) * input_size);
    memcpy(dims_used_hybrid, dims_used, sizeof(int) * input_size);

    pthread_mutex_lock(&lock);
    if (active_ok == 0) {
        killed_splits++;
    }
    if (inactive_ok == 0) {
        killed_splits++;
    }
    if (hybrid_ok == 0) {
        killed_splits++;
    }
    pthread_mutex_unlock(&lock);

    unsigned long const parent_tid = syscall(SYS_gettid);
#ifdef SINGLE_THREAD
    // This part is only compiled if SINGLE_THREAD is defined in pre-processor

    if (active_ok == 0 && inactive_ok == 0 && hybrid_ok == 0) {
        // Neither split viable. Return and try other neuron or exit?
        return 1;
    }

    if (active_ok == 1) {
        double *output_upper_active = (double*) malloc(sizeof(double) * output_size);
        double *output_lower_active = (double*) malloc(sizeof(double) * output_size);
        struct DMatrix *matrix_out_upper_active = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        struct DMatrix *matrix_out_lower_active = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        matrix_out_upper_active->data = output_upper_active;
        matrix_out_upper_active->row = output_size;
        matrix_out_upper_active->col = 1;
        matrix_out_lower_active->data = output_lower_active;
        matrix_out_lower_active->row = output_size;
        matrix_out_lower_active->col = 1;
        struct DInterval *output_interval_active = (struct DInterval*) malloc(sizeof(struct DInterval));
        output_interval_active->upper_dmatrix = matrix_out_upper_active;
        output_interval_active->lower_dmatrix = matrix_out_lower_active;
        memcpy(output_upper_active, output->upper_dmatrix->data, output_size * sizeof(double));
        memcpy(output_lower_active, output->lower_dmatrix->data, output_size * sizeof(double));

        enum NeuronState *activation_history_active =
            (enum NeuronState*) malloc(sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));
        memcpy(
            activation_history_active,
            activation_history,
            sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));

        struct IntervalVals **best_intervals_active =
            (struct IntervalVals**) malloc(sizeof(struct IntervalVals*) * (nnet->maxLayerSize * (nnet->numLayers + 1)));
        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            best_intervals_active[i] = (struct IntervalVals*) malloc(sizeof(struct IntervalVals));
            best_intervals_active[i]->lo = best_intervals[i]->lo;
            best_intervals_active[i]->up = best_intervals[i]->up;
        }

        // Actually force state of neuron we are splitting on
        best_intervals_active[nnet->maxLayerSize * (split_l + 1) + split_n]->lo = 0.0;

        struct NeuronInfo next_neuron = {
            .l = split_l,
            .n = split_n,
            .state = ACTIVE,
            .equation = &neq
        };
        struct NeuronInfoList next_list;
        next_list.ni = &next_neuron;
        next_list.next = prev_neurons;

#ifdef SPLIT_PRINT
        printf("start active %d\n", depth + 1);
#endif
        check_on_relu(
            nnet,
            base_active,
            new_origin_in_old,
            input_interval_in_old_active,
            output_interval_active,
            &cstrlist_active,

            num_dims_allowed,
            dims_used_active,

            parent_tid,
            depth+1,
            split_l,
            split_n,

            &next_list,
            activation_history_active,

            best_intervals_active
            );
#ifdef SPLIT_PRINT
        printf("done active %d\n", depth + 1);
#endif
        free(output_upper_active);
        free(output_lower_active);
        free(matrix_out_upper_active);
        free(matrix_out_lower_active);
        free(output_interval_active);

        free(activation_history_active);

        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            free(best_intervals_active[i]);
            best_intervals_active[i] = NULL;
        }
        free(best_intervals_active);
    }

    if (inactive_ok == 1) {
        double *output_upper_inactive = (double*) malloc(sizeof(double) * output_size);
        double *output_lower_inactive = (double*) malloc(sizeof(double) * output_size);
        struct DMatrix *matrix_out_upper_inactive = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        struct DMatrix *matrix_out_lower_inactive = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        matrix_out_upper_inactive->data = output_upper_inactive;
        matrix_out_upper_inactive->row = output_size;
        matrix_out_upper_inactive->col = 1;
        matrix_out_lower_inactive->data = output_lower_inactive;
        matrix_out_lower_inactive->row = output_size;
        matrix_out_lower_inactive->col = 1;
        struct DInterval *output_interval_inactive = (struct DInterval*) malloc(sizeof(struct DInterval));
        output_interval_inactive->upper_dmatrix = matrix_out_upper_inactive;
        output_interval_inactive->lower_dmatrix = matrix_out_lower_inactive;
        memcpy(output_upper_inactive, output->upper_dmatrix->data, output_size * sizeof(double));
        memcpy(output_lower_inactive, output->lower_dmatrix->data, output_size * sizeof(double));

        enum NeuronState *activation_history_inactive =
            (enum NeuronState*) malloc(sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));
        memcpy(
            activation_history_inactive,
            activation_history,
            sizeof(int) * (nnet->maxLayerSize * (nnet->numLayers - 1)));

        struct IntervalVals **best_intervals_inactive =
            (struct IntervalVals**) malloc(sizeof(struct IntervalVals*) * (nnet->maxLayerSize * (nnet->numLayers + 1)));
        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            best_intervals_inactive[i] = (struct IntervalVals*) malloc(sizeof(struct IntervalVals));
            best_intervals_inactive[i]->lo = best_intervals[i]->lo;
            best_intervals_inactive[i]->up = best_intervals[i]->up;
        }

        // Actually force state of neuron we are splitting on
        best_intervals_inactive[nnet->maxLayerSize * (split_l + 1) + split_n]->up = 0.0;

        struct NeuronInfo next_neuron = {
            .l = split_l,
            .n = split_n,
            .state = INACTIVE,
            .equation = &neq
        };
        struct NeuronInfoList next_list;
        next_list.ni = &next_neuron;
        next_list.next = prev_neurons;

#ifdef SPLIT_PRINT
        printf("start inactive %d\n", depth+1);
#endif
        check_on_relu(
            nnet,
            base_active,
            new_origin_in_old,
            input_interval_in_old_inactive,
            output_interval_inactive,
            &cstrlist_inactive,

            num_dims_allowed,
            dims_used_inactive,

            parent_tid,
            depth+1,
            split_l,
            split_n,

            &next_list,
            activation_history_inactive,

            best_intervals_inactive
            );
#ifdef SPLIT_PRINT
        printf("done inactive %d\n", depth+1);
#endif
        free(output_upper_inactive);
        free(output_lower_inactive);
        free(matrix_out_upper_inactive);
        free(matrix_out_lower_inactive);
        free(output_interval_inactive);

        free(activation_history_inactive);

        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            free(best_intervals_inactive[i]);
            best_intervals_inactive[i] = NULL;
        }
        free(best_intervals_inactive);
    }

    if (hybrid_ok == 1) {
        double *output_upper_hybrid = (double*) malloc(sizeof(double) * output_size);
        double *output_lower_hybrid = (double*) malloc(sizeof(double) * output_size);
        struct DMatrix *matrix_out_upper_hybrid = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        struct DMatrix *matrix_out_lower_hybrid = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        matrix_out_upper_hybrid->data = output_upper_hybrid;
        matrix_out_upper_hybrid->row = output_size;
        matrix_out_upper_hybrid->col = 1;
        matrix_out_lower_hybrid->data = output_lower_hybrid;
        matrix_out_lower_hybrid->row = output_size;
        matrix_out_lower_hybrid->col = 1;
        struct DInterval *output_interval_hybrid = (struct DInterval*) malloc(sizeof(struct DInterval));
        output_interval_hybrid->upper_dmatrix = matrix_out_upper_hybrid;
        output_interval_hybrid->lower_dmatrix = matrix_out_lower_hybrid;
        memcpy(output_upper_hybrid, output->upper_dmatrix->data, output_size * sizeof(double));
        memcpy(output_lower_hybrid, output->lower_dmatrix->data, output_size * sizeof(double));

        enum NeuronState *activation_history_hybrid =
            (enum NeuronState*) malloc(sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));
        memcpy(
            activation_history_hybrid,
            activation_history,
            sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));

        struct IntervalVals **best_intervals_hybrid =
            (struct IntervalVals**) malloc(sizeof(struct IntervalVals*) * (nnet->maxLayerSize * (nnet->numLayers + 1)));
        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            best_intervals_hybrid[i] = (struct IntervalVals*) malloc(sizeof(struct IntervalVals));
            best_intervals_hybrid[i]->lo = best_intervals[i]->lo;
            best_intervals_hybrid[i]->up = best_intervals[i]->up;
        }

        struct NeuronInfo next_neuron = {
            .l = split_l,
            .n = split_n,
            .state = HYBRID,
            .equation = &neq
        };
        struct NeuronInfoList next_list;
        next_list.ni = &next_neuron;
        next_list.next = prev_neurons;

#ifdef SPLIT_PRINT
        printf("start hybrid %d\n", depth+1);
#endif
        check_on_relu(
            nnet,
            base_active,
            new_origin_in_old,
            input_interval_in_old_hybrid,
            output_interval_hybrid,
            &cstrlist_hybrid2,

            num_dims_allowed,
            dims_used_hybrid,

            parent_tid,
            depth+1,
            split_l,
            split_n,

            &next_list,
            activation_history_hybrid,

            best_intervals_hybrid
            );
#ifdef SPLIT_PRINT
        printf("done hybrid %d\n", depth+1);
#endif

        free(output_upper_hybrid);
        free(output_lower_hybrid);
        free(matrix_out_upper_hybrid);
        free(matrix_out_lower_hybrid);
        free(output_interval_hybrid);

        free(activation_history_hybrid);

        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            free(best_intervals_hybrid[i]);
            best_intervals_hybrid[i] = NULL;
        }
        free(best_intervals_hybrid);
    }

    free(data_new_origin_in_old);
    free(new_origin_in_old);
    free(data_base_active);
    free(base_active);

    free(input_upper_active);
    free(input_lower_active);
    free(matrix_upper_active);
    free(matrix_lower_active);
    free(input_interval_in_old_active);

    free(input_upper_inactive);
    free(input_lower_inactive);
    free(matrix_upper_inactive);
    free(matrix_lower_inactive);
    free(input_interval_in_old_inactive);

    free(input_upper_hybrid);
    free(input_lower_hybrid);
    free(matrix_upper_hybrid);
    free(matrix_lower_hybrid);
    free(input_interval_in_old_hybrid);

    free(dims_used_active);
    free(dims_used_inactive);
    free(dims_used_hybrid);

    return 0;
#else

    if (active_ok == 0 && inactive_ok == 0 && hybrid_ok == 0) {
        // Neither split viable. Return and try with upper bound or exit?
        return 1;
    }

    double *output_upper_active, *output_lower_active;
    struct DMatrix *matrix_out_upper_active, *matrix_out_lower_active;
    struct DInterval *output_interval_active;
    enum NeuronState *activation_history_active;
    struct IntervalVals **best_intervals_active;
    struct NeuronInfo next_neuron_active;
    struct NeuronInfoList next_neuron_active_list;
    if (active_ok == 1) {
        output_upper_active = (double*) malloc(sizeof(double) * output_size);
        output_lower_active = (double*) malloc(sizeof(double) * output_size);
        matrix_out_upper_active = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        matrix_out_lower_active = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        matrix_out_upper_active->data = output_upper_active;
        matrix_out_upper_active->row = output_size;
        matrix_out_upper_active->col = 1;
        matrix_out_lower_active->data = output_lower_active;
        matrix_out_lower_active->row = output_size;
        matrix_out_lower_active->col = 1;
        output_interval_active = (struct DInterval*) malloc(sizeof(struct DInterval));
        output_interval_active->upper_dmatrix = matrix_out_upper_active;
        output_interval_active->lower_dmatrix = matrix_out_lower_active;
        memcpy(output_upper_active, output->upper_dmatrix->data, output_size * sizeof(double));
        memcpy(output_lower_active, output->lower_dmatrix->data, output_size * sizeof(double));

        activation_history_active =
            (enum NeuronState*) malloc(sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));
        memcpy(
            activation_history_active,
            activation_history,
            sizeof(int) * (nnet->maxLayerSize * (nnet->numLayers - 1)));

        best_intervals_active =
            (struct IntervalVals**) malloc(
                    sizeof(struct IntervalVals*) * (nnet->maxLayerSize * (nnet->numLayers + 1)));
        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            best_intervals_active[i] = (struct IntervalVals*) malloc(sizeof(struct IntervalVals));
            best_intervals_active[i]->lo = best_intervals[i]->lo;
            best_intervals_active[i]->up = best_intervals[i]->up;
        }

        // Actually force state of neuron we are splitting on
        best_intervals_active[nnet->maxLayerSize * (split_l + 1) + split_n]->lo = 0.0;

        next_neuron_active.l = split_l;
        next_neuron_active.n = split_n;
        next_neuron_active.state = ACTIVE;
        next_neuron_active.equation = &neq;
        next_neuron_active_list.ni = &next_neuron_active;
        next_neuron_active_list.next = prev_neurons;
    }

    double *output_upper_inactive, *output_lower_inactive;
    struct DMatrix *matrix_out_upper_inactive, *matrix_out_lower_inactive;
    struct DInterval *output_interval_inactive;
    enum NeuronState *activation_history_inactive;
    struct IntervalVals **best_intervals_inactive;
    struct NeuronInfo next_neuron_inactive;
    struct NeuronInfoList next_neuron_inactive_list;
    if (inactive_ok == 1) {
        output_upper_inactive = (double*) malloc(sizeof(double) * output_size);
        output_lower_inactive = (double*) malloc(sizeof(double) * output_size);
        matrix_out_upper_inactive = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        matrix_out_lower_inactive = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        matrix_out_upper_inactive->data = output_upper_inactive;
        matrix_out_upper_inactive->row = output_size;
        matrix_out_upper_inactive->col = 1;
        matrix_out_lower_inactive->data = output_lower_inactive;
        matrix_out_lower_inactive->row = output_size;
        matrix_out_lower_inactive->col = 1;
        output_interval_inactive = (struct DInterval*) malloc(sizeof(struct DInterval));
        output_interval_inactive->upper_dmatrix = matrix_out_upper_inactive;
        output_interval_inactive->lower_dmatrix = matrix_out_lower_inactive;
        memcpy(output_upper_inactive, output->upper_dmatrix->data, output_size * sizeof(double));
        memcpy(output_lower_inactive, output->lower_dmatrix->data, output_size * sizeof(double));

        activation_history_inactive =
            (enum NeuronState*) malloc(sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));
        memcpy(
            activation_history_inactive,
            activation_history,
            sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));

        best_intervals_inactive =
            (struct IntervalVals**) malloc(
                    sizeof(struct IntervalVals*) * (nnet->maxLayerSize * (nnet->numLayers + 1)));
        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            best_intervals_inactive[i] = (struct IntervalVals*) malloc(sizeof(struct IntervalVals));
            best_intervals_inactive[i]->lo = best_intervals[i]->lo;
            best_intervals_inactive[i]->up = best_intervals[i]->up;
        }

        // Actually force state of neuron we are splitting on
        best_intervals_inactive[nnet->maxLayerSize * (split_l + 1) + split_n]->up = 0.0;

        next_neuron_inactive.l = split_l;
        next_neuron_inactive.n = split_n;
        next_neuron_inactive.state = INACTIVE;
        next_neuron_inactive.equation = &neq;
        next_neuron_inactive_list.ni = &next_neuron_inactive;
        next_neuron_inactive_list.next = prev_neurons;
    }

    double *output_upper_hybrid, *output_lower_hybrid;
    struct DMatrix *matrix_out_upper_hybrid, *matrix_out_lower_hybrid;
    struct DInterval *output_interval_hybrid;
    enum NeuronState *activation_history_hybrid;
    struct IntervalVals **best_intervals_hybrid;
    struct NeuronInfo next_neuron_hybrid;
    struct NeuronInfoList next_neuron_hybrid_list;
    if (hybrid_ok == 1) {
        output_upper_hybrid = (double*) malloc(sizeof(double) * output_size);
        output_lower_hybrid = (double*) malloc(sizeof(double) * output_size);
        matrix_out_upper_hybrid = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        matrix_out_lower_hybrid = (struct DMatrix*) malloc(sizeof(struct DMatrix));
        matrix_out_upper_hybrid->data = output_upper_hybrid;
        matrix_out_upper_hybrid->row = output_size;
        matrix_out_upper_hybrid->col = 1;
        matrix_out_lower_hybrid->data = output_lower_hybrid;
        matrix_out_lower_hybrid->row = output_size;
        matrix_out_lower_hybrid->col = 1;
        output_interval_hybrid = (struct DInterval*) malloc(sizeof(struct DInterval));
        output_interval_hybrid->upper_dmatrix = matrix_out_upper_hybrid;
        output_interval_hybrid->lower_dmatrix = matrix_out_lower_hybrid;
        memcpy(output_upper_hybrid, output->upper_dmatrix->data, output_size * sizeof(double));
        memcpy(output_lower_hybrid, output->lower_dmatrix->data, output_size * sizeof(double));

        activation_history_hybrid =
            (enum NeuronState*) malloc(sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));
        memcpy(
            activation_history_hybrid,
            activation_history,
            sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));

        best_intervals_hybrid =
            (struct IntervalVals**) malloc(
                    sizeof(struct IntervalVals*) * (nnet->maxLayerSize * (nnet->numLayers + 1)));
        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            best_intervals_hybrid[i] = (struct IntervalVals*) malloc(sizeof(struct IntervalVals));
            best_intervals_hybrid[i]->lo = best_intervals[i]->lo;
            best_intervals_hybrid[i]->up = best_intervals[i]->up;
        }

        next_neuron_hybrid.l = split_l;
        next_neuron_hybrid.n = split_n;
        next_neuron_hybrid.state = HYBRID;
        next_neuron_hybrid.equation = &neq;
        next_neuron_hybrid_list.ni = &next_neuron_hybrid;
        next_neuron_hybrid_list.next = prev_neurons;
    }

    unsigned long active_tid = syscall(SYS_gettid);
    unsigned long inactive_tid = syscall(SYS_gettid);
    unsigned long hybrid_tid = syscall(SYS_gettid);
    pthread_mutex_lock(&lock);
    if (count <= MAX_THREAD) {
        pthread_mutex_unlock(&lock);

        pthread_t workers_active, workers_inactive, workers_hybrid;

        struct check_on_relu_args args_active, args_inactive, args_hybrid;

        if (active_ok == 1) {
            args_active.nnet = nnet;
            args_active.current_base_in_old = base_active;
            args_active.current_origin_in_old = new_origin_in_old;
            args_active.input_in_current = input_interval_in_old_active;
            args_active.output = output_interval_active;
            args_active.pcstrlist = &cstrlist_active;

            args_active.num_dims_allowed = num_dims_allowed;
            args_active.dims_used = dims_used_active;

            args_active.parent_tid = parent_tid;
            args_active.depth = depth + 1;
            args_active.prev_split_l = split_l;
            args_active.prev_split_n = split_n;
            args_active.prev_neurons = &next_neuron_active_list;
            args_active.activation_history = activation_history_active;
            args_active.best_intervals = best_intervals_active;
            pthread_mutex_lock(&lock);
#ifdef SPLIT_PRINT
            printf(">>>>>>> start active (depth=%d, pid=%ld)\n", depth + 1, syscall(SYS_gettid));
#endif
            count++;
            thread_tot_cnt++;
            pthread_mutex_unlock(&lock);
            pthread_create(&workers_active, NULL, check_on_relu_thread, &args_active);

            active_tid = (unsigned long) workers_active;
        }

        if (inactive_ok == 1) {
            args_inactive.nnet = nnet;
            args_inactive.current_base_in_old = base_active;
            args_inactive.current_origin_in_old = new_origin_in_old;
            args_inactive.input_in_current = input_interval_in_old_inactive;
            args_inactive.output = output_interval_inactive;
            args_inactive.pcstrlist = &cstrlist_inactive;

            args_inactive.num_dims_allowed = num_dims_allowed;
            args_inactive.dims_used = dims_used_inactive;

            args_inactive.parent_tid = parent_tid;
            args_inactive.depth = depth + 1;
            args_inactive.prev_split_l = split_l;
            args_inactive.prev_split_n = split_n;
            args_inactive.prev_neurons = &next_neuron_inactive_list;
            args_inactive.activation_history = activation_history_inactive;
            args_inactive.best_intervals = best_intervals_inactive;
            pthread_mutex_lock(&lock);
#ifdef SPLIT_PRINT
            printf(">>>>>>> start inactive (depth=%d, pid=%ld)\n", depth + 1, syscall(SYS_gettid));
#endif
            count++;
            thread_tot_cnt++;
            pthread_mutex_unlock(&lock);
            pthread_create(&workers_inactive, NULL, check_on_relu_thread, &args_inactive);

            inactive_tid = (unsigned long) workers_inactive;
        }

        if (hybrid_ok == 1) {
            args_hybrid.nnet = nnet;
            args_hybrid.current_base_in_old = base_active;
            args_hybrid.current_origin_in_old = new_origin_in_old;
            args_hybrid.input_in_current = input_interval_in_old_hybrid;
            args_hybrid.output = output_interval_hybrid;
            args_hybrid.pcstrlist = &cstrlist_hybrid2;

            args_hybrid.num_dims_allowed = num_dims_allowed;
            args_hybrid.dims_used = dims_used_hybrid;

            args_hybrid.parent_tid = parent_tid;
            args_hybrid.depth = depth + 1;
            args_hybrid.prev_split_l = split_l;
            args_hybrid.prev_split_n = split_n;
            args_hybrid.prev_neurons = &next_neuron_hybrid_list;
            args_hybrid.activation_history = activation_history_hybrid;
            args_hybrid.best_intervals = best_intervals_hybrid;
            pthread_mutex_lock(&lock);
#ifdef SPLIT_PRINT
            printf(">>>>>>> start hybrid (depth=%d, pid=%ld)\n", depth + 1, syscall(SYS_gettid));
#endif
            count++;
            thread_tot_cnt++;
            pthread_mutex_unlock(&lock);
            pthread_create(&workers_hybrid, NULL, check_on_relu_thread, &args_hybrid);

            hybrid_tid = (unsigned long) workers_hybrid;
        }

        if (active_ok == 1) {
            pthread_join(workers_active, NULL);
            pthread_mutex_lock(&lock);
#ifdef SPLIT_PRINT
            printf("<<<<<<< done active (depth=%d, pid=%ld)\n", depth + 1, syscall(SYS_gettid));
#endif
            count--;
            pthread_mutex_unlock(&lock);
        }

        if (inactive_ok == 1) {
            pthread_join(workers_inactive, NULL);
            pthread_mutex_lock(&lock);
#ifdef SPLIT_PRINT
            printf("<<<<<<< done inactive (depth=%d, pid=%ld)\n", depth + 1, syscall(SYS_gettid));
#endif
            count--;
            pthread_mutex_unlock(&lock);
        }

        if (hybrid_ok == 1) {
            pthread_join(workers_hybrid, NULL);
            pthread_mutex_lock(&lock);
#ifdef SPLIT_PRINT
            printf("<<<<<<< done hybrid (depth=%d, pid=%ld)\n", depth + 1, syscall(SYS_gettid));
#endif
            count--;
            pthread_mutex_unlock(&lock);
        }
    } else {
        pthread_mutex_unlock(&lock);

        if (active_ok == 1) {
#ifdef SPLIT_PRINT
            pthread_mutex_lock(&lock);
            printf("start active (depth=%d, pid=%ld) (NO THREAD)\n", depth + 1, syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
#endif

            check_on_relu(
                nnet,
                base_active,
                new_origin_in_old,
                input_interval_in_old_active,
                output_interval_active,
                &cstrlist_active,

                num_dims_allowed,
                dims_used_active,

                parent_tid,
                depth+1,
                split_l,
                split_n,
                &next_neuron_active_list,
                activation_history_active,
                best_intervals_active);

#ifdef SPLIT_PRINT
            pthread_mutex_lock(&lock);
            printf("done active (depth=%d, pid=%ld) (NO THREAD)\n", depth + 1, syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
#endif
        }

        if (inactive_ok == 1) {
#ifdef SPLIT_PRINT
            pthread_mutex_lock(&lock);
            printf("start inactive (depth=%d, pid=%ld) (NO THREAD)\n", depth + 1, syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
#endif

            check_on_relu(
                nnet,
                base_active,
                new_origin_in_old,
                input_interval_in_old_inactive,
                output_interval_inactive,
                &cstrlist_inactive,

                num_dims_allowed,
                dims_used_inactive,

                parent_tid,
                depth+1,
                split_l,
                split_n,
                &next_neuron_inactive_list,
                activation_history_inactive,
                best_intervals_inactive);

#ifdef SPLIT_PRINT
            pthread_mutex_lock(&lock);
            printf("done inactive (depth=%d, pid=%ld) (NO THREAD)\n", depth + 1, syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
#endif
        }

        if (hybrid_ok) {
#ifdef SPLIT_PRINT
            pthread_mutex_lock(&lock);
            printf("start hybrid (depth=%d, pid=%ld) (NO THREAD)\n", depth + 1, syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
#endif

            check_on_relu(
                nnet,
                base_active,
                new_origin_in_old,
                input_interval_in_old_hybrid,
                output_interval_hybrid,
                &cstrlist_hybrid2,

                num_dims_allowed,
                dims_used_hybrid,

                parent_tid,
                depth+1,
                split_l,
                split_n,
                &next_neuron_hybrid_list,
                activation_history_hybrid,
                best_intervals_hybrid);

#ifdef SPLIT_PRINT
            pthread_mutex_lock(&lock);
            printf("done hybrid (depth=%d, pid=%ld) (NO THREAD)\n", depth + 1, syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
#endif
        }
    }

    free(data_new_origin_in_old);
    free(new_origin_in_old);
    free(data_base_active);
    free(base_active);

    free(input_upper_active);
    free(input_lower_active);
    free(matrix_upper_active);
    free(matrix_lower_active);
    free(input_interval_in_old_active);

    free(input_upper_inactive);
    free(input_lower_inactive);
    free(matrix_upper_inactive);
    free(matrix_lower_inactive);
    free(input_interval_in_old_inactive);

    free(input_upper_hybrid);
    free(input_lower_hybrid);
    free(matrix_upper_hybrid);
    free(matrix_lower_hybrid);
    free(input_interval_in_old_hybrid);

    free(dims_used_active);
    free(dims_used_inactive);
    free(dims_used_hybrid);

    if (active_ok) {
        free(output_upper_active);
        free(output_lower_active);
        free(matrix_out_upper_active);
        free(matrix_out_lower_active);
        free(output_interval_active);

        free(activation_history_active);

        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            free(best_intervals_active[i]);
            best_intervals_active[i] = NULL;
        }
        free(best_intervals_active);
    }

    if (inactive_ok) {
        free(output_upper_inactive);
        free(output_lower_inactive);
        free(matrix_out_upper_inactive);
        free(matrix_out_lower_inactive);
        free(output_interval_inactive);

        free(activation_history_inactive);

        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            free(best_intervals_inactive[i]);
            best_intervals_inactive[i] = NULL;
        }
        free(best_intervals_inactive);
    }

    if (hybrid_ok) {
        free(output_upper_hybrid);
        free(output_lower_hybrid);
        free(matrix_out_upper_hybrid);
        free(matrix_out_lower_hybrid);
        free(output_interval_hybrid);

        free(activation_history_hybrid);

        for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
            free(best_intervals_hybrid[i]);
            best_intervals_hybrid[i] = NULL;
        }
        free(best_intervals_hybrid);
    }
    // BEGIN Investigate infeasible encode_nn_and_solve
    // pthread_mutex_lock(&lock);
    // if ((exit_prog == depth + 1) && (g_parent_tid == parent_tid)) {
    //     printf("Exiting at depth=%d, parent=%lu\nactive=%lu, inactive=%lu, hybrid=%lu\n",
    //             depth+1, parent_tid, active_tid, inactive_tid, hybrid_tid);
    //     exit(1);
    // }
    // pthread_mutex_unlock(&lock);
    // END Investigate infeasible encode_nn_and_solve
    return 0;
#endif // SINGLE_THREAD
}

