#include "nnet.h"

#include <assert.h>

int PROPERTY = 5;
char *LOG_FILE = "logs/log.txt";
FILE *fp;

/*
 * Load_network is a function modified from Reluplex
 * It takes in a nnet filename with path and load the
 * network from the file
 * Outputs the NNet instance of loaded network.
 */
struct NNet *load_network(const char* filename, int target)
{

    FILE *fstream = fopen(filename,"r");

    if (fstream == NULL) {
        printf("Wrong network!\n");
        exit(1);
    }

    int bufferSize = 20240;
    char *buffer = (char*)malloc(sizeof(char)*bufferSize);
    char *record, *line;
    int i=0, layer=0, row=0, j=0, param=0;

    struct NNet *nnet = (struct NNet*)malloc(sizeof(struct NNet));

    nnet->target = target;

    line=fgets(buffer,bufferSize,fstream);

    while (strstr(line, "//") != NULL) {
        line = fgets(buffer,bufferSize,fstream);
    }

    record = strtok(line,",\n");
    nnet->numLayers = atoi(record);
    nnet->inputSize = atoi(strtok(NULL,",\n"));
    nnet->outputSize = atoi(strtok(NULL,",\n"));
    nnet->maxLayerSize = atoi(strtok(NULL,",\n"));

    nnet->layerSizes = (int*)malloc(sizeof(int)*(nnet->numLayers+1));
    line = fgets(buffer,bufferSize,fstream);
    record = strtok(line,",\n");

    for (i = 0;i<((nnet->numLayers)+1);i++) {
        nnet->layerSizes[i] = atoi(record);
        record = strtok(NULL,",\n");
    }

    line = fgets(buffer,bufferSize,fstream);
    record = strtok(line,",\n");
    nnet->symmetric = atoi(record);

    nnet->mins = (double*)malloc(sizeof(double)*nnet->inputSize);
    line = fgets(buffer,bufferSize,fstream);
    record = strtok(line,",\n");

    for (i = 0;i<(nnet->inputSize);i++) {
        nnet->mins[i] = (double)atof(record);
        record = strtok(NULL,",\n");
    }

    nnet->maxes = (double*)malloc(sizeof(double)*nnet->inputSize);
    line = fgets(buffer,bufferSize,fstream);
    record = strtok(line,",\n");

    for (i = 0;i<(nnet->inputSize);i++) {
        nnet->maxes[i] = (double)atof(record);
        record = strtok(NULL,",\n");
    }

    nnet->means = (double*)malloc(sizeof(double)*(nnet->inputSize+1));
    line = fgets(buffer,bufferSize,fstream);
    record = strtok(line,",\n");

    for (i = 0;i<((nnet->inputSize)+1);i++) {
        nnet->means[i] = (double)atof(record);
        record = strtok(NULL,",\n");
    }

    nnet->ranges = (double*)malloc(sizeof(double)*(nnet->inputSize+1));
    line = fgets(buffer,bufferSize,fstream);
    record = strtok(line,",\n");

    for (i = 0;i<((nnet->inputSize)+1);i++) {
        nnet->ranges[i] = (double)atof(record);
        record = strtok(NULL,",\n");
    }

    nnet->dmatrix = (double****)malloc(sizeof(double *)*nnet->numLayers);

    for (layer = 0;layer<(nnet->numLayers);layer++) {
        nnet->dmatrix[layer] =\
                (double***)malloc(sizeof(double *)*2);
        nnet->dmatrix[layer][0] =\
                (double**)malloc(sizeof(double *)*nnet->layerSizes[layer+1]);
        nnet->dmatrix[layer][1] =\
                (double**)malloc(sizeof(double *)*nnet->layerSizes[layer+1]);

        for (row = 0;row<nnet->layerSizes[layer+1];row++) {
            nnet->dmatrix[layer][0][row] =\
                    (double*)malloc(sizeof(double)*nnet->layerSizes[layer]);
            nnet->dmatrix[layer][1][row] = (double*)malloc(sizeof(double));
        }

    }

    layer = 0;
    param = 0;
    i=0;
    j=0;

    char *tmpptr=NULL;

    double w = 0.0;

    while ((line = fgets(buffer,bufferSize,fstream)) != NULL) {

        if (i >= nnet->layerSizes[layer+1]) {

            if (param==0) {
                param = 1;
            }
            else {
                param = 0;
                layer++;
            }

            i=0;
            j=0;
        }

        record = strtok_r(line,",\n", &tmpptr);

        while (record != NULL) {
            w = (double)atof(record);
            nnet->dmatrix[layer][param][i][j] = w;
            j++;
            record = strtok_r(NULL, ",\n", &tmpptr);
        }

        tmpptr=NULL;
        j=0;
        i++;
    }

    double orig_weights[nnet->maxLayerSize];
    double orig_bias;

    struct DMatrix *weights = malloc(nnet->numLayers*sizeof(struct DMatrix));
    struct DMatrix *bias = malloc(nnet->numLayers*sizeof(struct DMatrix));

    for (int layer=0;layer<nnet->numLayers;layer++) {
        weights[layer].row = nnet->layerSizes[layer];
        weights[layer].col = nnet->layerSizes[layer+1];
        weights[layer].data = (double*)malloc(sizeof(double)\
                    * weights[layer].row * weights[layer].col);

        int n=0;

        // Output - target: does not work well for properties with single output NNs.
        // If using properties in if-statement we will not subtract the target from the output.
        if ((PROPERTY != 1) && (PROPERTY != 114) && (PROPERTY != 117) && (PROPERTY != 118) && (PROPERTY != 119)) {
        //if (false) {

            /* weights in the last layer minus the weights of true label output. */
            if (layer == nnet->numLayers-1) {

                orig_bias = nnet->dmatrix[layer][1][nnet->target][0];
                memcpy(orig_weights, nnet->dmatrix[layer][0][nnet->target],\
                            sizeof(double) * nnet->layerSizes[layer]);

                for (int i=0;i<weights[layer].col;i++) {

                    for (int j=0;j<weights[layer].row;j++) {
                        weights[layer].data[n] =\
                                nnet->dmatrix[layer][0][i][j]-orig_weights[j];
                        n++;
                    }

                }

                bias[layer].col = nnet->layerSizes[layer+1];
                bias[layer].row = (double)1;
                bias[layer].data = (double*)malloc(sizeof(double)*bias[layer].col);

                for (int i=0;i<bias[layer].col;i++) {
                    bias[layer].data[i] = nnet->dmatrix[layer][1][i][0]-orig_bias;
                }
            }
            else {

                for (int i=0;i<weights[layer].col;i++) {

                    for (int j=0;j<weights[layer].row;j++) {
                        weights[layer].data[n] = nnet->dmatrix[layer][0][i][j];
                        n++;
                    }

                }

                bias[layer].col = nnet->layerSizes[layer+1];
                bias[layer].row = (double)1;
                bias[layer].data = (double*)malloc(sizeof(double) *\
                                        bias[layer].col);

                for (int i=0;i<bias[layer].col;i++) {
                    bias[layer].data[i] = nnet->dmatrix[layer][1][i][0];
                }

            }
        }
        else {

            for (int i=0;i<weights[layer].col;i++) {

                for (int j=0;j<weights[layer].row;j++) {
                    weights[layer].data[n] = nnet->dmatrix[layer][0][i][j];
                    n++;
                }

            }

            bias[layer].col = nnet->layerSizes[layer+1];
            bias[layer].row = (double)1;
            bias[layer].data = (double*)malloc(sizeof(double)*bias[layer].col);

            for (int i=0;i<bias[layer].col;i++) {
                bias[layer].data[i] = nnet->dmatrix[layer][1][i][0];
            }

        }

    }

    nnet->weights = weights;
    nnet->bias = bias;

    free(buffer);
    fclose(fstream);

    return nnet;

}


/*
 * destroy_network is a function modified from Reluplex
 * It release all the memory mallocated to the network instance
 * It takes in the instance of nnet
 */
void destroy_network(struct NNet *nnet)
{

    int i=0, row=0;
    if (nnet != NULL) {

        for (i=0;i<(nnet->numLayers);i++) {

            for (row=0;row<nnet->layerSizes[i+1];row++) {
                free(nnet->dmatrix[i][0][row]);
                free(nnet->dmatrix[i][1][row]);
            }

            free(nnet->dmatrix[i][0]);
            free(nnet->dmatrix[i][1]);
            free(nnet->weights[i].data);
            free(nnet->bias[i].data);
            free(nnet->dmatrix[i]);
        }

        free(nnet->weights);
        free(nnet->bias);
        free(nnet->layerSizes);
        free(nnet->mins);
        free(nnet->maxes);
        free(nnet->means);
        free(nnet->ranges);
        free(nnet->dmatrix);
        free(nnet);
    }

}


/*
 * Load the inputs of all the predefined properties
 * It takes in the property and input pointers
 */
void load_inputs(int PROPERTY, int inputSize, struct DInterval *input_interval, char const *mnist_bounds)
{
    struct DMatrix *input_upper = (struct DMatrix*)malloc(sizeof(struct DMatrix)*(1));
    struct DMatrix *input_lower = (struct DMatrix*)malloc(sizeof(struct DMatrix)*(1));

    input_upper->data = (double*)malloc(sizeof(double)*(inputSize));
    input_upper->row = inputSize; //1;
    input_upper->col = 1; //inputSize;
    input_lower->data = (double*)malloc(sizeof(double)*(inputSize));
    input_lower->row = inputSize; //1;
    input_lower->col = 1; //inputSize;

    if ((PROPERTY == 114) || (PROPERTY == 115) || (PROPERTY == 117) || (PROPERTY == 118) || (PROPERTY == 119)) {
        double upper[] = {1, 1};
        double lower[] = {0, 0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 1)
    {
        // Same as ReluVal
        double upper[] = {60760,3.141592,3.141592, 1200, 60};
        double lower[] = {55947.691,-3.141592,-3.141592,1145,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 2)
    {
        // Same as ReluVal
        double upper[] = {60760,3.141592,3.141592, 1200, 60};
        double lower[] = {55947.691,-3.141592,-3.141592,1145,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 3)
    {
        // Same as ReluVal
        double upper[] = {1800,0.06,3.141592,1200,1200};
        double lower[] = {1500,-0.06,3.10,980,960};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 4)
    {
        // Same as ReluVal
        double upper[] = {1800, 0.06, 0, 1200, 800};
        double lower[] = {1500, -0.06, 0, 1000, 700};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 5)
    {
        // Same as ReluVal
        double upper[] = {400, 0.4, -3.1415926+0.005, 400, 400};
        double lower[] = {250, 0.2, -3.1415926, 100, 0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 16) // Considered as property 6.1
    {
        // Same as ReluVal
        double upper[] = {62000, -0.7, -3.141592+0.005, 200, 1200};
        double lower[] = {12000, -3.141592, -3.141592, 100,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 26) // Considered as property 6.2
    {
        // Same as ReluVal
        double upper[] = {62000, 3.141592, -3.141592+0.005, 200, 1200};
        double lower[] = {12000, 0.7, -3.141592, 100, 0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 7)
    {
        // Same as ReluVal
        double upper[] = {60760,3.141592,3.141592,1200,1200};
        double lower[] = {0,-3.141592,-3.141592,100,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 8)
    {
        // Same as ReluVal
        double upper[] = {60760,-3.141592*0.75,0.1,1200,1200};
        double lower[] = {0,-3.141592,-0.1,600,600};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 9)
    {
        // Same as ReluVal
        double upper[] = {7000,-0.14,-3.141592+0.01,150,150};
        double lower[] = {2000,-0.4,-3.141592,100,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 10)
    {
        // Same as ReluVal
        double upper[] = {60760,3.141592,-3.141592+0.01,1200,1200};
        double lower[] = {36000,0.7,-3.141592,900,600};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 11)
    {
        // Same as ReluVal
        double upper[] = {400,0.4,-3.1415926+0.005,400,400};
        double lower[] = {250,0.2,-3.1415926,100,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 12)
    {
        // Same as ReluVal
        double upper[] = {60760,3.141592,3.141592, 1200, 60};
        double lower[] = {55947.691,-3.141592,-3.141592,1145,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 13)
    {
        // Same as ReluVal
        double upper[] = {60760,3.141592,3.141592, 360, 360};
        double lower[] = {60000,-3.141592,-3.141592,0,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 14)
    {
        // Same as ReluVal
        double upper[] = {400,0.4,-3.1415926+0.005,400,400};
        double lower[] = {250,0.2,-3.1415926,100,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 15)
    {
        // Same as ReluVal
        double upper[] = {400,-0.2,-3.1415926+0.005,400,400};
        double lower[] = {250,-0.4,-3.1415926,100,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }

    else if (PROPERTY == 100)
    {
        // Same as ReluVal
        double upper[] = {400,0,-3.1415926+0.025,250,200};
        double lower[] = {250,0,-3.1415926+0.025,250,200};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 101)
    {
        // Same as ReluVal
        double upper[] = {400,0.4,-3.1415926+0.025,250,200};
        double lower[] = {250,0.2,-3.1415926+0.025,250,200};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 102)
    {
        // Same as ReluVal
        double upper[] = {400,0.2,-3.1415926+0.05,0,0};
        double lower[] = {250,0.2,-3.1415926+0.05,0,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }

    else if (PROPERTY == 110)
    {
        // Same as ReluVal
        double upper[] = {10000,3.141592,-3.141592+0.01,1200,1200};
        double lower[] = {1000,3.141592,-3.141592+0.01,1200,1200};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 111)
    {
        // Same as ReluVal
        double upper[] = {1000,3.141592,-3.141592+0.01,1200,1200};
        double lower[] = {1000,3.141592,-3.141592+0.01,0,1200};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 112)
    {
        // Same as ReluVal
        double upper[] = {1000,3.141592,-3.141592+0.01,1200,1200};
        double lower[] = {1000,3.141592,-3.141592+0.01,1200,0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 120)
    {
        double upper[] = {1.0, 1.0};
        double lower[] = {0.0, 0.0};
        memcpy(input_upper->data, upper, sizeof(double)*inputSize);
        memcpy(input_lower->data, lower, sizeof(double)*inputSize);
    }
    else if (PROPERTY == 1000 || PROPERTY == 1001)
    {
        FILE *bounds_file = fopen(mnist_bounds, "r");
        if (bounds_file == NULL) {
            printf("Could not open MNIST bounds file %s\n", mnist_bounds);
            exit(1);
        }

        int const buffer_size = 20240;
        char *buffer = (char*) malloc(sizeof(char) * buffer_size);

        char *record, *line;
        line = fgets(buffer, buffer_size, bounds_file);
        while (strstr(line, "//") != NULL) {
            line = fgets(buffer, buffer_size, bounds_file);
        }

        record = strtok(line, ",\n");
        int size = atoi(record);
        assert(size == inputSize);

        double *mins = (double*) malloc(sizeof(double) * inputSize);
        double *maxs = (double*) malloc(sizeof(double) * inputSize);

        line = fgets(buffer, buffer_size, bounds_file);
        record = strtok(line, ",\n");
        for (int i = 0; i < inputSize; i++) {
            mins[i] = atof(record);
            record = strtok(NULL, ",\n");
        }

        line = fgets(buffer, buffer_size, bounds_file);
        record = strtok(line, ",\n");
        for (int i = 0; i < inputSize; i++) {
            maxs[i] = atof(record);
            record = strtok(NULL, ",\n");
        }

        memcpy(input_lower->data, mins, sizeof(double) * inputSize);
        memcpy(input_upper->data, maxs, sizeof(double) * inputSize);

        free(mins);
        free(maxs);
        free(buffer);
        fclose(bounds_file);
    }
    else
    {
        printf("No input associated to property %d!!\n",PROPERTY);
        exit(1);
    }

    input_interval->lower_dmatrix = input_lower;
    input_interval->upper_dmatrix = input_upper;

}



/*
 * Following functions denomalize and normalize the concrete inputs
 * and input intervals.
 * They take in concrete inputs or input intervals.
 * Output normalized or denormalized concrete inputs or input intervals.
 */
void denormalize_input(struct NNet *nnet, struct DMatrix *input)
{
    for (int i=0; i<nnet->inputSize;i++) {
        input->data[i] = input->data[i]*(nnet->ranges[i]) + nnet->means[i];
    }
}

void denormalize_input_interval(struct NNet *nnet, struct DInterval *input)
{
    denormalize_input(nnet, input->upper_dmatrix);
    denormalize_input(nnet, input->lower_dmatrix);
}

void normalize_input(struct NNet *nnet, struct DMatrix *input)
{

    for (int i=0;i<nnet->inputSize;i++) {

        if (input->data[i] > nnet->maxes[i]) {
            input->data[i] = (nnet->maxes[i]-nnet->means[i])/(nnet->ranges[i]);
        }
        else if (input->data[i] < nnet->mins[i]) {
            input->data[i] = (nnet->mins[i]-nnet->means[i])/(nnet->ranges[i]);
        } else {
            input->data[i] = (input->data[i]-nnet->means[i])/(nnet->ranges[i]);
        }
    }
}

void normalize_input_interval(struct NNet *nnet, struct DInterval *input)
{
    normalize_input(nnet, input->upper_dmatrix);
    normalize_input(nnet, input->lower_dmatrix);
}

/*
 * Concrete forward propagation with openblas
 * It takes in network and concrete input matrix.
 * Outputs the concrete outputs.
 */
int forward_prop(struct NNet *network, struct DMatrix *input, struct DMatrix *output)
{

    int i,j,layer;

    struct NNet* nnet = network;
    int numLayers    = nnet->numLayers;
    int inputSize    = nnet->inputSize;
    int outputSize   = nnet->outputSize;

    double z[nnet->maxLayerSize];
    double a[nnet->maxLayerSize];
    struct DMatrix Z = {z, 1, inputSize};
    struct DMatrix A = {a, 1, inputSize};

    memcpy(Z.data, input->data, nnet->inputSize*sizeof(double));

    for(layer=0;layer<numLayers;layer++){
        A.row = nnet->bias[layer].row;
        A.col = nnet->bias[layer].col;
        memcpy(A.data, nnet->bias[layer].data, A.row*A.col*sizeof(double));

        matmul_with_bias(&Z, &nnet->weights[layer], &A);
        if(layer<numLayers-1){
            relu(&A);
        }
        memcpy(Z.data, A.data, A.row*A.col*sizeof(double));
        Z.row = A.row;
        Z.col = A.col;

    }

    memcpy(output->data, A.data, A.row*A.col*sizeof(double));
    output->row = A.row;
    output->col = A.col;

    return 1;
}

void linear_symbolic_step(int inputSize, int maxLayerSize, \
                    struct DInterval *equation_interval, \
                    struct DMatrix* weights, struct DMatrix* bias,\
                    struct DInterval *new_equation_interval)
{   // compute new_equation_interval after base transformation with origin bias
    assert(equation_interval->upper_dmatrix->row == inputSize + 1);
    assert(equation_interval->lower_dmatrix->row == inputSize + 1);
    assert(new_equation_interval->upper_dmatrix->row == inputSize + 1);
    assert(new_equation_interval->upper_dmatrix->row == inputSize + 1);

    int layerSize = weights->row;
    int nextLayerSize = weights->col;
#ifdef DEBUG
    printf("weights:\n");
    printDMatrix(weights);
#endif

    assert(equation_interval->upper_dmatrix->col == layerSize);
    assert(equation_interval->lower_dmatrix->col == layerSize);

    memset(new_equation_interval->upper_dmatrix->data, 0, sizeof(double) * (inputSize + 1) * maxLayerSize);
    memset(new_equation_interval->lower_dmatrix->data, 0, sizeof(double) * (inputSize + 1) * maxLayerSize);

    new_equation_interval->lower_dmatrix->col = nextLayerSize;
    new_equation_interval->upper_dmatrix->col = nextLayerSize;


    double p[layerSize * nextLayerSize];
    memset(p, 0, sizeof(double) * layerSize * nextLayerSize);
    struct DMatrix pos_weights = {p, layerSize, nextLayerSize};

    double n[layerSize * nextLayerSize];
    memset(n, 0, sizeof(double) * layerSize * nextLayerSize);
    struct DMatrix neg_weights = {n, layerSize, nextLayerSize};

    // identify positive and negative coefficients at current layer
    for (int i = 0; i < layerSize * nextLayerSize; i++){
        if (weights->data[i] >= 0){
            pos_weights.data[i] = weights->data[i];
        }else{
            neg_weights.data[i] = weights->data[i];
        }
    }

#ifdef DEBUG
    printf("positive weights:\n");
    printDMatrix(&pos_weights);
    printf("negative weights:\n");
    printDMatrix(&neg_weights);
#endif

    // symbolic uppers of next-layer intervals: positives * symbolic uppers of current intervals + negatives * symbolic lowers of current intervals
    matmul(equation_interval->upper_dmatrix, &pos_weights, new_equation_interval->upper_dmatrix);
    matmul_with_bias(equation_interval->lower_dmatrix, &neg_weights, new_equation_interval->upper_dmatrix);
    // symbolic lowers of next-layer intervals: positives * symbolic lowers of current intervals + negatives * symbolic uppers of current intervals
    matmul(equation_interval->lower_dmatrix, &pos_weights, new_equation_interval->lower_dmatrix);
    matmul_with_bias(equation_interval->upper_dmatrix, &neg_weights, new_equation_interval->lower_dmatrix);

    // add bias in symbolic intervalss and in lower/upper values of lower/upper symbolic intervalss
    for(int i=0; i < nextLayerSize; i++){
        new_equation_interval->lower_dmatrix->data[i * (inputSize + 1) + inputSize] += bias->data[i];
        new_equation_interval->upper_dmatrix->data[i * (inputSize + 1) + inputSize] += bias->data[i];
    }
}

void initialize_symbolic_intervals(double *lower, double *upper, int inputSize, int maxLayerSize, \
    struct DMatrix *current_base_in_old, struct DMatrix *current_origin_in_old)
{
    // This adds the initial base transposed, which is correct.
    // This is correct since we do matrix multiplication by column instead of by row.
    memset(upper, 0, sizeof(double) * (inputSize + 1) * maxLayerSize);
    memset(lower, 0, sizeof(double) * (inputSize + 1) * maxLayerSize);

    for (int col = 0; col < inputSize; col++){ //initial equations are exact
        for (int row = 0; row < inputSize; row++){ //initial equations are exact
            lower[col * (inputSize + 1) + row] = current_base_in_old->data[row * inputSize + col];
            upper[col * (inputSize + 1) + row] = current_base_in_old->data[row * inputSize + col];
        }
        lower[col * (inputSize+1) + inputSize] = current_origin_in_old->data[col];
        upper[col * (inputSize+1) + inputSize] = current_origin_in_old->data[col];
    }
}

void reset_eq_interval_vals(struct EqIntervalVals *eq_int_vals)
{
    eq_int_vals->eq_lo.lo = 0.0;
    eq_int_vals->eq_lo.up = 0.0;
    eq_int_vals->eq_up.lo = 0.0;
    eq_int_vals->eq_up.up = 0.0;
}

void print_eq_interval_vals(struct EqIntervalVals *eq_int_vals)
{
    printf("eq_lo.lo = %.20f\n", eq_int_vals->eq_lo.lo);
    printf("eq_lo.up = %.20f\n", eq_int_vals->eq_lo.up);
    printf("eq_up.lo = %.20f\n", eq_int_vals->eq_up.lo);
    printf("eq_up.up = %.20f\n", eq_int_vals->eq_up.up);
}

void meet_eq_interval_vals(
        struct EqIntervalVals *a,
        struct EqIntervalVals *b,
        struct EqIntervalVals *res)
{
    res->eq_lo.lo =
        b->eq_lo.lo < a->eq_lo.lo ? a->eq_lo.lo : b->eq_lo.lo;
    res->eq_lo.up =
        b->eq_lo.up < a->eq_lo.up ? b->eq_lo.up : a->eq_lo.up;
    res->eq_up.lo =
        b->eq_up.lo < a->eq_up.lo ? a->eq_up.lo : b->eq_up.lo;
    res->eq_up.up =
        b->eq_up.up < a->eq_up.up ? b->eq_up.up : a->eq_up.up;
}

void compute_concrete_intervals(
        struct DInterval *new_equation_interval,
        struct DInterval *input,
        int const input_size,
        int const current_neuron,
        double const outward_round,
        struct EqIntervalVals *eq_int_vals)
{
    for (int k = 0; k < input_size; k++) {
        // Compute concrete intervals in new base
        if (new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] >= 0) {
            eq_int_vals->eq_lo.lo +=
                (new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->lower_dmatrix->data[k]) - outward_round;
            eq_int_vals->eq_lo.up +=
                (new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->upper_dmatrix->data[k]) - outward_round;
        } else {
            eq_int_vals->eq_lo.lo +=
                (new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->upper_dmatrix->data[k]) - outward_round;
            eq_int_vals->eq_lo.up +=
                (new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->lower_dmatrix->data[k]) - outward_round;
        }
        if (new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)] >= 0) {
            eq_int_vals->eq_up.up +=
                (new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->upper_dmatrix->data[k]) + outward_round;
            eq_int_vals->eq_up.lo +=
                (new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->lower_dmatrix->data[k]) + outward_round;
        } else {
            eq_int_vals->eq_up.up +=
                (new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->lower_dmatrix->data[k]) + outward_round;
            eq_int_vals->eq_up.lo +=
                (new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->upper_dmatrix->data[k]) + outward_round;
        }
    }

    eq_int_vals->eq_lo.lo +=
        new_equation_interval->lower_dmatrix->data[input_size + current_neuron * (input_size + 1)];
    eq_int_vals->eq_lo.up +=
        new_equation_interval->lower_dmatrix->data[input_size + current_neuron * (input_size + 1)];
    eq_int_vals->eq_up.up +=
        new_equation_interval->upper_dmatrix->data[input_size + current_neuron * (input_size + 1)];
    eq_int_vals->eq_up.lo +=
        new_equation_interval->upper_dmatrix->data[input_size + current_neuron * (input_size + 1)];
}

void compute_relu_approximations(
        struct EqIntervalVals const *eq_int_vals,
        int const input_size,
        int const current_neuron,

        int const max_layer_size,
        int const current_layer,
        int *activations_history,

        struct IntervalVals **best_intervals,

        struct DInterval *input,
        struct DInterval *new_equation_interval)
{
    double const best_lo = best_intervals[current_neuron + current_layer * max_layer_size]->lo;
    double const best_up = best_intervals[current_neuron + current_layer * max_layer_size]->up;

    if (eq_int_vals->eq_up.up <= 0.0 || (activations_history[current_neuron + current_layer * max_layer_size] == 0)) {
    // if (best_up <= 0.0) {
        // Inactive Relu, both upper and lower symbolic intervals go to 0
        for (int k = 0; k < input_size + 1; k++) {
            new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)] = 0;
            new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] = 0;
        }
    } else if (eq_int_vals->eq_up.up > 0 && eq_int_vals->eq_lo.lo < 0) { // eq_up.up > 0, eq_lo.lo < 0
    // } else if (best_up > 0.0 && best_lo < 0.0) { // eq_up.up > 0, eq_lo.lo < 0

        /*
        double const slope = best_up / (best_up - best_lo);
        for (int k = 0; k < input_size + 1; k++) {
            new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)] =
                new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)] * slope;

            new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] =
                new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] * slope;
        }
        new_equation_interval->upper_dmatrix->data[input_size + current_neuron * (input_size + 1)] -=
            best_up * slope;
        */

        // Hybrid Relu
        if (eq_int_vals->eq_up.lo < 0.0) {
            for (int k = 0; k < input_size + 1; k++) {
                new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)] =
                    new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)] *
                    eq_int_vals->eq_up.up / (eq_int_vals->eq_up.up - eq_int_vals->eq_up.lo);
            }
            new_equation_interval->upper_dmatrix->data[input_size + current_neuron * (input_size + 1)] -=
                eq_int_vals->eq_up.up * eq_int_vals->eq_up.lo / (eq_int_vals->eq_up.up - eq_int_vals->eq_up.lo);
        }

        if (eq_int_vals->eq_lo.up < 0.0) {
            // Lower concrete intervals are for sure less than 0.
            // Set lower symbolic intervals to 0.
            for (int k = 0; k < input_size + 1; k++) {
                new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] = 0;
            }
        } else {
            // Lower bound of ReLU approximation
            for (int k = 0; k < input_size + 1; k++) {
                new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] =
                    new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] *
                    eq_int_vals->eq_lo.up / (eq_int_vals->eq_lo.up - eq_int_vals->eq_lo.lo );

            }
        }
    }
}

void compute_activations(
        struct DInterval *equation_interval,
        struct DInterval *input,
        int const input_size,
        int const current_layer,
        int const current_neuron,
        int const max_layer_size,
        double const outward_round,
        int *activations)
{
    struct EqIntervalVals concrete_vals_activation = {
        .eq_lo = {0.0, 0.0},
        .eq_up = {0.0, 0.0}
    };
    compute_concrete_intervals(
            equation_interval,
            input,
            input_size,
            current_neuron,
            outward_round,
            &concrete_vals_activation);
#ifdef DEBUG
    printf("In compute activation: l=%d, n=%d\n", current_layer, current_neuron);
    print_eq_interval_vals(&concrete_vals_activation);
#endif

    if (concrete_vals_activation.eq_up.up <= 0.0) {
        // Inactive Relu, both upper and lower symbolic intervalss go to 0
        activations[current_neuron + current_layer * max_layer_size] = 0;
    } else if (concrete_vals_activation.eq_lo.lo >= 0.0) {
        // Cheaply fully active Relu. Keep symbolic intervalss and bounds
        activations[current_neuron + current_layer * max_layer_size] = 2;
    } else { // eq_up.up > 0, eq_lo.lo < 0
        // Hybrid Relu
        activations[current_neuron + current_layer * max_layer_size] = 1;
    }

}

void strengthen_output_bounds(
        struct EqIntervalVals const *eq_int_vals,
        int const current_neuron,
        struct DInterval *output)
{
    output->upper_dmatrix->data[current_neuron] =
        (eq_int_vals->eq_up.up < output->upper_dmatrix->data[current_neuron] ?
         eq_int_vals->eq_up.up : output->upper_dmatrix->data[current_neuron]);
    output->lower_dmatrix->data[current_neuron] =
        (eq_int_vals->eq_lo.lo > output->lower_dmatrix->data[current_neuron] ?
         eq_int_vals->eq_lo.lo : output->lower_dmatrix->data[current_neuron]);
}

void get_old_in_new_expr(
        struct DMatrix *new_base,
        struct DMatrix *new_origin,
        struct DMatrix *old_base_in_new,
        struct DMatrix *old_origin_in_new)
{
    /*
    From

        P_o = B_n/o * P_n + O_n/o

    we get

        P_n = inv(B_n/o) * P_o - inv(B_n/o) * O_n/o     (where inv(.) is the inverse).

    Since we are working with ON-bases inv(B) = t(B) (t(.) is the transpose) so we get

        P_n = t(B_n/o) * P_o - t(B_n/o) * O_n/o.

    From this we can see that

        B_o/n = t(B_n/o),   (old_base_in_new below)
        O_o/n = -t(B_n/o) * O_n/o (old_origin_in_new below).
    */
    // Tranpose...
    for (int c = 0; c < old_base_in_new->col; c++) {
        for (int r = 0; r < old_base_in_new->row; r++) {
            old_base_in_new->data[r + c * old_base_in_new->row] = new_base->data[c + r * old_base_in_new->col];
        }
    }
    // Scale the resulting matrix with -1.0 such that we always use addition when computing offset
    matmul_with_factor(old_base_in_new, new_origin, old_origin_in_new, -1.0, 1.0);
}

void construct_transformation_matrix(
        struct DMatrix *base_transposed,
        struct DMatrix *origin,
        int const input_size,
        struct DMatrix *transformation_matrix)
{
    // We will be using the transpose of the transformation matrix we came up with, since it will give the
    // resulting equation in the correct form (otherwise the result would be transposed).
    // Therefore, when constructing the transformation matrix I want to use the transposed base matrix
    // (old_base_in_new), which actually happens to be the new base (new_base). Holds both ways.

    /*

        Some explanation of the following code.
        Here we are constructing our transformation matrices (The transpose of what we came up with on 2025-03-13.)
        The matrices are used to transform equations expressed in the new base such that they are expressed in the
        old base, and vice versa.

        The layout of the transformation matrix to transform equations in the new base to the old base is

                   ^       0
                   |       .
            <- t(B_o/n) -> .
                   |       .
                   v       0
            <- t(O_o/n) -> 1

        Where t(.) denotes the transpose.

        Concrete example:
            B_o/n =
                -1/sqrt(2)  1/sqrt(2)
                 1/sqrt(2)  1/sqrt(2)
            O_o/n =
                 0
                -sqrt(2)/4

            Then the transformation matrix is

                -1/sqrt(2)  1/sqrt(2)   0

                 1/sqrt(2)  1/sqrt(2)   0

                 0         -sqrt(2)/4   1

        Some observations:
            - The dimension of the transformation matrix is input_size + 1 x input_size + 1
            - Since we work with ON-bases t(B_o/n) = B_n/o. Because of this, when constructing the transformation
                matrix to transform equations from new to old, we will use the DMatrix new_base as base_transposed.
            - The final column in the transformation matrix is used to carry over offsets.
    */
    // Enjoy the index acrobatics
    // This part copies the base_transposed and origin to the transformation matrix as shown above.
    for (int i = 0; i < input_size; i++) {
        for (int j = 0; j < input_size; j++) {
            // Copy i-th column of base_transposed to transformation_matrix
            transformation_matrix->data[(input_size + 1) * i + j] = base_transposed->data[input_size * i + j];
        }
        // Copy i-th entry in origin to bottom row and i-th column of transformation matrix.
        transformation_matrix->data[(input_size + 1) * i + input_size] = origin->data[i];
    }
    // This part fills in the final column with zeroes, and finally a 1.
    for (int i = 0; i < input_size; i++) {
        transformation_matrix->data[(input_size + 1) * input_size + i] = 0;
    }
    transformation_matrix->data[(input_size + 1) * input_size + input_size] = 1;
}

void translate_equation(
        int const input_size,
        int const current_neuron,
        struct DMatrix *transform,
        struct DInterval *eq_interval,
        struct DInterval *eq_interval_trnsl)
{
    // Enjoy the pointer acrobatics
    struct DMatrix current_eq_lo = {
        .data = eq_interval->lower_dmatrix->data + ((input_size + 1) * current_neuron), // Is this allowed?
        .row = (input_size + 1),
        .col = 1
    };

    struct DMatrix current_eq_up = {
        .data = eq_interval->upper_dmatrix->data + ((input_size + 1) * current_neuron),
        .row = (input_size + 1),
        .col = 1
    };

    struct DMatrix trnsl_eq_lo = {
        .data = eq_interval_trnsl->lower_dmatrix->data + ((input_size + 1) * current_neuron),
        .row = (input_size + 1),
        .col = 1
    };

    struct DMatrix trnsl_eq_up = {
        .data = eq_interval_trnsl->upper_dmatrix->data + ((input_size + 1) * current_neuron),
        .row = (input_size + 1),
        .col = 1
    };

    matmul(transform, &current_eq_lo, &trnsl_eq_lo);
    matmul(transform, &current_eq_up, &trnsl_eq_up);
}

void translate_all_equations(
        int const input_size,
        int const current_neuron,
        struct DMatrix *new_to_old_transform,
        struct DMatrix *old_to_new_transform,
        struct DInterval *eq_interval_new_base,
        struct DInterval *eq_interval_old_base,
        struct DInterval *eq_interval_new_base_trnsl_to_old,
        struct DInterval *eq_interval_old_base_trnsl_to_new)
{
    translate_equation(
            input_size,
            current_neuron,
            new_to_old_transform,
            eq_interval_new_base,
            eq_interval_new_base_trnsl_to_old);

    translate_equation(
            input_size,
            current_neuron,
            old_to_new_transform,
            eq_interval_old_base,
            eq_interval_old_base_trnsl_to_new);
}


void copy_equation(
        int const current_neuron,
        int const input_size,
        struct DInterval *src,
        struct DInterval *dst)
{
    // Each column has length input_size + 1 (number of rows...)
    for (int i = 0; i < (input_size + 1); i++) {
        dst->lower_dmatrix->data[(input_size + 1) * current_neuron + i] =
            src->lower_dmatrix->data[(input_size + 1) * current_neuron + i];
        dst->upper_dmatrix->data[(input_size + 1) * current_neuron + i] =
            src->upper_dmatrix->data[(input_size + 1) * current_neuron + i];
    }
}

// Test:
//      Compute difference between eq_lo.up and eq_up.up (and .lo) for the different equations.
//      Choose equations which yields the smallest difference.
// In our example, third neuron (current_neuron = 2) after ReLU should trigger if-statement
void compare_equations2(
        int const current_neuron,
        int const input_size,
        struct DInterval *eq_interval,
        struct EqIntervalVals *concrete_vals,
        struct DInterval *eq_interval_trnsl,
        struct EqIntervalVals *concrete_vals_trnsl)
{


    // Possibly add condition that non-translated equation is hybrid?
    // I.e, concrete_vals->eq_lo.lo < 0 && concrete_vals->eq_up.up > 0
    // Motivation is that it is unnecessary to change equations if non-translated equation
    // already is non-hybrid.
    // General idea when comparing is that if we deem the non-translated and the translated equations
    // to be equally good, then keep the non-translated one.
    // One reason for this is that it would probably have less rounding errors.
    if (concrete_vals_trnsl->eq_up.up < 0) {
        // Translated equation is fully inactive, use since it is linear.
        printf("Translated equation inactive\n");
        copy_equation(current_neuron, input_size, eq_interval_trnsl, eq_interval);
    } else if (concrete_vals_trnsl->eq_lo.lo >= 0) {
        // Translated equation is fully active, use since it is linear
        printf("Translated equation active\n");
        copy_equation(current_neuron, input_size, eq_interval_trnsl, eq_interval);
    } else {
        printf("Translated equation hybrid: [%.20f, %.20f]\n",
                concrete_vals_trnsl->eq_lo.lo,
                concrete_vals_trnsl->eq_up.up);

        // Use only this part in abs value nnet
        // Difference between eq_up.up and eq_lo.lo
        double interval_length = concrete_vals->eq_up.up - concrete_vals->eq_lo.lo;
        double trnsl_interval_length = concrete_vals_trnsl->eq_up.up - concrete_vals_trnsl->eq_lo.lo;

        // Need to consider both lower and upper equations...?

        double interval_diff = interval_length - trnsl_interval_length;
        interval_diff = (interval_diff < 0 ? -interval_diff : interval_diff);
        if (interval_diff < 1e-6) { // Very small difference means they should be equal...
            trnsl_interval_length = interval_length;
        }

        if (interval_length > trnsl_interval_length) {
            // Bounds from translated equation is tighter, use translated equation instead.
            // Copy column in eq_interval_trnsl that corresponds to the current neuron
            // into eq_interval
            copy_equation(current_neuron, input_size, eq_interval_trnsl, eq_interval);
        }
    }
}

void compare_equations(
        int const current_neuron,
        int const input_size,
        struct DInterval *eq_interval,
        struct EqIntervalVals *concrete_vals,
        struct DInterval *eq_interval_trnsl,
        struct EqIntervalVals *concrete_vals_trnsl)
{
    // Difference between eq_up.up and eq_lo.lo
    double interval_length = concrete_vals->eq_up.up - concrete_vals->eq_lo.lo;
    double trnsl_interval_length = concrete_vals_trnsl->eq_up.up - concrete_vals_trnsl->eq_lo.lo;
    if (interval_length > trnsl_interval_length) {
        // Bounds from translated equation is tighter, use translated equation instead.
        copy_equation(current_neuron, input_size, eq_interval_trnsl, eq_interval);
    }
}

void compute_all_concrete_intervals(
        int const input_size,
        int const current_neuron,
        double const outward_round,

        struct DInterval *new_input,
        struct DInterval *old_input,

        struct DInterval *new_equation_interval_new_base,
        struct EqIntervalVals *concrete_vals_new,

        struct DInterval *eq_interval_old_base_trnsl_to_new,
        struct EqIntervalVals *concrete_vals_old_trnsl_new,

        struct DInterval *new_equation_interval_old_base,
        struct EqIntervalVals *concrete_vals_old,

        struct DInterval *eq_interval_new_base_trnsl_to_old,
        struct EqIntervalVals *concrete_vals_new_trnsl_old)
{
    // Also, reset each interval before
    reset_eq_interval_vals(concrete_vals_new);
    reset_eq_interval_vals(concrete_vals_old_trnsl_new);
    reset_eq_interval_vals(concrete_vals_old);
    reset_eq_interval_vals(concrete_vals_new_trnsl_old);

    // New base
    compute_concrete_intervals(
            new_equation_interval_new_base,
            new_input,
            input_size,
            current_neuron,
            outward_round,
            concrete_vals_new);

    // Old base translated to new base
    compute_concrete_intervals(
            eq_interval_old_base_trnsl_to_new,
            new_input,
            input_size,
            current_neuron,
            outward_round,
            concrete_vals_old_trnsl_new);

    // Old base
    compute_concrete_intervals(
            new_equation_interval_old_base,
            old_input,
            input_size,
            current_neuron,
            outward_round,
            concrete_vals_old);

    // New base translated to old base
    compute_concrete_intervals(
            eq_interval_new_base_trnsl_to_old,
            old_input,
            input_size,
            current_neuron,
            outward_round,
            concrete_vals_new_trnsl_old);

}

void compute_all_relu_approximations(
        int const input_size,
        int const current_neuron,

        int const max_layer_size,
        int const current_layer,
        int *activations_history,

        struct IntervalVals **best_intervals,

        struct DInterval *new_input,
        struct DInterval *old_input,

        struct DInterval *new_equation_interval_new_base,
        struct EqIntervalVals *concrete_vals_new,

        struct DInterval *new_equation_interval_old_base,
        struct EqIntervalVals *concrete_vals_old)
{
    // ReLU activations new base
    compute_relu_approximations(
            concrete_vals_new,
            input_size,
            current_neuron,

            max_layer_size,
            current_layer,
            activations_history,

            best_intervals,

            new_input,
            new_equation_interval_new_base);

    // ReLU activations old base
    compute_relu_approximations(
            concrete_vals_old,
            input_size,
            current_neuron,

            max_layer_size,
            current_layer,
            activations_history,

            best_intervals,

            old_input,
            new_equation_interval_old_base);
}

void print_current_neuron_equation(struct DInterval *equation, int const current_neuron, int const input_size)
{
    printf("Lower: [");
    for (int i = 0; i < (input_size + 1); i++) {
        double val = equation->lower_dmatrix->data[(input_size + 1) * current_neuron + i];
        if (i != input_size) {
            printf("%.20f ", val);
        } else {
            printf("%.20f", val);
        }
    }
    printf("]\n");
    printf("Upper: [");
    for (int i = 0; i < (input_size + 1); i++) {
        double val = equation->upper_dmatrix->data[(input_size + 1) * current_neuron + i];
        if (i != input_size) {
            printf("%.20f ", val);
        } else {
            printf("%.20f", val);
        }
    }
    printf("]\n");
}

struct NeuronInfo *allocate_NeuronInfo(int const input_size)
{
    double *data_lo = (double*) malloc(sizeof(double) * (input_size + 1));
    double *data_up = (double*) malloc(sizeof(double) * (input_size + 1));
    struct DMatrix *lo_mat = (struct DMatrix*)malloc(sizeof(struct DMatrix));
    lo_mat->data = data_lo;
    lo_mat->row = 1;
    lo_mat->col = input_size + 1;
    struct DMatrix *up_mat = (struct DMatrix*)malloc(sizeof(struct DMatrix));
    up_mat->data = data_up;
    up_mat->row = 1;
    up_mat->col = input_size + 1;

    struct DInterval *eq = (struct DInterval*)malloc(sizeof(struct DInterval));
    eq->lower_dmatrix = lo_mat;
    eq->upper_dmatrix = up_mat;

    struct NeuronInfo *ni = (struct NeuronInfo*)malloc(sizeof(struct NeuronInfo));
    ni->equation = eq;
    ni->l = -1;
    ni->n = -1;
    ni->state = -1;

    return ni;
}

void free_NeuronInfo(struct NeuronInfo *ni)
{
    free(ni->equation->lower_dmatrix->data);
    free(ni->equation->upper_dmatrix->data);
    free(ni->equation->lower_dmatrix);
    free(ni->equation->upper_dmatrix);
    free(ni->equation);
    free(ni);
    ni = NULL;
}

void print_NeuronInfo(struct NeuronInfo *ni)
{
    printf("NeuronInfo: l=%d, n=%d\n", ni->l, ni->n);
    printf("lower "); printDMatrix(ni->equation->lower_dmatrix);
    printf("upper "); printDMatrix(ni->equation->upper_dmatrix);
}

void symbolic_forward_simultaneous_analysis(
        struct NNet *nnet,
        struct DMatrix *new_base,
        struct DMatrix *new_origin,
        struct DInterval *new_input,
        struct DMatrix *old_base,
        struct DMatrix *old_origin,
        struct DInterval *old_input,
        struct DInterval *output,
        int *activations_old,
        int *activations_new,
        int *activations_history,

        struct IntervalVals *neuron_inputs,
        struct IntervalVals *neuron_inputs_in_new,

        struct IntervalVals **best_intervals,

        int const set_dir,
        struct NeuronInfo *bad_neurons[]
        // int const worst_neuron_layer,
        // int const worst_neuron,
        // double *direction_equation
        )
{
    double applied_outward_round = 0;

    int dir_chosen = 0;

    int const num_layers = nnet->numLayers;
    int const input_size = nnet->inputSize;
    int const output_size = nnet->outputSize;
    int const max_layer_size = nnet->maxLayerSize;

    // Init symbolic intervals for new base
    double equation_lower_new_base[(input_size + 1) * max_layer_size];
    double equation_upper_new_base[(input_size + 1) * max_layer_size];
    struct DInterval equation_interval_new_base = {
        .lower_dmatrix =
            &(struct DMatrix){(double *)equation_lower_new_base, input_size + 1, input_size},
        .upper_dmatrix =
            &(struct DMatrix){(double *)equation_upper_new_base, input_size + 1, input_size}
    };
    double new_equation_lower_new_base[(input_size + 1) * max_layer_size];
    double new_equation_upper_new_base[(input_size + 1) * max_layer_size];
    struct DInterval new_equation_interval_new_base = {
        .lower_dmatrix =
            &(struct DMatrix){(double *)new_equation_lower_new_base, input_size + 1, max_layer_size},
        .upper_dmatrix =
            &(struct DMatrix){(double *)new_equation_upper_new_base, input_size + 1, max_layer_size}
    };
    // This also perform affine transformation encoding the new base.
    initialize_symbolic_intervals(
            equation_lower_new_base,
            equation_upper_new_base,
            input_size,
            max_layer_size,
            new_base,
            new_origin);

    // Init symbolic intervals for old base
    double equation_lower_old_base[(input_size + 1) * max_layer_size];
    double equation_upper_old_base[(input_size + 1) * max_layer_size];
    struct DInterval equation_interval_old_base = {
        .lower_dmatrix =
            &(struct DMatrix){(double *)equation_lower_old_base, input_size + 1, input_size},
        .upper_dmatrix =
            &(struct DMatrix){(double *)equation_upper_old_base, input_size + 1, input_size}
    };
    double new_equation_lower_old_base[(input_size + 1) * max_layer_size];
    double new_equation_upper_old_base[(input_size + 1) * max_layer_size];
    struct DInterval new_equation_interval_old_base = {
        .lower_dmatrix =
            &(struct DMatrix){(double *)new_equation_lower_old_base, input_size + 1, max_layer_size},
        .upper_dmatrix =
            &(struct DMatrix){(double *)new_equation_upper_old_base, input_size + 1, max_layer_size}
    };
    initialize_symbolic_intervals(
            equation_lower_old_base,
            equation_upper_old_base,
            input_size,
            max_layer_size,
            old_base,
            old_origin);

    double old_base_in_new_data[input_size * input_size];
    memset(old_base_in_new_data, 0.0, sizeof(double) * (input_size * input_size));
    struct DMatrix old_base_in_new = {
        .data = old_base_in_new_data,
        .row = input_size,
        .col = input_size
    };
    double old_origin_in_new_data[input_size];
    memset(old_origin_in_new_data, 0.0, sizeof(double) * input_size);
    struct DMatrix old_origin_in_new = {
        .data = old_origin_in_new_data,
        .row = input_size,
        .col = 1
    };
    get_old_in_new_expr(new_base, new_origin, &old_base_in_new, &old_origin_in_new);

    // New to old
    double new_to_old_transform_data[(input_size + 1) * (input_size + 1)];
    struct DMatrix new_to_old_transform = {
        .data = new_to_old_transform_data,
        .row = input_size + 1,
        .col = input_size + 1
    };
    construct_transformation_matrix(
            new_base,
            &old_origin_in_new,
            input_size,
            &new_to_old_transform);

    double old_to_new_transform_data[(input_size + 1) * (input_size + 1)];
    struct DMatrix old_to_new_transform = {
        .data = old_to_new_transform_data,
        .row = input_size + 1,
        .col = input_size + 1
    };
    construct_transformation_matrix(
            &old_base_in_new,
            new_origin,
            input_size,
            &old_to_new_transform);

#ifdef DEBUG
    printf("== In symbolic forward simul. =======================================\n");
    printf("== New base =========================================================\n");
    printDMatrix(new_base);
    printf("== New origin =======================================================\n");
    printDMatrix(new_origin);
    printf("== Old base expr in new =============================================\n");
    printDMatrix(&old_base_in_new);
    printf("== Old origin expr in new ===========================================\n");
    printDMatrix(&old_origin_in_new);
    printf("== New to old transformation matrix =================================\n");
    printDMatrix(&new_to_old_transform);
    printf("== Old to new transformation matrix =================================\n");
    printDMatrix(&old_to_new_transform);
    printf("=====================================================================\n");
#endif

    double eq_lower_new_base_trnsl_to_old[(input_size + 1) * max_layer_size];
    double eq_upper_new_base_trnsl_to_old[(input_size + 1) * max_layer_size];
    struct DInterval eq_interval_new_base_trnsl_to_old = {
        .lower_dmatrix =
            &(struct DMatrix){(double *)eq_lower_new_base_trnsl_to_old, input_size + 1, max_layer_size},
        .upper_dmatrix =
            &(struct DMatrix){(double *)eq_upper_new_base_trnsl_to_old, input_size + 1, max_layer_size}
    };
    memset(eq_lower_new_base_trnsl_to_old, 0.0, sizeof(double) * (input_size + 1) * max_layer_size);
    memset(eq_upper_new_base_trnsl_to_old, 0.0, sizeof(double) * (input_size + 1) * max_layer_size);

    double eq_lower_old_base_trnsl_to_new[(input_size + 1) * max_layer_size];
    double eq_upper_old_base_trnsl_to_new[(input_size + 1) * max_layer_size];
    struct DInterval eq_interval_old_base_trnsl_to_new = {
        .lower_dmatrix =
            &(struct DMatrix){(double *)eq_lower_old_base_trnsl_to_new, input_size + 1, max_layer_size},
        .upper_dmatrix =
            &(struct DMatrix){(double *)eq_upper_old_base_trnsl_to_new, input_size + 1, max_layer_size}
    };
    memset(eq_lower_old_base_trnsl_to_new, 0.0, sizeof(double) * (input_size + 1) * max_layer_size);
    memset(eq_upper_old_base_trnsl_to_new, 0.0, sizeof(double) * (input_size + 1) * max_layer_size);

    // Concrete interval values for upper and lower symbolic interval for new base
    struct EqIntervalVals concrete_vals_new = {
        .eq_lo = {0.0, 0.0},
        .eq_up = {0.0, 0.0}
    };
    struct EqIntervalVals concrete_vals_old_trnsl_new = {
        .eq_lo = {0.0, 0.0},
        .eq_up = {0.0, 0.0}
    };

    // Concrete interval values for upper and lower symbolic interval for old base
    struct EqIntervalVals concrete_vals_old = {
        .eq_lo = {0.0, 0.0},
        .eq_up = {0.0, 0.0}
    };
    struct EqIntervalVals concrete_vals_new_trnsl_old = {
        .eq_lo = {0.0, 0.0},
        .eq_up = {0.0, 0.0}
    };

    // Ensure this array is zeroed before we start
    memset(activations_old, 0, sizeof(int) * max_layer_size * (num_layers - 1));
    memset(activations_new, 0, sizeof(int) * max_layer_size * (num_layers - 1));

    for (int layer = 0; layer < num_layers; layer++) {
#ifdef DEBUG
        printf("== Before Affine transformation ======================\n");
        printf("== Equations old =====================================\n");
        printDMatrix(equation_interval_old_base.lower_dmatrix);
        printDMatrix(equation_interval_old_base.upper_dmatrix);
        printf("======================================================\n");
        printf("== Equations new =====================================\n");
        printDMatrix(equation_interval_new_base.lower_dmatrix);
        printDMatrix(equation_interval_new_base.upper_dmatrix);
        printf("======================================================\n");
#endif
        // Affine transformation with new base
        linear_symbolic_step(
                input_size,
                max_layer_size,
                &equation_interval_new_base,
                &(nnet->weights[layer]),
                &(nnet->bias[layer]),
                &new_equation_interval_new_base);

        // Affine transformation with old base
        linear_symbolic_step(
                input_size,
                max_layer_size,
                &equation_interval_old_base,
                &(nnet->weights[layer]),
                &(nnet->bias[layer]),
                &new_equation_interval_old_base);
#ifdef DEBUG
        printf("== After Affine transformation =======================\n");
        printf("== Equations old =====================================\n");
        printDMatrix(new_equation_interval_old_base.lower_dmatrix);
        printDMatrix(new_equation_interval_old_base.upper_dmatrix);
        printf("======================================================\n");
        printf("== Equations new =====================================\n");
        printDMatrix(new_equation_interval_new_base.lower_dmatrix);
        printDMatrix(new_equation_interval_new_base.upper_dmatrix);
        printf("======================================================\n");
#endif

        for (int i = 0; i < nnet->layerSizes[layer + 1]; i++) {
#ifdef DEBUG
            printf("layer = %d, neuron = %d\n", layer, i);
#endif

            translate_all_equations(
                    input_size,
                    i,
                    &new_to_old_transform,
                    &old_to_new_transform,
                    &new_equation_interval_new_base,
                    &new_equation_interval_old_base,
                    &eq_interval_new_base_trnsl_to_old,
                    &eq_interval_old_base_trnsl_to_new);

            compute_all_concrete_intervals(
                    input_size,
                    i,
                    applied_outward_round,

                    new_input,
                    old_input,

                    &new_equation_interval_new_base,
                    &concrete_vals_new,

                    &eq_interval_old_base_trnsl_to_new,
                    &concrete_vals_old_trnsl_new,

                    &new_equation_interval_old_base,
                    &concrete_vals_old,

                    &eq_interval_new_base_trnsl_to_old,
                    &concrete_vals_new_trnsl_old);

#ifdef DEBUG
            if (!(concrete_vals_new.eq_lo.lo <= concrete_vals_new.eq_up.up) ||
                    !(concrete_vals_old_trnsl_new.eq_lo.lo <= concrete_vals_old_trnsl_new.eq_up.up) ||
                    !(concrete_vals_old.eq_lo.lo <= concrete_vals_old.eq_up.up) ||
                    !(concrete_vals_new_trnsl_old.eq_lo.lo <= concrete_vals_new_trnsl_old.eq_up.up)) {
                printf("== PRINT BEFORE CRASH ======================================\n");
                printf("Before ReLU: l=%d, n=%d\n", layer, i);
                printf("===== Old ==================================================\n");
                print_current_neuron_equation(&new_equation_interval_old_base, i, input_size);
                printf("===== New ==================================================\n");
                print_current_neuron_equation(&new_equation_interval_new_base, i, input_size);
                printf("===== New -> Old ===========================================\n");
                print_current_neuron_equation(&eq_interval_new_base_trnsl_to_old, i, input_size);
                printf("===== Old -> New ===========================================\n");
                print_current_neuron_equation(&eq_interval_old_base_trnsl_to_new, i, input_size);
                printf("============================================================\n");
                printf("== Concrete vals new =======================================\n");
                print_eq_interval_vals(&concrete_vals_new);
                printf("== Concrete vals old -> new ================================\n");
                print_eq_interval_vals(&concrete_vals_old_trnsl_new);
                printf("== Concrete vals old =======================================\n");
                print_eq_interval_vals(&concrete_vals_old);
                printf("== Concrete vals new -> old ================================\n");
                print_eq_interval_vals(&concrete_vals_new_trnsl_old);
                printf("============================================================\n");
                assert(concrete_vals_new.eq_lo.lo <= concrete_vals_new.eq_up.up && "Before ReLU");
                assert(concrete_vals_old_trnsl_new.eq_lo.lo <= concrete_vals_old_trnsl_new.eq_up.up && "Before ReLU");
                assert(concrete_vals_old.eq_lo.lo <= concrete_vals_old.eq_up.up && "Before ReLU");
                assert(concrete_vals_new_trnsl_old.eq_lo.lo <= concrete_vals_new_trnsl_old.eq_up.up && "Before ReLU");
            }
#endif

            // Compare new and old->new
            compare_equations(
                    i, // current neuron
                    input_size,
                    &new_equation_interval_new_base,
                    &concrete_vals_new,
                    &eq_interval_old_base_trnsl_to_new,
                    &concrete_vals_old_trnsl_new);

            // Compare old and new->old
            compare_equations(
                    i, // current neuron
                    input_size,
                    &new_equation_interval_old_base,
                    &concrete_vals_old,
                    &eq_interval_new_base_trnsl_to_old,
                    &concrete_vals_new_trnsl_old);

            if (set_dir) {
                for (int k = 0; k < (num_layers - 1); k++) {
                    if (bad_neurons[k] != NULL) {
                        if ((bad_neurons[k]->l == layer) && (bad_neurons[k]->n == i)) {
                            for (int h = 0; h < (input_size + 1); h++) {
                                bad_neurons[k]->equation->lower_dmatrix->data[h] =
                                    new_equation_interval_old_base.lower_dmatrix->data[(input_size + 1) * i + h];
                                bad_neurons[k]->equation->upper_dmatrix->data[h] =
                                    new_equation_interval_old_base.upper_dmatrix->data[(input_size + 1) * i + h];
                            }
                        }
                    }
                }
            }

            if (layer < (num_layers - 1)) { // Perform ReLU

                // We are re-computing the bounds for the equations inside these functions
                compute_activations(
                        &new_equation_interval_old_base,
                        old_input,
                        input_size,
                        layer,
                        i,
                        max_layer_size,
                        applied_outward_round,
                        activations_old);
                compute_activations(
                        &new_equation_interval_new_base,
                        new_input,
                        input_size,
                        layer,
                        i,
                        max_layer_size,
                        applied_outward_round,
                        activations_new);

                // ACTIVATIONS HISTORY BEGIN
                if (activations_old[i + layer * max_layer_size] == 0 ||
                        activations_new[i + layer * max_layer_size] == 0) {
                    activations_history[i + layer * max_layer_size] = 0;
                }
                // ACTIVATIONS HISTORY END

                // Need to re-compute concrete intervals before ReLU approximation
                // since we may use a translated equation (from compare_equations) instead.
                // This new equation obviously has different bounds needed to compute the approximation.
                reset_eq_interval_vals(&concrete_vals_old);
                compute_concrete_intervals(
                        &new_equation_interval_old_base,
                        old_input,
                        input_size,
                        i,
                        applied_outward_round,
                        &concrete_vals_old);
                reset_eq_interval_vals(&concrete_vals_new);
                compute_concrete_intervals(
                        &new_equation_interval_new_base,
                        new_input,
                        input_size,
                        i,
                        applied_outward_round,
                        &concrete_vals_new);

                // BEST INTERVALS BEGIN

                if (best_intervals[i + layer * max_layer_size]->lo < concrete_vals_new.eq_lo.lo) {
                    best_intervals[i + layer * max_layer_size]->lo = concrete_vals_new.eq_lo.lo;
                }
                if (best_intervals[i + layer * max_layer_size]->up > concrete_vals_new.eq_up.up) {
                    best_intervals[i + layer * max_layer_size]->up = concrete_vals_new.eq_up.up;
                }
                assert(
                    best_intervals[i + layer * max_layer_size]->lo <= best_intervals[i + layer * max_layer_size]->up);

                // BEST INTERVALS END

                // Should this part use different bounds?
                if (!set_dir) {
                    neuron_inputs[max_layer_size * layer + i].lo = concrete_vals_old.eq_lo.lo;
                    neuron_inputs[max_layer_size * layer + i].up = concrete_vals_old.eq_up.up;
                    neuron_inputs_in_new[max_layer_size * layer + i].lo = concrete_vals_new.eq_lo.lo;
                    neuron_inputs_in_new[max_layer_size * layer + i].up = concrete_vals_new.eq_up.up;
                }

                compute_all_relu_approximations(
                        input_size,
                        i,
                        // ACTIVATIONS HISTORY BEGIN
                        max_layer_size,
                        layer,
                        activations_history,
                        // ACTIVATIONS HISTORY END
                        // BEST INTERVALS BEGIN
                        best_intervals,
                        // BEST INTERVALS END
                        new_input,
                        old_input,
                        &new_equation_interval_new_base,
                        &concrete_vals_new,
                        &new_equation_interval_old_base,
                        &concrete_vals_old);

#ifdef DEBUG
                reset_eq_interval_vals(&concrete_vals_old);
                compute_concrete_intervals(
                        &new_equation_interval_old_base,
                        old_input,
                        input_size,
                        i,
                        applied_outward_round,
                        &concrete_vals_old);
                reset_eq_interval_vals(&concrete_vals_new);
                compute_concrete_intervals(
                        &new_equation_interval_new_base,
                        new_input,
                        input_size,
                        i,
                        applied_outward_round,
                        &concrete_vals_new);
                if (!(concrete_vals_new.eq_lo.lo <= concrete_vals_new.eq_up.up) ||
                        !(concrete_vals_old.eq_lo.lo <= concrete_vals_old.eq_up.up)) {
                    printf("== PRINT BEFORE CRASH ======================================\n");
                    printf("After ReLU: l=%d, n=%d\n", layer, i);
                    printf("===== New ==================================================\n");
                    print_current_neuron_equation(&new_equation_interval_new_base, i, input_size);
                    printf("===== Old ==================================================\n");
                    print_current_neuron_equation(&new_equation_interval_old_base, i, input_size);
                    printf("============================================================\n");
                    printf("== Concrete vals new =======================================\n");
                    print_eq_interval_vals(&concrete_vals_new);
                    printf("== Concrete vals old =======================================\n");
                    print_eq_interval_vals(&concrete_vals_old);
                    printf("============================================================\n");
                    assert(concrete_vals_new.eq_lo.lo <= concrete_vals_new.eq_up.up && "After ReLU");
                    assert(concrete_vals_old.eq_lo.lo <= concrete_vals_old.eq_up.up && "After ReLU");
                }
#endif

                translate_all_equations(
                        input_size,
                        i,
                        &new_to_old_transform,
                        &old_to_new_transform,
                        &new_equation_interval_new_base,
                        &new_equation_interval_old_base,
                        &eq_interval_new_base_trnsl_to_old,
                        &eq_interval_old_base_trnsl_to_new);

                compute_all_concrete_intervals(
                        input_size,
                        i,
                        applied_outward_round,

                        new_input,
                        old_input,

                        &new_equation_interval_new_base,
                        &concrete_vals_new,

                        &eq_interval_old_base_trnsl_to_new,
                        &concrete_vals_old_trnsl_new,

                        &new_equation_interval_old_base,
                        &concrete_vals_old,

                        &eq_interval_new_base_trnsl_to_old,
                        &concrete_vals_new_trnsl_old);

#ifdef DEBUG
                if (!(concrete_vals_new.eq_lo.lo <= concrete_vals_new.eq_up.up) ||
                        !(concrete_vals_old_trnsl_new.eq_lo.lo <= concrete_vals_old_trnsl_new.eq_up.up) ||
                        !(concrete_vals_old.eq_lo.lo <= concrete_vals_old.eq_up.up) ||
                        !(concrete_vals_new_trnsl_old.eq_lo.lo <= concrete_vals_new_trnsl_old.eq_up.up)) {
                    printf("== PRINT BEFORE CRASH ======================================\n");
                    printf("After Translation: l=%d, n=%d\n", layer, i);
                    printf("===== Old ==================================================\n");
                    print_current_neuron_equation(&new_equation_interval_old_base, i, input_size);
                    printf("===== New ==================================================\n");
                    print_current_neuron_equation(&new_equation_interval_new_base, i, input_size);
                    printf("===== New -> Old ===========================================\n");
                    print_current_neuron_equation(&eq_interval_new_base_trnsl_to_old, i, input_size);
                    printf("===== Old -> New ===========================================\n");
                    print_current_neuron_equation(&eq_interval_old_base_trnsl_to_new, i, input_size);
                    printf("============================================================\n");
                    printf("== Concrete vals new =======================================\n");
                    print_eq_interval_vals(&concrete_vals_new);
                    printf("== Concrete vals old -> new ================================\n");
                    print_eq_interval_vals(&concrete_vals_old_trnsl_new);
                    printf("== Concrete vals old =======================================\n");
                    print_eq_interval_vals(&concrete_vals_old);
                    printf("== Concrete vals new -> old ================================\n");
                    print_eq_interval_vals(&concrete_vals_new_trnsl_old);
                    printf("============================================================\n");
                    assert(concrete_vals_new.eq_lo.lo <= concrete_vals_new.eq_up.up && "After translation");
                    assert(concrete_vals_old_trnsl_new.eq_lo.lo <= concrete_vals_old_trnsl_new.eq_up.up && "After translation");
                    assert(concrete_vals_old.eq_lo.lo <= concrete_vals_old.eq_up.up && "After translation");
                    assert(concrete_vals_new_trnsl_old.eq_lo.lo <= concrete_vals_new_trnsl_old.eq_up.up && "After translation");
                }
#endif

                // Compare new and old->new
                compare_equations(
                        i, // current neuron
                        input_size,
                        &new_equation_interval_new_base,
                        &concrete_vals_new,
                        &eq_interval_old_base_trnsl_to_new,
                        &concrete_vals_old_trnsl_new);

                // Compare old and new->old
                compare_equations(
                        i, // current neuron
                        input_size,
                        &new_equation_interval_old_base,
                        &concrete_vals_old,
                        &eq_interval_new_base_trnsl_to_old,
                        &concrete_vals_new_trnsl_old);

            } else { // Last layer, no ReLU!
                // Perform meet of concrete intervals for old and new base
                struct EqIntervalVals meet_old_new = {
                    .eq_lo = {0.0, 0.0},
                    .eq_up = {0.0, 0.0}
                };
                meet_eq_interval_vals(
                        &concrete_vals_old,
                        &concrete_vals_new,
                        &meet_old_new);

                struct EqIntervalVals meet_trnsl_old_new = {
                    .eq_lo = {0.0, 0.0},
                    .eq_up = {0.0, 0.0}
                };
                meet_eq_interval_vals(
                        &concrete_vals_new_trnsl_old,
                        &concrete_vals_old_trnsl_new,
                        &meet_trnsl_old_new);

                struct EqIntervalVals power_meet = {
                    .eq_lo = {0.0, 0.0},
                    .eq_up = {0.0, 0.0}
                };
                meet_eq_interval_vals(
                        &meet_old_new,
                        &meet_trnsl_old_new,
                        &power_meet);

#ifdef DEBUG
                printf("== meet old new ======================================\n");
                print_eq_interval_vals(&meet_old_new);
                printf("======================================================\n");
                printf("== meet trnsl old new ================================\n");
                print_eq_interval_vals(&meet_trnsl_old_new);
                printf("======================================================\n");
                printf("== power meet ========================================\n");
                print_eq_interval_vals(&power_meet);
                printf("======================================================\n");
#endif
#ifdef DEBUG
                printf("== Concrete vals old =================================\n");
                print_eq_interval_vals(&concrete_vals_old);
                printf("======================================================\n");
                printf("== Concrete vals new =================================\n");
                print_eq_interval_vals(&concrete_vals_new);
                printf("======================================================\n");
                printf("== Meet old new ======================================\n");
                print_eq_interval_vals(&meet_old_new);
                printf("======================================================\n");
#endif
                // How should we strengthen the output bounds with our current analysis?
                // Strengthen the older bounds with the new ones.
                if (!set_dir) {
                    strengthen_output_bounds(
                            // &concrete_vals_new,
                            &power_meet,
                            i,
                            output);
                }
            }
        }
#ifdef DEBUG
        printf("Equations after layer %d, old base\n", layer);
        printDMatrix(new_equation_interval_old_base.lower_dmatrix);
        printDMatrix(new_equation_interval_old_base.upper_dmatrix);
        printf("Equations after layer %d, new base\n", layer);
        printDMatrix(new_equation_interval_new_base.lower_dmatrix);
        printDMatrix(new_equation_interval_new_base.upper_dmatrix);
#endif

        // New base
        memcpy(
            equation_interval_new_base.upper_dmatrix->data,
            new_equation_interval_new_base.upper_dmatrix->data,
            sizeof(double) * (input_size + 1) * max_layer_size);
        memcpy(
            equation_interval_new_base.lower_dmatrix->data,
            new_equation_interval_new_base.lower_dmatrix->data,
            sizeof(double) * (input_size + 1) * max_layer_size);
        equation_interval_new_base.lower_dmatrix->row =
            equation_interval_new_base.upper_dmatrix->row = new_equation_interval_new_base.lower_dmatrix->row;
        equation_interval_new_base.lower_dmatrix->col =
            equation_interval_new_base.upper_dmatrix->col = new_equation_interval_new_base.lower_dmatrix->col;

        // Old base
        memcpy(
            equation_interval_old_base.upper_dmatrix->data,
            new_equation_interval_old_base.upper_dmatrix->data,
            sizeof(double) * (input_size + 1) * max_layer_size);
        memcpy(
            equation_interval_old_base.lower_dmatrix->data,
            new_equation_interval_old_base.lower_dmatrix->data,
            sizeof(double) * (input_size + 1) * max_layer_size);
        equation_interval_old_base.lower_dmatrix->row =
            equation_interval_old_base.upper_dmatrix->row = new_equation_interval_old_base.lower_dmatrix->row;
        equation_interval_old_base.lower_dmatrix->col =
            equation_interval_old_base.upper_dmatrix->col = new_equation_interval_old_base.lower_dmatrix->col;
    }
}


/*
 * Backward propagation to calculate the gradient ranges of inputs.
 * Takes in network and gradient masks.
 * Outputs input gradient ranges.
 */
void backward_prop(struct NNet *nnet,\
                struct DInterval *grad,\
                int R[][nnet->maxLayerSize])
{

    int i, j, layer;
    int numLayers    = nnet->numLayers;
    int inputSize    = nnet->inputSize;
    int outputSize   = nnet->outputSize;
    int maxLayerSize   = nnet->maxLayerSize;

    double grad_upper[maxLayerSize];
    double grad_lower[maxLayerSize];
    double grad1_upper[maxLayerSize];
    double grad1_lower[maxLayerSize];

    memcpy(grad_upper, nnet->dmatrix[numLayers-1][0][nnet->target],\
                    sizeof(double)*maxLayerSize);
    memcpy(grad_lower, nnet->dmatrix[numLayers-1][0][nnet->target],\
                    sizeof(double)*maxLayerSize);

    for (layer=numLayers-2;layer>-1;layer--){
        double **weights = nnet->dmatrix[layer][0];
        memset(grad1_upper, 0, sizeof(double)*maxLayerSize);
        memset(grad1_lower, 0, sizeof(double)*maxLayerSize);

        for (j=0;j<maxLayerSize;j++) {

            if(R[layer][j] == 0){
                grad_upper[j] = grad_lower[j] = 0;
            }
            else if (R[layer][j] == 1) {
                grad_upper[j] = (grad_upper[j]>0)?grad_upper[j]:0;
                grad_lower[j] = (grad_lower[j]<0)?grad_lower[j]:0;
            }

            if (layer != 0) {

                for (i=0;i<maxLayerSize;i++) {

                    if (weights[j][i] >= 0) {
                        grad1_upper[i] += weights[j][i]*grad_upper[j];
                        grad1_lower[i] += weights[j][i]*grad_lower[j];
                    }
                    else {
                        grad1_upper[i] += weights[j][i]*grad_lower[j];
                        grad1_lower[i] += weights[j][i]*grad_upper[j];
                    }

                }

            }
            else {

                for (i=0;i<inputSize;i++) {

                    if (weights[j][i] >= 0) {
                        grad1_upper[i] += weights[j][i]*grad_upper[j];
                        grad1_lower[i] += weights[j][i]*grad_lower[j];
                    }
                    else {
                        grad1_upper[i] += weights[j][i]*grad_lower[j];
                        grad1_lower[i] += weights[j][i]*grad_upper[j];
                    }

                }

            }
        }

        if (layer != 0) {
            memcpy(grad_upper,grad1_upper,sizeof(double)*maxLayerSize);
            memcpy(grad_lower,grad1_lower,sizeof(double)*maxLayerSize);
        }
        else {
            memcpy(grad_upper,grad1_upper,sizeof(double)*maxLayerSize);
            memcpy(grad_lower,grad1_lower,sizeof(double)*maxLayerSize);
            memcpy(grad->lower_dmatrix->data, grad1_lower,\
                                        sizeof(double)*inputSize);
            memcpy(grad->upper_dmatrix->data, grad1_upper,\
                                        sizeof(double)*inputSize);
        }

    }

}
