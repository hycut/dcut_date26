#include <pthread.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <signal.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include <limits.h>

#include "cstrlist.h"
#include "dinterval.h"
#include "dmatrix.h"
#include "lapacke.h"

#include "nnet.h"
#include "symbolic_analysis.h"


#ifndef SPLIT_H
#define SPLIT_H

// Prints which splits are started
// #define SPLIT_PRINT

// Writes infeasible Gurobi models to disk
// #define DBG_GUROBI

// Prints "common" things to check in check_on_relu
// #define CHK_COMMON_DBG

// Prints "bad neurons' information in check_on_relu
// #define DBG_CHK_BAD_NEURONS

// Prints input used to check for adversarial in check_on_relu
// #define DBG_CHK_ADV_TEST

// Debug prints for encode_nn_and_solve
// Should only be used in single thread mode
// #define DBG_ENCODE_NN

// Writes models from encode_nn_and_solve to file
// Creates a lot of files, use with caution
// #define DBG_ENCODE_NN_WRITE_FILES

/* Print detailed progress */
extern int NEED_PRINT;

/* No bisection mode */
extern int NEED_FOR_ONE_RUN;

/* set 1 if a concrete adversarial example is
found */
extern int adv_found;

/* Mode for faster search concrete
adversarial examples */
extern int CHECK_ADV_MODE;
extern int PARTIAL_MODE;

/* Bisection tree info */
extern double max_depth;
extern int leaf_num;
extern int uncertain_leaf_num;
extern double avg_depth;
extern double total_avg_depth;

extern double avg_linear_neurons_robust;
extern int split_num;
extern int active_splits;
extern int inactive_splits;
extern int hybrid_splits;
extern int killed_splits;
extern double avg_linear_neurons_split;
extern double avg_lin_split_active;
extern double avg_lin_split_inactive;
extern double avg_lin_split_hybrid;

extern int csv_print;

extern int total_gurobi_count;
extern int input_gurobi_count;
extern int gurobi_count;
extern double total_gurobi_time;

extern int max_dims_used_robust;
extern int min_dims_used_robust;

extern int max_allowed_depth;
extern int uncertain_analysis;

extern double avg_target_output_width;

/* Progress record out of 1024 */
extern int progress;

/* Time record */
extern struct timeval start,finish, last_finish;

/* If the input range is less than ADV_THRESHOLD,
then it will check for concrete adversarial example*/
#define ADV_THRESHOLD  0.00001

/* Thread locker */
extern pthread_mutex_t lock;

/* Active threads number */
extern int count;


/*
 * Define the argument structure of main function
 * direct_run_check used for parallelization.
 */
struct direct_run_check_args
{
    struct NNet *nnet;
    struct DInterval *input;
    struct DInterval *output;
    struct DInterval *grad;
    int depth;
    int *feature_range;
    int feature_range_length;
    int split_feature;
    GRBmodel *model;
    GRBenv *env;
    int code;
    struct CStrList* pcstrlist;
    struct DMatrixList *bases;
    struct DMatrixList *origins;
    struct DIntervalList *inputs;
    //int avg_depth;
};

struct check_args
{
    struct NNet *nnet;
    struct DMatrix *current_base_in_old;
    struct DMatrix *current_origin_in_old;
    struct DInterval *input_in_current;
    struct DInterval *output;
    struct CStrList* pcstrlist;
    int center_type;
    int depth;
};


/*
 * Check the concrete adversarial examples of
 * the middle point of given input ranges.
 */
void check_adv(struct NNet *nnet, struct DInterval *input);

int is_concrete_adv(struct NNet *nnet, struct DMatrix *adv);


/*
 * Check the predefined properties given
 * approximated output ranges.
 */
int check_functions(struct NNet *nnet, struct DInterval *output);


/*
 * Check the predefined properties given
 * concrete output.
 */
int check_functions1(struct NNet *nnet, struct DMatrix *output);


/*
 * Function for parallelization.
 */
void *direct_run_check_thread(void *args);

/*
 * Main function to decide whether need to further split input ranges
 * or terminate according to given approximated output ranges.
 */
int direct_run_check(struct NNet *nnet, struct DInterval *input,
                     struct DInterval *output, struct DInterval *grad,
                     int depth, int *feature_range, int feature_range_length,
                     int split_feature, GRBmodel* model, GRBenv *env, int code,\
                     struct CStrList* pcstrlist,
                     struct DMatrixList *bases,
                     struct DMatrixList *origins,
                     struct DIntervalList *inputs);

/*
 * Function for parallelization.
 */
void *check_thread(void *args);

void check(struct NNet *nnet, struct DMatrix *current_base_in_old,
          struct DMatrix *current_origin_in_old, struct DInterval *input_in_current, \
          struct DInterval *output, struct CStrList* pcstrlist, int center_type, int depth);


/*
 * Function for splitting and creating new threads
 * for newly split input ranges.
 */
int split_interval(struct NNet *nnet, struct DInterval *input,
                   struct DInterval *output, struct DInterval *grad,
                   int depth, int *feature_range, int feature_range_length,
                   int split_feature, GRBmodel* model, GRBenv *env, int code, \
                   struct CStrList* pcstrlist,
                   struct DMatrixList *bases,
                   struct DMatrixList *origins,
                   struct DIntervalList *inputs);

lapack_int construct_new_base(int const input_size, struct DMatrix *new_base, struct DMatrix *new_base_inv);

int construct_input_in_old(
        struct DInterval *input_in_old,
        struct DInterval *input_in_current,
        struct DMatrix *current_base_in_old,
        struct DMatrix *current_origin_in_old,
        struct CStrList *pcstrlist,
        int const inputSize);

void construct_common_model(GRBmodel **model, GRBenv **env, char *modelname, int const num_vars);
void quit_and_print_gurobi_error(GRBenv *env);

int split(struct NNet *nnet, struct DMatrix *new_base_in_old, struct DMatrix *new_direction_in_old, \
        struct DMatrix *new_origin_in_old, \
        struct DInterval *output, struct CStrList* pcstrlist, int center_type, int depth, double mid);


int get_center(struct CStrList* pcstrlist, struct DMatrix* direction, \
        struct DMatrix *center, int center_type);

int quit_get_center_combined(GRBenv *env);

int get_center_combined(
    struct CStrList *pcstrlist,
    struct DMatrix *direction_in_old,
    struct DMatrix *new_center_in_old);

int get_optimal_val(GRBmodel* model, GRBenv *env, double* obj, int size, int max_min, double *objval);

int get_input_bounds_dim(
        GRBmodel *model,
        GRBenv *env,
        int const dim,
        int const input_size,
        int *split_ok,
        struct DInterval *input);

int encode_nn_and_solve(
        struct NNet *nnet,
        struct CStrList *pcstrlist,
        struct IntervalVals **neuron_intervals,

        unsigned long const parent_tid,
        int const depth,
        enum NeuronState const current_split_state,

        struct DInterval *output);

struct check_on_relu_args
{
    struct NNet *nnet;
    struct DMatrix *current_base_in_old;
    struct DMatrix *current_origin_in_old;
    struct DInterval *input_in_current;
    struct DInterval *output;
    struct CStrList* pcstrlist;
    int num_dims_allowed;
    int *dims_used;
    unsigned long parent_tid;
    int depth;
    int prev_split_l;
    int prev_split_n;
    struct NeuronInfoList *prev_neurons;
    enum NeuronState *activation_history;
    struct IntervalVals **best_intervals;
};

void *check_on_relu_thread(void *args);


struct dimension_score
{
    double score;
    int index;
};

int construct_approx_equation(
        struct DMatrix *equation,
        struct DInterval *parent_input,
        int const input_size,

        int const num_dims_allowed,
        int *dims_used_local,
        int *dims_used,

        double *active_offset,
        double *inactive_offset,
        struct DMatrix *approx_equation
        );

int construct_base_from_approx_equation(
        struct DMatrix *approx_equation,
        int *dims_used,
        int const input_size,
        int const num_dims_allowed,

        struct DMatrix *base
        );

int split_relu_3way(
        struct NNet *nnet,
        struct DInterval *parent_input,
        struct DInterval *output,
        struct CStrList* pcstrlist,

        int const num_dims_allowed,
        int *dims_used,

        int depth,
        struct NeuronInfo *neuron,
        int const split_l,
        int const split_n,

        struct NeuronInfoList *prev_neurons,
        enum NeuronState *activation_history,

        struct IntervalVals **best_intervals
        );

void check_on_relu(
        struct NNet *nnet,
        struct DMatrix *current_base_in_old,
        struct DMatrix *current_origin_in_old,
        struct DInterval *input_in_current,
        struct DInterval *output,
        struct CStrList* pcstrlist,

        int const num_dims_allowed,
        int *dims_used,

        unsigned long const parent_tid,
        int const depth,
        int const prev_split_l,
        int const prev_split_n,

        struct NeuronInfoList *prev_neurons,
        enum NeuronState *activation_history,

        struct IntervalVals **best_intervals
        );
#endif
