#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "gurobi_c.h"

#include "cstrlist.h"
#include "dinterval.h"
#include "dmatrix.h"


#ifndef NNET_H
#define NNET_H

/* outward rounding */

/* which property to test */
extern int PROPERTY;

/* log file */
extern char *LOG_FILE;
extern FILE *fp;

typedef int bool;
enum { false, true };


/*
 * Network instance modified from Reluplex
 * malloc all the memory needed for network
 */
struct NNet
{
    int symmetric;
    int numLayers;
    int inputSize;
    int outputSize;
    int maxLayerSize;
    int *layerSizes;

    double *mins;
    double *maxes;
    double *means;
    double *ranges;
    double ****dmatrix; // don't use!


    struct DMatrix* weights;
    struct DMatrix* bias;

    int target;
    int *feature_range;
    int feature_range_length;
    int split_feature;
};

/* load the network from file */
struct NNet *load_network(const char *filename, int target);

/* free all the memory for the network */
void destroy_network(struct NNet *network);


/* load the input range of the property */
void load_inputs(int PROPERTY, int inputSize, struct DInterval *input_interval, char const *mnist_bounds);


/* denormalize input */
void denormalize_input(struct NNet *nnet, struct DMatrix *input);

/* denormalize input range */
void denormalize_input_interval(struct NNet *nnet, struct DInterval *input);


/* normalize input */
void normalize_input(struct NNet *nnet, struct DMatrix *input);

/* normalize input range */
void normalize_input_interval(struct NNet *nnet, struct DInterval *input);


/*
 * Uses for loop to calculate the output
 * 0.00002607 sec for one run with one core
*/
int evaluate(struct NNet *network, struct DMatrix *input, struct DMatrix *output);



/*
 * Uses sgemm to calculate the output
 * 0.00001359 sec for one run with one core
*/
int forward_prop(struct NNet *network, struct DMatrix *input, struct DMatrix *output);


/*
 * Uses sgemm to calculate the output interval
*/
int forward_prop_interval(struct NNet *network, \
                        struct DInterval *input, \
                        struct DInterval *output);



// new propagation method which can make the verification much faster!
int forward_prop_interval_equation_linear(struct NNet *network, \
                                struct DInterval *input, struct DInterval *output,\
                                struct DInterval *grad, GRBmodel* model, GRBenv *env);


void symbolic_forward(struct NNet *nnet, struct DMatrix *base, struct DMatrix *origin, \
    struct DInterval *input, struct DInterval *output, int* activations);

struct IntervalVals
{
    double lo, up;
};

struct EqIntervalVals
{
    struct IntervalVals eq_lo;
    struct IntervalVals eq_up;
};

void reset_eq_interval_vals(struct EqIntervalVals *eq_int_vals);
void print_eq_interval_vals(struct EqIntervalVals *eq_int_vals);
void meet_eq_interval_vals(
        struct EqIntervalVals *a,
        struct EqIntervalVals *b,
        struct EqIntervalVals *res);

void compute_concrete_intervals(
        struct DInterval *new_equation_interval,
        struct DInterval *input,
        int const input_size,
        int const current_neuron,
        double const outward_round,
        struct EqIntervalVals *eq_int_vals);

void compute_relu_approximations(
        struct EqIntervalVals const *eq_int_vals,
        int const input_size,
        int const current_neuron,

        int const max_layer_size,
        int const current_layer,
        int *activations_history,

        struct IntervalVals **best_intervals,

        struct DInterval *input,
        struct DInterval *new_equation_interval);

void compute_activations(
        struct DInterval *equation_interval,
        struct DInterval *input,
        int const input_size,
        int const current_layer,
        int const current_neuron,
        int const max_layer_size,
        double const outward_round,
        int *activations);

void strengthen_output_bounds(
        struct EqIntervalVals const *eq_int_vals,
        int const current_neuron,
        struct DInterval *output);

/*
 * Columns B_c/o (new base in old) gives the equation of each dimension in the new base
 * expressed in the old base.
 * Transposing B_c/o makes the columns represent each dimension of the old base expressed
 * in the new base.
 *
 * P_o = B_c/o * P_c + O_c/oo
 * => (since B_c/o is an ON-base)
 * P_c = transp(B_c/o) * P_o - transp(B_c/o) * O_c/o
 * */
void get_old_in_new_expr(
        struct DMatrix *new_base,
        struct DMatrix *new_origin,
        struct DMatrix *old_base_in_new,
        struct DMatrix *old_origin_in_new);

void translate_equation(
        int const input_size,
        int const current_neuron,
        struct DMatrix *transform,
        struct DInterval *eq_interval,
        struct DInterval *eq_interval_trnsl);

void compare_equations(
        int const current_neuron,
        int const input_size,
        struct DInterval *eq_interval,
        struct EqIntervalVals *concrete_vals,
        struct DInterval *eq_interval_trnsl,
        struct EqIntervalVals *concrete_vals_trnsl);

enum NeuronState
{
    DEFAULT,
    ACTIVE,
    INACTIVE,
    HYBRID,
};

struct NeuronInfo
{
    int l, n;
    enum NeuronState state;
    struct DInterval *equation;
};

struct NeuronInfoList
{
    struct NeuronInfo *ni;
    struct NeuronInfoList *next;
};

struct NeuronInfo *allocate_NeuronInfo(int const input_size);
void free_NeuronInfo(struct NeuronInfo *ni);
void print_NeuronInfo(struct NeuronInfo *ni);

void print_current_neuron_equation(struct DInterval *equation, int const current_neuron, int const input_size);

void symbolic_forward_simultaneous_analysis(
        struct NNet *nnet,
        struct DMatrix *new_base,
        struct DMatrix *new_origin,
        struct DInterval *new_input,
        struct DMatrix *old_base,
        struct DMatrix *old_origin,
        struct DInterval *old_input,
        struct DInterval *output,
        int *activations_old,
        int *activations_new,
        int *activations_history,

        struct IntervalVals *neuron_inputs,
        struct IntervalVals *neuron_inputs_in_new,

        struct IntervalVals **best_intervals,

        int const set_dir,
        struct NeuronInfo *bad_neurons[]
        // int const worst_neuron_layer,
        // int const worst_neuron,
        // double *direction_equation
        );

/*
 * The back prop to calculate the gradient
 * 0.000249 sec for one run with one core
*/
void backward_prop(struct NNet *nnet, struct DInterval *grad, int R[][nnet->maxLayerSize]);

double get_obj_gurobi(GRBmodel* model, GRBenv *env, double* obj, int size, int max_min);

double add_cost_functions_to_gurobi(GRBmodel* model, GRBenv *env,	\
                            struct NNet *nnet, int node_index, \
                            double* new_equation_inteval, int max_min);

#endif
