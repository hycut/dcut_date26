#ifndef _SYMBOLIC_ANALYSIS_H_
#define _SYMBOLIC_ANALYSIS_H_

#include "nnet.h"
#include "split.h"

#define NEED_OUTWARD_ROUND 0
#define OUTWARD_ROUND 0.00000005

void symbolic_forward_analysis(
        struct NNet *nnet,
        struct DMatrix *base,
        struct DMatrix *origin,
        struct DInterval *input,

        struct DInterval *input_old,

        struct DInterval *output,
        struct IntervalVals **neuron_intervals,
        struct CStrList *pcstrlist,

        struct NeuronInfoList *prev_neurons,
        enum NeuronState *activation_history,

        int const get_equations,
        struct NeuronInfo **bad_neurons);

void compute_concrete_interval_symbolic(
        int const input_size,
        int const current_neuron,
        double const applied_outward_round,

        struct DInterval *input,

        struct DInterval *equation_interval,
        struct EqIntervalVals *eq_int_vals);

#endif // _SYMBOLIC_ANALYSIS_H_
