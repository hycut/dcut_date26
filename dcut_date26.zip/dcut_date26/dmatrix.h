#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <cblas.h>

#include <assert.h>

#include "lapacke.h"

#ifndef DMATRIX_H
#define DMATRIX_H


/* Define the structure of DMatrix */
struct DMatrix
{
    double* data;
    int row, col;
};

struct DMatrixList{
    struct DMatrix matrix;
    struct DMatrixList* next;
};


/* add the constant to dmatrix */
void add_constant(struct DMatrix* A, double alpha);


/*dmatrix multiplication with factors */
void matmul_with_factor(struct DMatrix* A,\
                        struct DMatrix* B,\
                        struct DMatrix* C,\
                        double alpha,\
                        double beta);

/* dmatrix multiplication */
void matmul(struct DMatrix* A,\
            struct DMatrix* B,\
            struct DMatrix* C);


/* dmatrix multiplication with bias */
void matmul_with_bias(struct DMatrix* A,\
                      struct DMatrix* B,\
                      struct DMatrix* C);


/* dmatrix dot product */
double dot(struct DMatrix* x, struct DMatrix* y);


/* element-wise multiplication */
void multiply(struct DMatrix* A, struct DMatrix* B);


/* print dmatrix */
void printDMatrix(struct DMatrix* A);


/* print dmatrix to the file */
void fprintDMatrix(FILE *fp, struct DMatrix* A);


/* takes the relu of the dmatrix */
void relu(struct DMatrix* A);

/*
 * Computes the LU decomposition and returns the L and U matrices.
 *
 * A - The MxN matrix to be decomposed. This is not modified.
 * L - Resulting L matrix of size MxM is stored here.
 * U - Resulting U matrix of size MxN is stored here.
 *
 * Return: the status code from the dgetrf LAPACKE function call.
 * */
lapack_int DMatrix_LU_decomposition(struct DMatrix *A, struct DMatrix *L, struct DMatrix *U);

/*
 * Computes the inverse of matrix A and stores it in A_inv
 *
 * A - The MxM matrix to be inverted. This is not modified.
 * A_inv - Resulting inverted matrix.
 *
 * Return: the status code from the LAPACKE function call.
 * */
lapack_int DMatrix_inverse(struct DMatrix *A, struct DMatrix *A_inv);

/*
 * Computes the rank of a matrix. (Assumed usage is with the U matrix from LU decomposition.)
 *
 * A - Matrix of size MxN in row echelon form. This is not modified.
 *
 * Return: rank of matrix A.
 * */
int DMatrix_rank(struct DMatrix *A);

#endif
