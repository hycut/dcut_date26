#ifndef DINTERVAL_H
#define DINTERVAL_H

/* define the structure of interval */
struct DInterval
{
	struct DMatrix* lower_dmatrix;
	struct DMatrix* upper_dmatrix;
};

struct DIntervalList{
	struct DInterval dinterval;
	struct DIntervalList* next;
};

#endif

