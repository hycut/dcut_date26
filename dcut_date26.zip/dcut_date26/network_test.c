#include <stdio.h>
#include "nnet.h"
#include "split.h"

#include <assert.h>

void set_identity_base_and_origin(int const input_size, double *base, double *origin)
{
    for (int in = 0; in < input_size; in++) {
        base[in + in*input_size] = 1.0;
    }
}

void set_custom_base_and_origin(
        int const input_size,
        double *base,
        double *origin,
        double *custom_base,
        double *custom_origin)
{
    for (int i = 0; i < input_size; i++) {
        origin[i] = custom_origin[i];
    }

    for (int i = 0; i < input_size * input_size; i++) {
        base[i] = custom_base[i];
    }
}


int main( int argc, char *argv[])
{
    openblas_set_num_threads(1);
    //clock_t start, end;
    srand((unsigned)time(NULL));

    int num_dims_allowed = 0;
    char *FULL_NET_PATH = NULL;
    int target = 0;
    int norm_input = 1;
    char *mnist_bounds = NULL;
    for (int i = 1; i < argc; i++) {
        if (i == 1) {
            PROPERTY = atoi(argv[i]);
        }
        if (i == 2) {
            FULL_NET_PATH = argv[i];
        }
        if (i == 3) {
            target = atoi(argv[i]);
        }
        if (i == 4) {
            csv_print = atoi(argv[i]);
        }
        if (i == 5) {
            num_dims_allowed = atoi(argv[i]);
        }
        if (i == 6) {
            max_allowed_depth = atoi(argv[i]);
        }
        if (i == 7) {
            mnist_bounds = argv[i];
        }
        if (i == 8) {
            norm_input = atoi(argv[i]);
        }
    }

    // load network and normalize input.
    // All outputs get network - target (except for property==1, 114, 117, 118).
    struct NNet* nnet;
    nnet = load_network(FULL_NET_PATH, target);

    int total_relu_neurons = 0;
    for(int layer = 0; layer < nnet->numLayers - 1; layer++) {
        for(int node = 0; node < nnet->layerSizes[layer + 1]; node++) {
            total_relu_neurons++;
        }
    }

    int inputSize = nnet->inputSize;
    int outputSize = nnet->outputSize;

    if (num_dims_allowed <= 0) {
        num_dims_allowed = inputSize;
    }
    if (num_dims_allowed > inputSize) {
        printf("Bad value for num_dims_allowed (arg 5)\n");
        exit(1);
    }

    struct DInterval *input_interval = (struct DInterval*) malloc(sizeof(struct DInterval));
    load_inputs(PROPERTY, inputSize, input_interval, mnist_bounds);
    // If we do not call normalize then the input will exactly as we specified for property
    // We do not really see the point of using this function.
    // However, the ACAS Xu properties (at least) from ReluVal are scaled such that they
    // assume that the input is normalized.
    if (norm_input) { // Default is 1
        normalize_input_interval(nnet, input_interval);
    }

    if (csv_print == 0 && PROPERTY < 1000) {
        printf("Running property %d with network %s: \n", PROPERTY, FULL_NET_PATH);
        printDMatrix(input_interval->lower_dmatrix);
        printDMatrix(input_interval->upper_dmatrix);
    }

    double *data_upper_output = (double*) malloc(sizeof(double) * outputSize);
    double *data_lower_output = (double*) malloc(sizeof(double) * outputSize);
    struct DMatrix *matrix_upper_output = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    matrix_upper_output->data = data_upper_output;
    matrix_upper_output->row = outputSize;
    matrix_upper_output->col = 1;
    struct DMatrix *matrix_lower_output = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    matrix_lower_output->data = data_lower_output;
    matrix_lower_output->row = outputSize;
    matrix_lower_output->col = 1;
    struct DInterval *output_interval = (struct DInterval*) malloc(sizeof(struct DInterval));
    output_interval->upper_dmatrix = matrix_upper_output;
    output_interval->lower_dmatrix = matrix_lower_output;
    for(int i = 0; i < outputSize; i++){ // output initially unconstrained
        data_lower_output[i] = -1.0/0.0; //- infinity
        data_upper_output[i] = 1.0/0.0; // + infinity
    }

    double *data_current_base = (double*) malloc(sizeof(double) * inputSize * inputSize);
    struct DMatrix *current_base = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    current_base->data = data_current_base;
    current_base->row = inputSize;
    current_base->col = inputSize;
    memset(data_current_base, 0.0, sizeof(double) * inputSize * inputSize);

    double *data_current_origin = (double*) malloc(sizeof(double) * inputSize);
    struct DMatrix *current_origin = (struct DMatrix*) malloc(sizeof(struct DMatrix));
    current_origin->data = data_current_origin;
    current_origin->row = inputSize;
    current_origin->col = 1;
    memset(data_current_origin, 0.0, sizeof(double) * inputSize);

    set_identity_base_and_origin(inputSize, data_current_base, data_current_origin);

    struct CStrList* pcstrlist = NULL;
    struct CStrList lists[2 * inputSize];
    double identity[inputSize * inputSize];
    { // build constraints for initial bounds
        for(int i = 0; i < inputSize; i++) {
            for(int j = 0; j < inputSize; j++) {
                identity[i * inputSize + j] = (i == j ? 1.0 : 0.0);
            }
        }
        for(int i = 0; i < inputSize; i++) {
            if(input_interval->lower_dmatrix->data[i] < input_interval->upper_dmatrix->data[i]) {
                lists[2 * i].current =
                    (struct Cstr){inputSize, identity + i * inputSize, \
                    GRB_GREATER_EQUAL, input_interval->lower_dmatrix->data[i]};
                lists[2 * i].next = pcstrlist;
                pcstrlist = &lists[2 * i];

                lists[2 * i + 1].current =
                    (struct Cstr){inputSize, identity + i * inputSize, \
                    GRB_LESS_EQUAL, input_interval->upper_dmatrix->data[i]};
                lists[2 * i + 1].next = pcstrlist;
                pcstrlist = &lists[2 * i + 1];
            } else {
                lists[2 * i].current =
                    (struct Cstr){inputSize, identity + i * inputSize, \
                    GRB_EQUAL, input_interval->lower_dmatrix->data[i]};

                lists[2 * i].next = pcstrlist;
                pcstrlist= &lists[2 * i];
            }
        }
    }

    // Set up the end node for the linked list of previously chosen neurons.
    struct NeuronInfoList prev_neurons;
    struct NeuronInfo null_neuron = {
        .l = -1,
        .n = -1,
        .equation = NULL
    };
    prev_neurons.ni = &null_neuron;
    prev_neurons.next = NULL;

    // Set up the activation history vector
    // This only has entries corresponding to neurons in the hidden layers.
    enum NeuronState *activation_history =
        (enum NeuronState*) malloc(sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));
    memset(activation_history, DEFAULT, sizeof(enum NeuronState) * (nnet->maxLayerSize * (nnet->numLayers - 1)));

    // Also includes input and output layer
    struct IntervalVals **best_intervals =
        (struct IntervalVals**) malloc(sizeof(struct IntervalVals*) * (nnet->maxLayerSize * (nnet->numLayers + 1)));
    for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
        best_intervals[i] = (struct IntervalVals*) malloc(sizeof(struct IntervalVals));
        best_intervals[i]->lo = -1.0/0.0;
        best_intervals[i]->up = 1.0/0.0;
    }
    // Initialize intervals of input neuron to the input intervals
    for (int i = 0; i < inputSize; i++) {
        best_intervals[i]->lo = input_interval->lower_dmatrix->data[i];
        best_intervals[i]->up = input_interval->upper_dmatrix->data[i];
    }

    int *dims_used = (int*) malloc(sizeof(int) * inputSize);
    memset(dims_used, 0, sizeof(int) * inputSize);

    gettimeofday(&start, NULL);
    check_on_relu(
            nnet,
            current_base,
            current_origin,
            input_interval,
            output_interval,
            pcstrlist,

            num_dims_allowed,
            dims_used,

            syscall(SYS_gettid),
            0, // depth
            -1, // previous split l
            -1, // previous split n
            &prev_neurons,
            activation_history,
            best_intervals);
    gettimeofday(&finish, NULL);

    free(activation_history);

    for (int i = 0; i < (nnet->maxLayerSize * (nnet->numLayers + 1)); i++) {
        free(best_intervals[i]);
        best_intervals[i] = NULL;
    }
    free(best_intervals);
    free(dims_used);

    double time_spent = ((double)(finish.tv_sec - start.tv_sec) * 1000000 + \
		  (double)(finish.tv_usec - start.tv_usec)) / 1000000;

    pthread_mutex_lock(&lock);
    assert(count == 0);

    // Extract NN name from full path
    char nn_name[128];
    memset(nn_name, '\0', 128);
    int i = 0, j = 0;
    while (FULL_NET_PATH[i] != '\0') {
        if (FULL_NET_PATH[i] == '/') {
            j = 0;
            memset(nn_name, '\0', 128);
        } else {
            nn_name[j] = FULL_NET_PATH[i];
            j++;
        }
        i++;
    }

    char bnd_name[128];
    memset(bnd_name, '\0', 128);
    if (PROPERTY >= 1000) {
        int i = 0, j = 0;
        while(mnist_bounds[i] != '\0') {
            if (mnist_bounds[i] == '/') {
                j = 0;
                memset(bnd_name, '\0', 128);
            } else {
                bnd_name[j] = mnist_bounds[i];
                j++;
            }
            i++;
        }
    }

    if (csv_print) {
        // Line below should be the header for the csv file ACAS.
        // MNIST (property >= 1000) adds the output bounds as well
        // property,NN,target,time,adv,uncertain_analysis,num_splits,leaf_num,uncertain_leaf_num,active_splits,inactive_splits,hybrid_splits,killed_splits,max_depth,total_avg_depth,
        // ReLUs,avg_lin_ReLU_split,avg_lin_ReLU_robust,avg_lin_ReLU_active_split,avg_lin_ReLU_inactive_split,avg_lin_ReLU_hybrid_split,
        // total_gurobi_time,total_gurobi_count,input_gurobi_count,gurobi_count,num_dims_allowed,max_dims_used_robust,min_dims_used_robust
        printf("%d,", PROPERTY);                                            // property
        printf("%s,", nn_name);                                             // NN
        printf("%d,", target);                                              // target
        if (PROPERTY >= 1000) {
            printf("%s,", bnd_name);
        }
        printf("%f,", time_spent);                                          // time
        printf("%d,", adv_found);                                           // adv
        printf("%d,", uncertain_analysis);                                  // uncertain_analysis
        printf("%d,", split_num);                                           // num_splits
        printf("%d,", leaf_num);                                            // leaf_num
        printf("%d,", uncertain_leaf_num);                                  // uncertain_leaf_num
        printf("%d,", active_splits);                                       // active_splits
        printf("%d,", inactive_splits);                                     // inactive_splits
        printf("%d,", hybrid_splits);                                       // hybrid_splits
        printf("%d,", killed_splits);                                       // killed_splits
        printf("%f,", max_depth);                                           // max_depth
        printf("%f,", total_avg_depth);                                     // total_avg_depth
        printf("%d,", total_relu_neurons);                                  // ReLUs
        printf("%f,", avg_linear_neurons_split / total_relu_neurons);       // avg_lin_ReLU_split
        printf("%f,", avg_linear_neurons_robust / total_relu_neurons);      // avg_lin_ReLU_robust
        printf("%f,", avg_lin_split_active / total_relu_neurons);           // avg_lin_ReLU_active_split
        printf("%f,", avg_lin_split_inactive / total_relu_neurons);         // avg_lin_ReLU_inactive_split
        printf("%f,", avg_lin_split_hybrid / total_relu_neurons);           // avg_lin_ReLU_hybrid_split
        printf("%f,", total_gurobi_time);                                   // total_gurobi_time
        printf("%d,", total_gurobi_count);                                  // total_gurobi_count
        printf("%d,", input_gurobi_count);                                  // input_gurobi_count
        printf("%d,", gurobi_count);                                        // gurobi_count
        printf("%d,", num_dims_allowed);                                    // num_dims_allowed
        printf("%d,", max_dims_used_robust);                                // max_dims_used_robust
        printf("%d\n", min_dims_used_robust);                               // min_dims_used_robust
    } else {
        printf(">>>>>>>> pid=%ld, main\n", syscall(SYS_gettid));
        if (adv_found == 0 && !uncertain_analysis) {
            printf("No adv!\n");
        } else if (adv_found == 0 && uncertain_analysis) {
            printf("Uncertain analysis!\n");
        }
        printf("NN: %s, property: %d, target: %d", nn_name, PROPERTY, target);
        if (PROPERTY >= 1000) {
            printf(", Bounds: %s\n", bnd_name);
        } else {
            printf("\n");
        }
        printf("\ttime: %f, max_depth: %f, total_avg_depth: %f, leaf_num: %d, uncertain_leaf_num: %d\n" \
                "\tnum splits: %d, active: %d, inactive: %d, hybrid: %d, killed: %d\n" \
                "\tReLUs: %d, avg lin. ReLUs per split: %f, avg lin. ReLUs at robustness: %f\n" \
                "\tActive split avg lin ReLU: %f, Inactive split avg lin ReLU: %f, Hybrid split avg lin ReLU: %f\n" \
                "\tTotal Gurobi time: %f, Total Gurobi count: %d, Input Gurobi count: %d, Gurobi count: %d\n" \
                "\tDims allowed per split: %d, Max dims used at robustness: %d, Min dims used at robustness: %d\n",
                time_spent, max_depth, total_avg_depth, leaf_num, uncertain_leaf_num,
                split_num, active_splits, inactive_splits, hybrid_splits, killed_splits,
                total_relu_neurons, avg_linear_neurons_split / total_relu_neurons, avg_linear_neurons_robust / total_relu_neurons,
                avg_lin_split_active / total_relu_neurons, avg_lin_split_inactive / total_relu_neurons, avg_lin_split_hybrid / total_relu_neurons,
                total_gurobi_time, total_gurobi_count, input_gurobi_count, gurobi_count,
                num_dims_allowed, max_dims_used_robust, min_dims_used_robust);
        printf("\tavg_target_output_width: %f\n", avg_target_output_width);
        printf("<<<<<<<< pid=%ld, main \n", syscall(SYS_gettid));
        printf("\n\n");
    }
    pthread_mutex_unlock(&lock);

    destroy_network(nnet);
    free(input_interval->lower_dmatrix->data);
    free(input_interval->lower_dmatrix);
    free(input_interval->upper_dmatrix->data);
    free(input_interval->upper_dmatrix);
    free(input_interval);

    free(data_upper_output);
    free(data_lower_output);
    free(matrix_upper_output);
    free(matrix_lower_output);
    free(output_interval);

    free(current_base->data);
    free(current_base);
    free(current_origin->data);
    free(current_origin);

    return 0;
}
