#include "dmatrix.h"


/*
 * dmatrix multiplication with factor
 * Takes in targeted DMatrix A and DMatrix B
 * and factors alpha and beta
 * Stores the output in DMatrix C
 */
void matmul_with_factor(struct DMatrix* A,\
                        struct DMatrix* B,\
                        struct DMatrix* C,\
                        double alpha,\
                        double beta)
{
    int m = A->row;
    int k = A->col;
    int n = B->col;
    cblas_dgemm(CblasColMajor,\
                CblasNoTrans,\
                CblasNoTrans,\
                m, n, k, alpha,\
                A->data, m, B->data,\
                k, beta, C->data, m);

}


/*
 * Add the targeted dmatrix with a bias vector
 * Takes in targeted DMatrix A and bias vector alpha
 * Stores the output A+alpha in A
 */
void add_constant(struct DMatrix* A, double alpha)
{

    int m = A->row;
    int k = A->col;

    for (int i=0;i<m*k;i++) {
        A->data[i] += alpha;
    }

}



/*
 * DMatrix multiplication C = AB+C
 * Takes in DMatrix A and DMatrix B and
 * store AB+C in DMatrix C
 */
void matmul_with_bias(struct DMatrix* A,\
                     struct DMatrix* B,\
                     struct DMatrix* C)
{
    //cblas_dgemm(CblasRowMajor,\
                  CblasNoTrans,\
                  CblasNoTrans,\
                  m, n, k,\
                  alpha, A, k, B,\
                  n, beta, C, n);

    int m = A->row;
    int k = A->col;
    int n = B->col;

    C->row = A->row;
    C->col = B->col;

    cblas_dgemm(CblasColMajor,\
                CblasNoTrans,\
                CblasNoTrans,
                m, n, k, 1,\
                A->data, m, B->data,\
                k, 1, C->data, m);
}


/*
 * DMatrix multiplication C = AB
 * Takes in DMatrix A and DMatrix B and store AB in DMatrix C
 */
void matmul(struct DMatrix* A,\
            struct DMatrix* B,\
            struct DMatrix* C)
{
    //cblas_dgemm(CblasRowMajor,\
                  CblasNoTrans,\
                  CblasNoTrans,\
                  m, n, k,\
                  alpha, A, k, B,\
                  n, beta, C, n);

    int m = A->row;
    int k = A->col;
    int n = B->col;

    C->row = A->row;
    C->col = B->col;

    cblas_dgemm(CblasColMajor,\
                CblasNoTrans,\
                CblasNoTrans,\
                m, n, k, 1,\
                A->data, m, B->data,\
                k, 0, C->data, m);
}



/*
 * Element-wise dmatrix multiplication
 * Take in the two targeted dmatrix, which should have same shape
 */
void multiply(struct DMatrix* A, struct DMatrix* B)
{

    for (int i=0;i<A->row*A->col;i++) {
        A->data[i] = A->data[i] * B->data[i];
    }

}


/*
 * DMatrix dot product d = x . y
 * Takes in DMatrix A and DMatrix B and store AB in DMatrix C
 */
double dot(struct DMatrix* x, struct DMatrix* y)
{
    assert(x->row == y->row);
    assert(x->col == 1);
    assert(y->col == 1);

    return cblas_ddot(x->row, x->data, 1, y->data, 1);
}

/*
 * Take the relu of targeted dmatrix
 * Take in the targeted dmatrix
 */
void relu(struct DMatrix* A)
{

    for (int i=0;i<A->col*A->row;i++) {

        if (A->data[i] < 0) {
            A->data[i] = 0;
        }

    }

}


/*
 * Print the dmatrix
 * Take in the targed dmatrix
 */
void printDMatrix(struct DMatrix* A)
{
    if (A->row == 1) {
        printf("[");
        for (int i = 0; i < A->col; i++) {
            printf("%.20f", A->data[i]);
            if (i != A->col - 1) printf(" ");
        }
        printf("] (row vec)\n");
    } else if (A->col == 1) {
        printf("[");
        for (int i = 0; i < A->row; i++) {
            printf("%.20f", A->data[i]);
            if (i != A->row - 1) printf(" ");
        }
        printf("] (col vec)\n");
    } else {
        printf("[");
        for (int stride = 0; stride < A->row; stride++) {
            printf("[");
            for (int i = 0; i < A->col; i++) {
                printf("%.20f", A->data[A->row * i + stride]);
                if (i != A->col - 1) printf(" ");
            }
            printf("]");
            if (stride != A->row - 1)
                printf("\n");
        }
        printf("]\n");
    }
}


/*
 * Print the DMatrix in file
 * Take in the file and the targeted dmatrix
 */
void fprintDMatrix(FILE *fp, struct DMatrix* A){
    //printf("%d %d\n", A->row, A->col);

    if (A->col == 1) {
        fprintf(fp, "[");

        for (int i=0;i<A->row;i++) {
            fprintf(fp, "%f ", A->data[i]);
        }

        fprintf(fp, "]\n");
        return;
    }

    if (A->row == 1) {
        fprintf(fp, "[");
        for(int i=0;i<A->col;i++){
            fprintf(fp, "%f ", A->data[i]);
        }
        fprintf(fp, "]\n");
        return;
    }

    fprintf(fp, "[" );

    for (int i=0;i<A->col;i++) {
        fprintf(fp, "[");

        for(int j=0;j<A->row;j++){
            fprintf(fp, "%f ",A->data[A->row*i+j]);
        }

        if (i == A->col-1) {
            fprintf(fp,"]");
        }
        else {
            fprintf(fp, "]\n");
        }

    }

    fprintf(fp, "]\n");

}

lapack_int DMatrix_LU_decomposition(struct DMatrix *A, struct DMatrix *L, struct DMatrix *U)
{
    double data[A->row * A->col];
    memcpy(data, A->data, sizeof(double) * A->row * A->col);
    struct DMatrix mat = {
        .data = data,
        .row = A->row,
        .col = A->col
    };

    lapack_int ipiv[mat.row];
    memset(ipiv, -1, sizeof(lapack_int) * mat.row);
    lapack_int ret = LAPACKE_dgetrf(LAPACK_COL_MAJOR, mat.row, mat.col, mat.data, mat.row, ipiv);
    if (ret != 0) return ret;

    for (int c = 0; c < L->col; c++) {
        for (int r = 0; r < L->row; r++) {
            if (c == r) {
                L->data[c * L->row + r] = 1.0;
            } else if (r > c) {
                L->data[c * L->row + r] = mat.data[c * L->row + r];
            } else {
                L->data[c * L->row + r] = 0.0;
            }
        }
    }

    for (int c = 0; c < U->col; c++) {
        for (int r = 0; r < U->row; r++) {
            if (r <= c) {
                U->data[c * U->row + r] = mat.data[c * U->row + r];
            } else {
                U->data[c * U->row + r] = 0.0;
            }
        }
    }

    return ret;
}

lapack_int DMatrix_inverse(struct DMatrix *A, struct DMatrix *A_inv)
{
    assert(A->row == A->col);
    A_inv->row = A->row;
    A_inv->col = A->col;

    memcpy(A_inv->data, A->data, sizeof(double) * A->row * A->col);

    lapack_int ipiv[A_inv->row];
    memset(ipiv, -1, sizeof(lapack_int) * A_inv->row);
    lapack_int ret = LAPACKE_dgetrf(LAPACK_COL_MAJOR, A_inv->row, A_inv->col, A_inv->data, A_inv->row, ipiv);
    if (ret != 0) return ret;

    ret = LAPACKE_dgetri(LAPACK_COL_MAJOR, A_inv->row, A_inv->data, A_inv->row, ipiv);

    return ret;
}

int DMatrix_rank(struct DMatrix *A)
{
    // Compute the rank of A
    // This is done by counting the number of rows that has non-zero values.
    // E.g., if A has 2 rows containing non-zero values then A has rank 2.
    // Since we are storing them in the column-major format, this is quite inefficient for the cache.
    // Note that for-loops below are "switched" to iterate through rows instead of columns.
    int rank = 0;

    for (int r = 0; r < A->row; r++) {
        for (int c = 0; c < A->col; c++) {
            if (A->data[c * A->row + r] != 0) {
                // At least 1 non-zero value means that we can skip ahead to next row
                rank += 1;
                break;
            }
        }
    }

    return rank;
}
