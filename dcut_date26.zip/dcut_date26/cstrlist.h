#ifndef CSTRLIST_H
#define CSTRLIST_H

struct Cstr{
    int length;
    double* coeffs;
    char direction;
    double d;
};

/* define the structure of a list of linear constraints */
struct CStrList{
    struct Cstr current;
    struct CStrList* next;
};

void print_constraints(struct CStrList* pcstrlist);


#endif

