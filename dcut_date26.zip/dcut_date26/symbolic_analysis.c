#include "symbolic_analysis.h"

void compute_tighter_bounds_gurobi(
        int const input_size,
        int const current_neuron,
        struct DMatrix *base,
        struct DInterval *input,
        struct CStrList *pcstrlist,
        struct DInterval *new_equation_interval,
        double *lb,
        double *ub)
{
    /*
    All symbolic expressions are using the input variables
    One extra variable to denote the current output neuron

    We assume that all symbolic expressions are using the variables of the new base
    This is true in all cases except in the original problem.
    In the following model we need to encode the constraints in pcstrlist as well
    as how the old base is related to the new base.
    E.g., if we have the base

         B_c/o = 1/sqrt(2) | 1   1|
                           |-1   1|
    We have to encode:
         x' = 1/sqrt(2) (x - y) <=> x' - x/sqrt(2) + y/sqrt(2) = 0
         y' = 1/sqrt(2) (x + y) <=> y' - x/sqrt(2) - y/sqrt(2) = 0

    The following is equivalent but relies on the inverse of the base:
         x = 1/sqrt(2) (x' + y')
         y = 1/sqrt(2) (-x' + y')
    We need:
         input_size variables for the original base
         input_size variables for the new base
         1 variable for the current output neuron
    */
    int const num_vars = 2 * input_size + 1;
    GRBmodel *model = NULL;
    GRBenv *env = NULL;
    char modelname[] = "models/model.lp";
    construct_common_model(&model, &env, modelname, num_vars);

#ifdef DEBUG
    char modelname1[] = "models/a.lp";
    GRBwrite(model, modelname1);
#endif

    int lp_var_index[num_vars];
    for (int i = 0; i < num_vars; i++)
        lp_var_index[i] = i;

    // pcstrlist contains the original bounds and split bounds
    struct CStrList *list = pcstrlist;
    int error = 0;
    while (list) {
        char dir = list->current.direction;
        assert(dir == GRB_GREATER_EQUAL || dir == GRB_LESS_EQUAL || dir == GRB_EQUAL);

        error = GRBaddconstr(model, input_size, lp_var_index, list->current.coeffs, dir, list->current.d, "");
        if (error)
            quit_and_print_gurobi_error(env);

        list = list->next;
    }

#ifdef DEBUG
    char modelname2[] = "models/b.lp";
    GRBwrite(model, modelname2);
#endif

    // Encode the base
    double expr[num_vars];
    for (int h = 0; h < input_size; h++) {
        memset(expr, 0, sizeof(double) * num_vars);
        // Input variable in new base
        expr[input_size + h] = 1.0;
        for (int g = 0; g < input_size; g++) {
            expr[g] = -base->data[input_size * h + g];
        }

        error = GRBaddconstr(model, num_vars, lp_var_index, expr, GRB_EQUAL, 0.0, "");
        if (error)
            quit_and_print_gurobi_error(env);
    }

    // Encode the input bounds of the variables of the new base
    for (int h = 0; h < input_size; h++) {
        memset(expr, 0, sizeof(double) * num_vars);
        // Input variable in new base
        expr[input_size + h] = 1.0;
        double in_lb = input->lower_dmatrix->data[h];
        double in_ub = input->upper_dmatrix->data[h];

        error = GRBaddconstr(model, num_vars, lp_var_index, expr, GRB_GREATER_EQUAL, in_lb, "");
        if (error)
            quit_and_print_gurobi_error(env);
        error = GRBaddconstr(model, num_vars, lp_var_index, expr, GRB_LESS_EQUAL, in_ub, "");
        if (error)
            quit_and_print_gurobi_error(env);
    }


#ifdef DEBUG
    char modelname3[] = "models/c.lp";
    GRBwrite(model, modelname3);
#endif

    // Finally encode the symbolic equation of the current output neuron
    // Remember that the symbolic equations are encoded in the new base
    double expr_lo[num_vars];
    double expr_up[num_vars];
    memset(expr_lo, 0, sizeof(double) * num_vars);
    memset(expr_up, 0, sizeof(double) * num_vars);
    expr_lo[num_vars - 1] = 1.0;
    expr_up[num_vars - 1] = 1.0;
    for (int h = 0; h < input_size; h++) {
        expr_lo[input_size + h] = -new_equation_interval->lower_dmatrix->data[(input_size + 1) * current_neuron + h];
        expr_up[input_size + h] = -new_equation_interval->upper_dmatrix->data[(input_size + 1) * current_neuron + h];
    }
    double coeff_lo = new_equation_interval->lower_dmatrix->data[(input_size + 1) * current_neuron + input_size];
    double coeff_up = new_equation_interval->upper_dmatrix->data[(input_size + 1) * current_neuron + input_size];

    error = GRBaddconstr(model, num_vars, lp_var_index, expr_lo, GRB_GREATER_EQUAL, coeff_lo, "");
    if (error)
        quit_and_print_gurobi_error(env);

    error = GRBaddconstr(model, num_vars, lp_var_index, expr_up, GRB_LESS_EQUAL, coeff_up, "");
    if (error)
        quit_and_print_gurobi_error(env);

    GRBupdatemodel(model);
#ifdef DEBUG
    GRBwrite(model, modelname);
#endif

    // Encode the objective function
    double obj[num_vars];
    memset(obj, 0, sizeof(double) * num_vars);
    obj[num_vars - 1] = 1.0;
    *lb = 0.0;
    *ub = 0.0;

    pthread_mutex_lock(&lock);
    gurobi_count++;
    pthread_mutex_unlock(&lock);
    error = get_optimal_val(model, env, obj, num_vars, GRB_MINIMIZE, lb);
    if (error)
        quit_and_print_gurobi_error(env);

    pthread_mutex_lock(&lock);
    gurobi_count++;
    pthread_mutex_unlock(&lock);
    error = get_optimal_val(model, env, obj, num_vars, GRB_MAXIMIZE, ub);
    if (error)
        quit_and_print_gurobi_error(env);

    // Free model and environment used
    error = GRBfreemodel(model);
    if (error)
        quit_and_print_gurobi_error(env);
    GRBfreeenv(env);
}

void compute_concrete_relu(
        int const input_size,
        int const max_layer_size,
        int const current_neuron,
        int const current_layer,
        enum NeuronState const forced_state,
        struct DInterval *new_concrete_interval)
{
    double const L = new_concrete_interval->lower_dmatrix->data[current_neuron];
    double const U = new_concrete_interval->upper_dmatrix->data[current_neuron];

    // Does not seem to affect result too much if disabled.
    int const force_active      = 0; // (forced_state == ACTIVE) && (fabs(L) < 1e-7) && L < 0;
    int const force_inactive    = 0; // (forced_state == INACTIVE) && (fabs(U) < 1e-7) && U > 0;

    if (L > 0 || force_active) {
#ifdef DEBUG
        if (force_active) {
            pthread_mutex_lock(&lock);
            printf(">>>>>>> pid=%ld symbolic_analysis, concrete ReLU\n", syscall(SYS_gettid));
            printf("Neuron (l=%d, n=%d) : [%.20f, %.20f] forced ACTIVE\n",
                    current_layer, current_neuron, L, U);
            printf("<<<<<<< pid=%ld symbolic_analysis, concrete ReLU\n", syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
        }
#endif
    } else if (U <= 0 || force_inactive) {
#ifdef DEBUG
        if (force_inactive) {
            pthread_mutex_lock(&lock);
            printf(">>>>>>> pid=%ld symbolic_analysis, concrete ReLU\n", syscall(SYS_gettid));
            printf("Neuron (l=%d, n=%d) : [%.20f, %.20f] forced INACTIVE\n",
                    current_layer, current_neuron, L, U);
            printf("<<<<<<< pid=%ld symbolic_analysis, concrete ReLU\n", syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
        }
#endif
        new_concrete_interval->upper_dmatrix->data[current_neuron] = 0;
        new_concrete_interval->lower_dmatrix->data[current_neuron] = 0;
    } else if (L <= 0) {
        new_concrete_interval->lower_dmatrix->data[current_neuron] = 0;
    }
}

void compute_symbolic_relu(
        int const input_size,
        int const max_layer_size,
        int const current_neuron,
        int const current_layer,
        enum NeuronState const forced_state,
        struct IntervalVals **neuron_intervals,
        struct EqIntervalVals *concrete_vals_symbolic,
        struct DInterval *new_equation_interval,
        int const compute_activations, // flag to determine if we should compute the activation vector
        enum NeuronState *activation_history)
{
    double const L = neuron_intervals[current_neuron + (current_layer + 1) * max_layer_size]->lo;
    double const U = neuron_intervals[current_neuron + (current_layer + 1) * max_layer_size]->up;
    double const l_lower = concrete_vals_symbolic->eq_lo.lo;
    double const u_lower = concrete_vals_symbolic->eq_lo.up;
    double const l_upper = concrete_vals_symbolic->eq_up.lo;
    double const u_upper = concrete_vals_symbolic->eq_up.up;

    // Does not seem to affect result too much if disabled.
    int const force_active      = 0; // (forced_state == ACTIVE) && (fabs(L) < 1e-7) && L < 0;
    int const force_inactive    = 0; // (forced_state == INACTIVE) && (fabs(U) < 1e-7) && U > 0;

    if (L > 0 || force_active) { // Neuron is alive!
        if (compute_activations) {
            activation_history[current_neuron + current_layer * max_layer_size] = ACTIVE;
        }
#ifdef DEBUG
        if (force_active) {
            pthread_mutex_lock(&lock);
            printf(">>>>>>> pid=%ld symbolic_analysis, symbolic ReLU\n", syscall(SYS_gettid));
            printf("Neuron (l=%d, n=%d) : [%.20f, %.20f] forced ACTIVE\n",
                    current_layer, current_neuron, L, U);
            printf("<<<<<<< pid=%ld symbolic_analysis, symbolic ReLU\n", syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
        }
#endif
    } else if (U <= 0 || force_inactive) { // Neuron is dead!
        if (compute_activations) {
            activation_history[current_neuron + current_layer * max_layer_size] = INACTIVE;
        }
#ifdef DEBUG
        if (force_inactive) {
            pthread_mutex_lock(&lock);
            printf(">>>>>>> pid=%ld symbolic_analysis, symbolic ReLU\n", syscall(SYS_gettid));
            printf("Neuron (l=%d, n=%d) : [%.20f, %.20f] forced INACTIVE\n",
                    current_layer, current_neuron, L, U);
            printf("<<<<<<< pid=%ld symbolic_analysis, symbolic ReLU\n", syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
        }
#endif
        for (int k = 0; k < input_size + 1; k++) {
            new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)] = 0;
            new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] = 0;
        }
    } else { // L < 0 < U
        if (compute_activations) {
            activation_history[current_neuron + current_layer * max_layer_size] = HYBRID;
        }
        if (l_upper > 0) { // Upper equation is alive
        } else if (l_upper >= L) { // Use l_upper and U
            for (int k = 0; k < input_size + 1; k++) {
                new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)] *= U / (U - l_upper);
            }
            new_equation_interval->upper_dmatrix->data[input_size + current_neuron * (input_size + 1)] -=
                U * l_upper / (U - l_upper);
        } else if (l_upper <= L) { // Use L and U
            for (int k = 0; k < input_size + 1; k++) {
                new_equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)] *= U / (U - L);
            }
            new_equation_interval->upper_dmatrix->data[input_size + current_neuron * (input_size + 1)] -=
                U * L / (U - L);
        }

        // Consider neurons dead when they are equal to 0 to avoid division by zero.
        if (u_lower <= 0) { // Lower equation is dead
            for (int k = 0; k < input_size + 1; k++) {
                new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] = 0;
            }
        } else if (u_lower >= U) { // Use L and U
            for (int k = 0; k < input_size + 1; k++) {
                new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] *= U / (U - L);
            }
        } else if (u_lower <= U) { // Use L and u_lower
            for (int k = 0; k < input_size + 1; k++) {
                new_equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] *=
                    u_lower / (u_lower - L);
            }
        }
    }
}

void compute_concrete_interval_symbolic(
        int const input_size,
        int const current_neuron,
        double const applied_outward_round,

        struct DInterval *input,

        struct DInterval *equation_interval,
        struct EqIntervalVals *eq_int_vals)
{
    for (int k = 0; k < input_size; k++) {
        // Compute concrete intervals in new base
        if (equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)] >= 0) {
            eq_int_vals->eq_lo.lo +=
                (equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->lower_dmatrix->data[k]) - applied_outward_round;
            eq_int_vals->eq_lo.up +=
                (equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->upper_dmatrix->data[k]) - applied_outward_round;
        } else {
            eq_int_vals->eq_lo.lo +=
                (equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->upper_dmatrix->data[k]) - applied_outward_round;
            eq_int_vals->eq_lo.up +=
                (equation_interval->lower_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->lower_dmatrix->data[k]) - applied_outward_round;
        }
        if (equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)] >= 0) {
            eq_int_vals->eq_up.up +=
                (equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->upper_dmatrix->data[k]) + applied_outward_round;
            eq_int_vals->eq_up.lo +=
                (equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->lower_dmatrix->data[k]) + applied_outward_round;
        } else {
            eq_int_vals->eq_up.up +=
                (equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->lower_dmatrix->data[k]) + applied_outward_round;
            eq_int_vals->eq_up.lo +=
                (equation_interval->upper_dmatrix->data[k + current_neuron * (input_size + 1)]
                 * input->upper_dmatrix->data[k]) + applied_outward_round;
        }
    }

    eq_int_vals->eq_lo.lo +=
        equation_interval->lower_dmatrix->data[input_size + current_neuron * (input_size + 1)];
    eq_int_vals->eq_lo.up +=
        equation_interval->lower_dmatrix->data[input_size + current_neuron * (input_size + 1)];
    eq_int_vals->eq_up.up +=
        equation_interval->upper_dmatrix->data[input_size + current_neuron * (input_size + 1)];
    eq_int_vals->eq_up.lo +=
        equation_interval->upper_dmatrix->data[input_size + current_neuron * (input_size + 1)];
}

void meet_concrete_symbolic_best(
        int const input_size,
        int const max_layer_size,
        int const current_neuron,
        int const current_layer,
        struct DInterval *concrete_interval,
        struct EqIntervalVals *concrete_vals_symbolic,
        struct IntervalVals **neuron_intervals)
{
    double l = -1.0/0.0;
    double u = 1.0/0.0;

    if (concrete_interval->lower_dmatrix->data[current_neuron] < concrete_vals_symbolic->eq_lo.lo)
        l = concrete_vals_symbolic->eq_lo.lo;
    else
        l = concrete_interval->lower_dmatrix->data[current_neuron];

    if (concrete_interval->upper_dmatrix->data[current_neuron] > concrete_vals_symbolic->eq_up.up)
        u = concrete_vals_symbolic->eq_up.up;
    else
        u = concrete_interval->upper_dmatrix->data[current_neuron];

    // Above we set l and u to best values from concrete or symbolic interval anaylsis
    // Now we compare with the previsouly known best values

    if (neuron_intervals[current_neuron + (current_layer + 1) * max_layer_size]->lo < l)
        neuron_intervals[current_neuron + (current_layer + 1) * max_layer_size]->lo = l;

    if (neuron_intervals[current_neuron + (current_layer + 1) * max_layer_size]->up > u)
        neuron_intervals[current_neuron + (current_layer + 1) * max_layer_size]->up = u;
}

void affine_symbolic_step(
        int const input_size,
        int const max_layer_size,
        struct DInterval *interval,
        struct DMatrix *weights,
        struct DMatrix *bias,
        struct DInterval *new_interval)
{
    assert(interval->upper_dmatrix->row == input_size + 1);
    assert(interval->lower_dmatrix->row == input_size + 1);
    assert(new_interval->upper_dmatrix->row == input_size + 1);
    assert(new_interval->upper_dmatrix->row == input_size + 1);

    int const layer_size = weights->row;
    int const next_layer_size = weights->col;

    assert(interval->upper_dmatrix->col == layer_size);
    assert(interval->lower_dmatrix->col == layer_size);

    memset(new_interval->upper_dmatrix->data, 0, sizeof(double) * (input_size + 1) * max_layer_size);
    memset(new_interval->lower_dmatrix->data, 0, sizeof(double) * (input_size + 1) * max_layer_size);

    new_interval->lower_dmatrix->col = next_layer_size;
    new_interval->upper_dmatrix->col = next_layer_size;

    double p[layer_size * next_layer_size];
    memset(p, 0, sizeof(double) * layer_size * next_layer_size);
    struct DMatrix pos_weights = {p, layer_size, next_layer_size};

    double n[layer_size * next_layer_size];
    memset(n, 0, sizeof(double) * layer_size * next_layer_size);
    struct DMatrix neg_weights = {n, layer_size, next_layer_size};

    // identify positive and negative coefficients at current layer
    for (int i = 0; i < layer_size * next_layer_size; i++) {
        if (weights->data[i] >= 0) {
            pos_weights.data[i] = weights->data[i];
        } else {
            neg_weights.data[i] = weights->data[i];
        }
    }

    // symbolic uppers of next-layer intervals:
    // positives * symbolic uppers of current intervals + negatives * symbolic lowers of current intervals
    matmul(interval->upper_dmatrix, &pos_weights, new_interval->upper_dmatrix);
    matmul_with_bias(interval->lower_dmatrix, &neg_weights, new_interval->upper_dmatrix);

    // symbolic lowers of next-layer intervals:
    // positives * symbolic lowers of current intervals + negatives * symbolic uppers of current intervals
    matmul(interval->lower_dmatrix, &pos_weights, new_interval->lower_dmatrix);
    matmul_with_bias(interval->upper_dmatrix, &neg_weights, new_interval->lower_dmatrix);

    // add bias in symbolic intervalss and in lower/upper values of lower/upper symbolic intervalss
    for(int i=0; i < next_layer_size; i++) {
        new_interval->lower_dmatrix->data[i * (input_size + 1) + input_size] += bias->data[i];
        new_interval->upper_dmatrix->data[i * (input_size + 1) + input_size] += bias->data[i];
    }
}

void affine_concrete_step(
            int const input_size,
            int const max_layer_size,
            struct DInterval *concrete_interval,
            struct DMatrix *weights,
            struct DMatrix *bias,
            struct DInterval *new_concrete_interval)
{
    memset(new_concrete_interval->upper_dmatrix->data, 0, sizeof(double) * max_layer_size);
    memset(new_concrete_interval->lower_dmatrix->data, 0, sizeof(double) * max_layer_size);

    int const layer_size = weights->row;
    int const next_layer_size = weights->col;

    new_concrete_interval->lower_dmatrix->row = next_layer_size;
    new_concrete_interval->upper_dmatrix->row = next_layer_size;

    for (int c = 0; c < next_layer_size; c++) {
        for (int r = 0; r < layer_size; r++) {
            double const w = weights->data[r + c * layer_size];
            if (w > 0) {
                new_concrete_interval->upper_dmatrix->data[c] += w * concrete_interval->upper_dmatrix->data[r];
                new_concrete_interval->lower_dmatrix->data[c] += w * concrete_interval->lower_dmatrix->data[r];
            } else {
                new_concrete_interval->upper_dmatrix->data[c] += w * concrete_interval->lower_dmatrix->data[r];
                new_concrete_interval->lower_dmatrix->data[c] += w * concrete_interval->upper_dmatrix->data[r];
            }
        }
    }
    for(int i = 0; i < next_layer_size; i++) {
        new_concrete_interval->lower_dmatrix->data[i] += bias->data[i];
        new_concrete_interval->upper_dmatrix->data[i] += bias->data[i];
    }
}

void init_concrete_intervals(
            int const input_size,
            int const max_layer_size,
            struct DInterval *input,
            struct DMatrix *base,
            struct DMatrix *origin,
            struct DInterval *concrete_interval)
{
    memset(concrete_interval->upper_dmatrix->data, 0, sizeof(double) * max_layer_size);
    memset(concrete_interval->lower_dmatrix->data, 0, sizeof(double) * max_layer_size);

    double *p = (double*) malloc(sizeof(double) * input_size * input_size);
    memset(p, 0, sizeof(double) * input_size * input_size);
    struct DMatrix pos_weights = {p, input_size, input_size};

    double *n = (double*) malloc(sizeof(double) * input_size * input_size);
    memset(n, 0, sizeof(double) * input_size * input_size);
    struct DMatrix neg_weights = {n, input_size, input_size};

    for (int i = 0; i < input_size * input_size; i++) {
        if (base->data[i] >= 0)
            pos_weights.data[i] = base->data[i];
        else
            neg_weights.data[i] = base->data[i];
    }

    // Initialize concrete upper intervals
    matmul(&pos_weights, input->upper_dmatrix, concrete_interval->upper_dmatrix);
    matmul_with_bias(&neg_weights, input->lower_dmatrix, concrete_interval->upper_dmatrix);

    // Initialize concrete lower intervals
    matmul(&pos_weights, input->lower_dmatrix, concrete_interval->lower_dmatrix);
    matmul_with_bias(&neg_weights, input->upper_dmatrix, concrete_interval->lower_dmatrix);

    // Take into account origin
    for(int i = 0; i < input_size; i++) {
        concrete_interval->lower_dmatrix->data[i] += origin->data[i];
        concrete_interval->upper_dmatrix->data[i] += origin->data[i];
    }

    free(p);
    free(n);
}

void init_symbolic_intervals(
        struct DInterval *equation_interval,
        int const input_size,
        int const max_layer_size,
        struct DMatrix *base,
        struct DMatrix *origin)
{
    // This adds the initial base transposed, which is correct.
    // This is correct since we do matrix multiplication by column instead of by row.
    memset(equation_interval->upper_dmatrix->data, 0, sizeof(double) * (input_size + 1) * max_layer_size);
    memset(equation_interval->lower_dmatrix->data, 0, sizeof(double) * (input_size + 1) * max_layer_size);

    for (int col = 0; col < input_size; col++) {
        for (int row = 0; row < input_size; row++) {
            equation_interval->lower_dmatrix->data[col * (input_size + 1) + row] = base->data[row * input_size + col];
            equation_interval->upper_dmatrix->data[col * (input_size + 1) + row] = base->data[row * input_size + col];
        }
        equation_interval->lower_dmatrix->data[col * (input_size + 1) + input_size] = origin->data[col];
        equation_interval->upper_dmatrix->data[col * (input_size + 1) + input_size] = origin->data[col];
    }
}

void symbolic_forward_analysis(
        struct NNet *nnet,
        struct DMatrix *base,
        struct DMatrix *origin,
        struct DInterval *input,

        struct DInterval *input_old,

        struct DInterval *output,
        struct IntervalVals **neuron_intervals,
        struct CStrList *pcstrlist,

        struct NeuronInfoList *prev_neurons,
        enum NeuronState *activation_history,

        int const get_equations,
        struct NeuronInfo **bad_neurons)
{
    double applied_outward_round = OUTWARD_ROUND;
    if (!NEED_OUTWARD_ROUND) {
        applied_outward_round = 0;
    }

    int const num_layers = nnet->numLayers;
    int const input_size = nnet->inputSize;
    int const output_size = nnet->outputSize;
    int const max_layer_size = nnet->maxLayerSize;

    // Init concrete intervals
    double *concrete_lower = (double*) malloc(sizeof(double) * max_layer_size);
    double *concrete_upper = (double*) malloc(sizeof(double) * max_layer_size);
    struct DInterval concrete_interval = {
        .lower_dmatrix = &(struct DMatrix){(double*)concrete_lower, input_size, 1},
        .upper_dmatrix = &(struct DMatrix){(double*)concrete_upper, input_size, 1},
    };
    double *new_concrete_lower = (double*) malloc(sizeof(double) * max_layer_size);
    double *new_concrete_upper = (double*) malloc(sizeof(double) * max_layer_size);
    struct DInterval new_concrete_interval = {
        .lower_dmatrix = &(struct DMatrix){(double*)new_concrete_lower, max_layer_size, 1},
        .upper_dmatrix = &(struct DMatrix){(double*)new_concrete_upper, max_layer_size, 1},
    };
    init_concrete_intervals(input_size, max_layer_size, input, base, origin, &concrete_interval);

    // Check if inputs of ancestor provide better bounds for inital concrete analysis
    for (int i = 0; i < input_size; i++) {
        // This indexing works since we are only looking at the first input_size-th
        // intervals in the structure
        double Li = neuron_intervals[i]->lo;
        double Ui = neuron_intervals[i]->up;
        if (concrete_interval.lower_dmatrix->data[i] < Li) {
            concrete_interval.lower_dmatrix->data[i] = Li;
        }
        if (concrete_interval.upper_dmatrix->data[i] > Ui) {
            concrete_interval.upper_dmatrix->data[i] = Ui;
        }
    }

#ifdef DEBUG
    pthread_mutex_lock(&lock);
    if (!get_equations) {
        printf(">>>>>>> symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
        printf("== Input - New =======================================\n");
        printDMatrix(input->lower_dmatrix);
        printDMatrix(input->upper_dmatrix);
        printf("== Input - Old =======================================\n");
        printDMatrix(input_old->lower_dmatrix);
        printDMatrix(input_old->upper_dmatrix);
        printf("== Neuron Intervals ==================================\n");
        printf("[");
        for (int i = 0; i < input_size; i++)
            printf("%.20f ", neuron_intervals[i]->lo);
        printf("]\n");
        printf("[");
        for (int i = 0; i < input_size; i++)
            printf("%.20f ", neuron_intervals[i]->up);
        printf("]\n");
        printf("== Concrete values ===================================\n");
        printDMatrix(concrete_interval.lower_dmatrix);
        printDMatrix(concrete_interval.upper_dmatrix);
        printf("======================================================\n");
        printf("<<<<<<< symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
    }
    pthread_mutex_unlock(&lock);
#endif

    // Init symbolic intervals
    double *equation_lower = (double*) malloc(sizeof(double) * ((input_size + 1) * max_layer_size));
    double *equation_upper = (double*) malloc(sizeof(double) * ((input_size + 1) * max_layer_size));
    struct DInterval equation_interval = {
        .lower_dmatrix = &(struct DMatrix){(double*)equation_lower, input_size + 1, input_size},
        .upper_dmatrix = &(struct DMatrix){(double*)equation_upper, input_size + 1, input_size}
    };
    double *new_equation_lower = (double*) malloc(sizeof(double) * ((input_size + 1) * max_layer_size));
    double *new_equation_upper = (double*) malloc(sizeof(double) * ((input_size + 1) * max_layer_size));
    struct DInterval new_equation_interval = {
        .lower_dmatrix = &(struct DMatrix){(double*)new_equation_lower, input_size + 1, max_layer_size},
        .upper_dmatrix = &(struct DMatrix){(double*)new_equation_upper, input_size + 1, max_layer_size}
    };
    // This also perform affine transformation encoding the new base.
    init_symbolic_intervals(&equation_interval, input_size, max_layer_size, base, origin);

    // The concrete values of the symbolic equations for the current neuron
    struct EqIntervalVals concrete_vals_symbolic = {
        .eq_lo = {0.0, 0.0},
        .eq_up = {0.0, 0.0}
    };

#ifdef DEBUG
    pthread_mutex_lock(&lock);
    printf(">>>>>>> symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
    printf("== Equations at input layer ==========================\n");
    printDMatrix(equation_interval.lower_dmatrix);
    printDMatrix(equation_interval.upper_dmatrix);
    printf("======================================================\n");
    printf("== Concrete values at input layer ====================\n");
    printDMatrix(concrete_interval.lower_dmatrix);
    printDMatrix(concrete_interval.upper_dmatrix);
    printf("======================================================\n");
    printf("<<<<<<< symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
    pthread_mutex_unlock(&lock);
#endif

    for (int layer = 0; layer < num_layers; layer++) {

#ifdef DEBUG
        pthread_mutex_lock(&lock);
        printf(">>>>>>> symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
        printf("== Before Affine transformation ======================\n");
        printf("== Equations =========================================\n");
        printDMatrix(equation_interval.lower_dmatrix);
        printDMatrix(equation_interval.upper_dmatrix);
        printf("== Concrete ==========================================\n");
        printDMatrix(concrete_interval.lower_dmatrix);
        printDMatrix(concrete_interval.upper_dmatrix);
        printf("======================================================\n");
        printf("<<<<<<< symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);
#endif

        // Affine transformation concrete
        affine_concrete_step(
                input_size,
                max_layer_size,
                &concrete_interval,
                &(nnet->weights[layer]),
                &(nnet->bias[layer]),
                &new_concrete_interval);

        // Affine transformation symbolic
        affine_symbolic_step(
                input_size,
                max_layer_size,
                &equation_interval,
                &(nnet->weights[layer]),
                &(nnet->bias[layer]),
                &new_equation_interval);

#ifdef DEBUG
        pthread_mutex_lock(&lock);
        printf(">>>>>>> symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
        printf("== After Affine transformation =======================\n");
        printf("== Equations =========================================\n");
        printDMatrix(new_equation_interval.lower_dmatrix);
        printDMatrix(new_equation_interval.upper_dmatrix);
        printf("== Concrete ==========================================\n");
        printDMatrix(new_concrete_interval.lower_dmatrix);
        printDMatrix(new_concrete_interval.upper_dmatrix);
        printf("======================================================\n");
        printf("<<<<<<< symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);
#endif

        for (int i = 0; i < nnet->layerSizes[layer + 1]; i++) {
#ifdef DEBUG
            pthread_mutex_lock(&lock);
            printf(">>>>>>> symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
            printf("layer = %d, neuron = %d\n", layer, i);
            printf("<<<<<<< symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
#endif

            concrete_vals_symbolic.eq_lo.lo = 0.0;
            concrete_vals_symbolic.eq_lo.up = 0.0;
            concrete_vals_symbolic.eq_up.lo = 0.0;
            concrete_vals_symbolic.eq_up.up = 0.0;

            compute_concrete_interval_symbolic(
                    input_size,
                    i,
                    applied_outward_round,

                    input,

                    &new_equation_interval,
                    &concrete_vals_symbolic);

            meet_concrete_symbolic_best(
                    input_size,
                    max_layer_size,
                    i,
                    layer,
                    &new_concrete_interval,
                    &concrete_vals_symbolic,
                    neuron_intervals);

            // Use the meet-value to continue concrete analysis
            if (new_concrete_interval.lower_dmatrix->data[i] < neuron_intervals[i + (layer + 1) * max_layer_size]->lo) {
                new_concrete_interval.lower_dmatrix->data[i] = neuron_intervals[i + (layer + 1) * max_layer_size]->lo;
            }
            if (new_concrete_interval.upper_dmatrix->data[i] > neuron_intervals[i + (layer + 1) * max_layer_size]->up) {
                new_concrete_interval.upper_dmatrix->data[i] = neuron_intervals[i + (layer + 1) * max_layer_size]->up;
            }

#ifdef DEBUG
            pthread_mutex_lock(&lock);
            printf(">>>>>>> symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
            printf("== Pre-ReLU - l=%d, n=%d =============================\n", layer, i);
            printf("== Equations =========================================\n");
            printf("lower: [");
            for (int p = 0; p < input_size + 1; p++) {
                printf("%.20f ", new_equation_interval.lower_dmatrix->data[(input_size + 1) * i + p]);
            }
            printf("]\n");
            printf("upper: [");
            for (int p = 0; p < input_size + 1; p++) {
                printf("%.20f ", new_equation_interval.upper_dmatrix->data[(input_size + 1) * i + p]);
            }
            printf("]\n");
            printf("== Concrete symbolic =================================\n");
            printf("[%.20f, %.20f]\n", concrete_vals_symbolic.eq_lo.lo, concrete_vals_symbolic.eq_up.up);
            printf("== Concrete ==========================================\n");
            printf("[%.20f, %.20f]\n",
                    new_concrete_interval.lower_dmatrix->data[i],
                    new_concrete_interval.upper_dmatrix->data[i]);
            printf("======================================================\n");
            printf("<<<<<<< symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
            pthread_mutex_unlock(&lock);
#endif

#ifdef SOUNDNESS_DEBUG
            // Symbolic interval analysis is an over-approximation of the LP problem
            double grb_lb, grb_ub;
            compute_tighter_bounds_gurobi(
                    input_size, i, base, input, pcstrlist, &new_equation_interval, &grb_lb, &grb_ub);
            double sym_lb = concrete_vals_symbolic.eq_lo.lo;
            double sym_ub = concrete_vals_symbolic.eq_up.up;
            // printf("== Gurobi Bounds =====================================\n");
            // printf("[%.20f, %.20f]\n", grb_lb, grb_ub);
            assert((sym_lb <= grb_lb || fabs(sym_lb - grb_lb) < 1e-6) &&
                    "Over-approx lower bound greater than LP lower bound!");
            assert((sym_ub >= grb_ub || fabs(sym_ub - grb_ub) < 1e-6) &&
                    "Over-approx upper bound lesser than LP upper bound!");
#endif

            enum NeuronState forced_state = DEFAULT;
            if (!get_equations) {
                struct NeuronInfoList *nil = prev_neurons;
                while (nil->next != NULL) {
                    int const curr_split_l = nil->ni->l;
                    int const curr_split_n = nil->ni->n;
                    if (curr_split_l == layer && curr_split_n == i) {
                        // enum NeuronState const forced_state = nil->ni->state;
                        forced_state = nil->ni->state;
                        double curr_lo = neuron_intervals[nnet->maxLayerSize * (curr_split_l + 1) + curr_split_n]->lo;
                        double curr_up = neuron_intervals[nnet->maxLayerSize * (curr_split_l + 1) + curr_split_n]->up;

#ifdef DEBUG
                        char forced_state_print;
                        if (forced_state == ACTIVE) {
                            forced_state_print = 'A';
                        } else if (forced_state == INACTIVE) {
                            forced_state_print = 'D';
                        } else if (forced_state == HYBRID) {
                            forced_state_print = 'H';
                        }
#endif

                        if ((forced_state == ACTIVE && !(fabs(curr_lo) < 1e-4 || curr_lo > 0)) ||
                                (forced_state == INACTIVE && !(fabs(curr_up) < 1e-4 || curr_up < 0))) {

#ifdef DEBUG
                            char *s = forced_state == ACTIVE ? "ACTIVE" : "INACTIVE";
                            pthread_mutex_lock(&lock);
                            printf(">>>>>>> pid=%ld symbolic_analysis\n", syscall(SYS_gettid));
                            printf("Neuron forced %s is not %s (l=%d, n=%d, s=%c) : [%.20f, %.20f]\n",
                                    s, s, curr_split_l, curr_split_n, forced_state_print, curr_lo, curr_up);
                            printf("== Saved Equation - Old Base =============================\n");
                            print_current_neuron_equation(nil->ni->equation, 0 /* A lil' hack */, input_size);
                            struct EqIntervalVals conc_vals = {
                                .eq_lo = {0.0, 0.0},
                                .eq_up = {0.0, 0.0}
                            };
                            compute_concrete_interval_symbolic(
                                    input_size,
                                    0, // A lil' hack
                                    0,
                                    input_old,
                                    nil->ni->equation,
                                    &conc_vals);
                            printf("== Bounds computed from Saved Equation - Old Base ========\n");
                            printf("[%.20f, %.20f]\n", conc_vals.eq_lo.lo, conc_vals.eq_up.up);

                            double const saved_old_lo = conc_vals.eq_lo.lo;
                            double const saved_old_up = conc_vals.eq_up.up;

                            // Convert saved equation in old base to new base BEGIN
                            double data_saved_eq_in_old_lower[input_size];
                            double data_saved_eq_in_old_upper[input_size];
                            memcpy(
                                data_saved_eq_in_old_lower,
                                nil->ni->equation->lower_dmatrix->data,
                                sizeof(double) * input_size);
                            memcpy(
                                data_saved_eq_in_old_upper,
                                nil->ni->equation->upper_dmatrix->data,
                                sizeof(double) * input_size);
                            struct DInterval saved_eq_old = {
                                .lower_dmatrix = &(struct DMatrix){data_saved_eq_in_old_lower, input_size, 1},
                                .upper_dmatrix = &(struct DMatrix){data_saved_eq_in_old_upper, input_size, 1}
                            };

                            double data_base_inv[input_size * input_size];
                            struct DMatrix base_inv = {
                                .data = data_base_inv,
                                .row = input_size,
                                .col = input_size
                            };
                            lapack_int info = DMatrix_inverse(base, &base_inv);
                            if (info != 0) exit(1);

                            double data_saved_eq_in_new_lower[input_size + 1];
                            double data_saved_eq_in_new_upper[input_size + 1];
                            struct DInterval saved_eq_new = {
                                .lower_dmatrix = &(struct DMatrix){data_saved_eq_in_new_lower, input_size, 1},
                                .upper_dmatrix = &(struct DMatrix){data_saved_eq_in_new_upper, input_size, 1}
                            };
                            matmul(&base_inv, saved_eq_old.lower_dmatrix, saved_eq_new.lower_dmatrix);
                            matmul(&base_inv, saved_eq_old.upper_dmatrix, saved_eq_new.upper_dmatrix);
                            saved_eq_new.lower_dmatrix->col += 1;
                            saved_eq_new.lower_dmatrix->data[input_size] =
                                nil->ni->equation->lower_dmatrix->data[input_size];
                            saved_eq_new.upper_dmatrix->col += 1;
                            saved_eq_new.upper_dmatrix->data[input_size] =
                                nil->ni->equation->upper_dmatrix->data[input_size];

                            printf("== Saved Equation - Old -> New base ======================\n");
                            print_current_neuron_equation(&saved_eq_new, 0 /* A lil' hack */, input_size);
                            reset_eq_interval_vals(&conc_vals);
                            compute_concrete_interval_symbolic(
                                    input_size,
                                    0,
                                    0,
                                    input,
                                    &saved_eq_new,
                                    &conc_vals);
                            printf("== Bounds from Saved Equation - Old -> New base ==========\n");
                            printf("[%.20f, %.20f]\n", conc_vals.eq_lo.lo, conc_vals.eq_up.up);
                            // Convert saved equation in old base to new base END

                            printf("== Computed Equation - New Base ==========================\n");
                            print_current_neuron_equation(&new_equation_interval, i, input_size);
                            reset_eq_interval_vals(&conc_vals);
                            compute_concrete_interval_symbolic(
                                    input_size,
                                    curr_split_n,
                                    0,
                                    input,
                                    &new_equation_interval,
                                    &conc_vals);
                            printf("== Bounds computed from Computed Equation - New Base =====\n");
                            printf("[%.20f, %.20f]\n", conc_vals.eq_lo.lo, conc_vals.eq_up.up);

                            // Convert computed equation in new base to old base BEGIN
                            double data_comp_eq_in_new_lower[input_size];
                            double data_comp_eq_in_new_upper[input_size];
                            memcpy(
                                data_comp_eq_in_new_lower,
                                new_equation_interval.lower_dmatrix->data + ((input_size + 1) * i),
                                sizeof(double) * input_size);
                            memcpy(
                                data_comp_eq_in_new_upper,
                                new_equation_interval.upper_dmatrix->data + ((input_size + 1) * i),
                                sizeof(double) * input_size);
                            struct DInterval comp_eq_new = {
                                .lower_dmatrix = &(struct DMatrix){data_comp_eq_in_new_lower, input_size, 1},
                                .upper_dmatrix = &(struct DMatrix){data_comp_eq_in_new_upper, input_size, 1}
                            };

                            double data_comp_eq_in_old_lower[input_size + 1];
                            double data_comp_eq_in_old_upper[input_size + 1];
                            struct DInterval comp_eq_old = {
                                .lower_dmatrix = &(struct DMatrix){data_comp_eq_in_old_lower, input_size, 1},
                                .upper_dmatrix = &(struct DMatrix){data_comp_eq_in_old_upper, input_size, 1}
                            };
                            matmul(base, comp_eq_new.lower_dmatrix, comp_eq_old.lower_dmatrix);
                            matmul(base, comp_eq_new.upper_dmatrix, comp_eq_old.upper_dmatrix);
                            comp_eq_old.lower_dmatrix->col += 1;
                            comp_eq_old.lower_dmatrix->data[input_size] =
                                (new_equation_interval.lower_dmatrix->data + ((input_size + 1) * i))[input_size];
                            comp_eq_old.upper_dmatrix->col += 1;
                            comp_eq_old.upper_dmatrix->data[input_size] =
                                (new_equation_interval.upper_dmatrix->data + ((input_size + 1) * i))[input_size];

                            printf("== Computed Equation - New -> Old base ===================\n");
                            print_current_neuron_equation(&comp_eq_old, 0 /* A lil' hack */, input_size);
                            reset_eq_interval_vals(&conc_vals);
                            compute_concrete_interval_symbolic(
                                    input_size,
                                    0,
                                    0,
                                    input_old,
                                    &comp_eq_old,
                                    &conc_vals);
                            printf("== Bounds from Computed Equation - New -> Old base =======\n");
                            printf("[%.20f, %.20f]\n", conc_vals.eq_lo.lo, conc_vals.eq_up.up);
                            printf("==========================================================\n");

                            double const computed_old_lo = conc_vals.eq_lo.lo;
                            double const computed_old_up = conc_vals.eq_up.up;
                            if (!(saved_old_lo <= computed_old_lo)) {
                                printf("Lo of saved > lo of computed\n");
                            }
                            if (!(computed_old_up <= saved_old_up)) {
                                printf("Up of saved < up of computed\n");
                            }

                            printf("<<<<<<< pid=%ld symbolic_analysis\n", syscall(SYS_gettid));
                            pthread_mutex_unlock(&lock);
                            // Convert computed equation in new base to old base END
#endif

                            // This part could be kept.
                            // I.e., if the neuron we've forced linear for some reason is not
                            // linear in a gross way we can try to compute tighter bounds with Gurobi.
                            double new_lb, new_ub;
                            compute_tighter_bounds_gurobi(
                                    input_size,
                                    i,
                                    base,
                                    input,
                                    pcstrlist,
                                    &new_equation_interval,
                                    &new_lb,
                                    &new_ub);
                            if (neuron_intervals[i + (layer + 1) * max_layer_size]->lo < new_lb) {
                                new_concrete_interval.lower_dmatrix->data[i] =
                                    neuron_intervals[i + (layer + 1) * max_layer_size]->lo = new_lb;
                            }
                            if (neuron_intervals[i + (layer + 1) * max_layer_size]->up > new_ub) {
                                new_concrete_interval.upper_dmatrix->data[i] =
                                    neuron_intervals[i + (layer + 1) * max_layer_size]->up = new_ub;
                            }

#ifdef DEBUG
                            pthread_mutex_lock(&lock);
                            printf(">>>>>>> pid=%ld symbolic_analysis\n", syscall(SYS_gettid));
                            printf("== Bounds computed with Gurobi Procedure =================\n");
                            printf("[%.20f, %.20f]\n", new_lb, new_ub);
                            printf("== New bounds for neuron (l=%d, n=%d) ====================\n",
                                    curr_split_l, curr_split_n);
                            printf("[%.20f, %.20f]\n",
                                    new_concrete_interval.lower_dmatrix->data[i],
                                    new_concrete_interval.upper_dmatrix->data[i]);
                            printf("<<<<<<< pid=%ld symbolic_analysis\n", syscall(SYS_gettid));
                            pthread_mutex_unlock(&lock);
#endif
                        }
                    }
                    nil = nil->next;
                }
            }

            if (get_equations) {
                if (layer != num_layers - 1) {
                    for (int l = 0; l < num_layers - 1; l++) {
                        if (bad_neurons[l] != NULL) {
                            if ((bad_neurons[l]->l == layer) && (bad_neurons[l]->n == i)) {
                                for (int h = 0; h < (input_size + 1); h++) {
                                    bad_neurons[l]->equation->lower_dmatrix->data[h] =
                                        new_equation_interval.lower_dmatrix->data[(input_size + 1) * i + h];
                                    bad_neurons[l]->equation->upper_dmatrix->data[h] =
                                        new_equation_interval.upper_dmatrix->data[(input_size + 1) * i + h];
                                }
                            }
                        }
                    }
                }
            }

            // Check if we are in a ReLU layer
            if (layer < (num_layers - 1)) {
                // Compute Relu activation for concrete vals
                compute_concrete_relu(
                        input_size,
                        max_layer_size,
                        i,
                        layer,

                        forced_state,

                        &new_concrete_interval);

                // Compute ReLU activation for symbolic interval
                //      This part is where we are using the remembered intervals
                compute_symbolic_relu(
                        input_size,
                        max_layer_size,
                        i,
                        layer,

                        forced_state,

                        neuron_intervals,
                        &concrete_vals_symbolic,
                        &new_equation_interval,

                        !get_equations, // Using this flag to determine if we should compute activations
                        activation_history);

                // Compute concrete values of symbolic intervals after ReLU,
                // compare with concrete intervals and update concrete intervals
                // with whatever is tighter. We do not update neuron_intervals
                // here since we only save the best intervals coming into a neuron.
                concrete_vals_symbolic.eq_lo.lo = 0.0;
                concrete_vals_symbolic.eq_lo.up = 0.0;
                concrete_vals_symbolic.eq_up.lo = 0.0;
                concrete_vals_symbolic.eq_up.up = 0.0;
                compute_concrete_interval_symbolic(
                        input_size,
                        i,
                        applied_outward_round,
                        input,
                        &new_equation_interval,
                        &concrete_vals_symbolic);
                if (new_concrete_interval.lower_dmatrix->data[i] < concrete_vals_symbolic.eq_lo.lo)
                    new_concrete_interval.lower_dmatrix->data[i] = concrete_vals_symbolic.eq_lo.lo;
                if (new_concrete_interval.lower_dmatrix->data[i] > concrete_vals_symbolic.eq_up.up)
                    new_concrete_interval.lower_dmatrix->data[i] = concrete_vals_symbolic.eq_up.up;

#ifdef DEBUG
                pthread_mutex_lock(&lock);
                printf(">>>>>>> symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
                printf("== Post-ReLU - l=%d, n=%d ============================\n", layer, i);
                printf("== Equations =========================================\n");
                printf("lower: [");
                for (int p = 0; p < input_size + 1; p++) {
                    printf("%.20f ", new_equation_interval.lower_dmatrix->data[(input_size + 1) * i + p]);
                }
                printf("]\n");
                printf("upper: [");
                for (int p = 0; p < input_size + 1; p++) {
                    printf("%.20f ", new_equation_interval.upper_dmatrix->data[(input_size + 1) * i + p]);
                }
                printf("]\n");
                printf("== Concrete symbolic =================================\n");
                printf("[%.20f, %.20f]\n", concrete_vals_symbolic.eq_lo.lo, concrete_vals_symbolic.eq_up.up);
                printf("== Concrete ==========================================\n");
                printf("[%.20f, %.20f]\n",
                        new_concrete_interval.lower_dmatrix->data[i],
                        new_concrete_interval.upper_dmatrix->data[i]);
                printf("======================================================\n");
                printf("<<<<<<< symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
                pthread_mutex_unlock(&lock);
#endif



            } else {
                if (!get_equations) {
                    int progress = 0;
                    // The neuron_intervals structure must also represent the output
                    // Having a separate structure for the output is unnecessary?
                    // No need to compare here since neuron_intervals already contain the best known bounds?
                    if (neuron_intervals[i + (layer + 1) * max_layer_size]->lo > output->lower_dmatrix->data[i]) {
                        double a = output->lower_dmatrix->data[i];
                        double b = neuron_intervals[i + (layer + 1) * max_layer_size]->lo;
                        if (fabs(a - b) > 1e-6) // Is change large enough to not be rounding error?
                            progress = 1;

                        output->lower_dmatrix->data[i] = neuron_intervals[i + (layer + 1) * max_layer_size]->lo;
                    }
                    if (neuron_intervals[i + (layer + 1) * max_layer_size]->up < output->upper_dmatrix->data[i]) {
                        double a = output->upper_dmatrix->data[i];
                        double b = neuron_intervals[i + (layer + 1) * max_layer_size]->up;
                        if (fabs(a - b) > 1e-6)
                            progress = 1;

                        output->upper_dmatrix->data[i] = neuron_intervals[i + (layer + 1) * max_layer_size]->up;
                    }

                    // We have not tightened the output after forward analysis
                    // Invoke the almighty Gurobi to try and tighten the bounds
                    // if (0) {
                    // if (!progress) {
                    if (1) {
#ifdef DEBUG
                        pthread_mutex_lock(&lock);
                        printf(">>>>>>> symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
                        printf("Invoking Gurobi to strengthen bounds at output neuron %d\n", i);
                        printf("<<<<<<< symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
                        pthread_mutex_unlock(&lock);
#endif
                        double lb, ub;
                        compute_tighter_bounds_gurobi(
                                input_size, i, base, input, pcstrlist, &new_equation_interval, &lb, &ub);

                        if (neuron_intervals[i + (layer + 1) * max_layer_size]->lo < lb) {
                            neuron_intervals[i + (layer + 1) * max_layer_size]->lo = lb;
                            output->lower_dmatrix->data[i] = lb;
                        }
                        if (neuron_intervals[i + (layer + 1) * max_layer_size]->up > ub) {
                            neuron_intervals[i + (layer + 1) * max_layer_size]->up = ub;
                            output->upper_dmatrix->data[i] = ub;
                        }
                    }
                }
            }
        }

#ifdef DEBUG
        pthread_mutex_lock(&lock);
        printf(">>>>>>> symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
        printf("== Equations after layer %d ==========================\n", layer);
        printDMatrix(new_equation_interval.lower_dmatrix);
        printDMatrix(new_equation_interval.upper_dmatrix);
        printf("======================================================\n");
        printf("== Concrete values after layer %d ====================\n", layer);
        printDMatrix(new_concrete_interval.lower_dmatrix);
        printDMatrix(new_concrete_interval.upper_dmatrix);
        printf("======================================================\n");
        printf("<<<<<<< symbolic analysis (pid=%ld)\n", syscall(SYS_gettid));
        pthread_mutex_unlock(&lock);
#endif

        // Concrete
        memcpy(
            concrete_interval.upper_dmatrix->data,
            new_concrete_interval.upper_dmatrix->data,
            sizeof(double) * max_layer_size);
        memcpy(
            concrete_interval.lower_dmatrix->data,
            new_concrete_interval.lower_dmatrix->data,
            sizeof(double) * max_layer_size);
        concrete_interval.lower_dmatrix->row =
            concrete_interval.upper_dmatrix->row = new_concrete_interval.lower_dmatrix->row;
        concrete_interval.lower_dmatrix->col =
            concrete_interval.upper_dmatrix->col = new_concrete_interval.lower_dmatrix->col;

        // Symbolic
        memcpy(
            equation_interval.upper_dmatrix->data,
            new_equation_interval.upper_dmatrix->data,
            sizeof(double) * (input_size + 1) * max_layer_size);
        memcpy(
            equation_interval.lower_dmatrix->data,
            new_equation_interval.lower_dmatrix->data,
            sizeof(double) * (input_size + 1) * max_layer_size);
        equation_interval.lower_dmatrix->row =
            equation_interval.upper_dmatrix->row = new_equation_interval.lower_dmatrix->row;
        equation_interval.lower_dmatrix->col =
            equation_interval.upper_dmatrix->col = new_equation_interval.lower_dmatrix->col;
    }

    free(equation_lower);
    free(equation_upper);
    free(new_equation_lower);
    free(new_equation_upper);

    free(concrete_lower);
    free(concrete_upper);
    free(new_concrete_lower);
    free(new_concrete_upper);
}
